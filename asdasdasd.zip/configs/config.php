<?php 
date_default_timezone_set('Asia/Ho_Chi_Minh');
return array(
	'mysql' => array(
		'host'         => defined('DB_HOST') ? DB_HOST : 'localhost',
        'username'     => defined('DB_USER') ? DB_USER : 'root',
        'password'     => defined('DB_PASSWORD') ? DB_PASSWORD : '',
        'database'     => defined('DB_NAME') ? DB_NAME : 'mysql',
	),
    'sessiond' => DA.'/data/sessiond',
    'log_dir' => DA.'/data/logs',
	'upload' => array(
        'dir'=> DR.'/upload',
        'url'=> '/upload',
    ),
    'view_compiler' => DA.'/data/views',
);