<?php
/* Document Root */
define('DR', dirname(__FILE__).'/public');
define('DA', dirname(__FILE__));
define('DS', DIRECTORY_SEPARATOR);

define('DEBUG', 1);

define('USE_SESSION_FILE', 1);

define('module', '/cosmetics');
// define('index', 'cosmetics');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '123456');
define('DB_NAME', 'ohui');

define('_KADMIN', 'admins');
define('_TKKEYA', 'token');
define('_USER_ID', 'user_id');
