<?php
require 'definitions.php';

ini_set('display_startup_errors', defined('DEBUG') && DEBUG ? 1 : 0);
ini_set('display_errors', defined('DEBUG') && DEBUG ? 1 : 0);
error_reporting(defined('DEBUG') && DEBUG ? -1 : 0);
date_default_timezone_set('Asia/Ho_Chi_Minh');

require 'functions.php';
require DA.'/.htphp';

HT::bootstrap(Htlib_Request::getUri());