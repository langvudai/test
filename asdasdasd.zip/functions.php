<?php 

if (!function_exists('escape_string')) {
    function escape_string($string)
    {
        return addcslashes($string, "'".'"'."\0"."\n"."\r");
    }
}

if (!function_exists('to_slug')) {
    /**
     * @param string $str
     */
    function to_slug($str)
    {
        $str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
        $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
        $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
        $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
        $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
        $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
        $str = preg_replace("/(đ)/", 'd', $str);
        $str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $str);
        $str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
        $str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
        $str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $str);
        $str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
        $str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
        $str = preg_replace("/(Đ)/", 'D', $str);

        $str = preg_replace('/[^a-z0-9\-]+/i','-',$str);
        $str = preg_replace('/[\-]{1,}/','-',$str);
        return $str;
    }
}

if (!function_exists('paging')) {
    /**
     * 
     * @param int $total
     * @param int $maxItemOnPage
     * @param int $c
     * @param int $_maxPage
     * @return array [first, prev, from, to, next, last, total, current]
     */
    function paging($total=0, $maxItemOnPage=10, $c=1, $_maxPage=10)
    {
        $total = (int)$total;
        $maxItemOnPage = (int)$maxItemOnPage;
        $c = ((int)$c<1) ? 1 : $c;
        $_maxPage = (int)$_maxPage;
        if ($total<$maxItemOnPage)
            return array('first'=>0, 'prev'=>0, 'from'=>1, 'to'=>1, 'next'=>0, 'last'=>0, 'total'=>1, 'current'=>$c);
        $total = ceil($total/$maxItemOnPage);
        if ($total<=$_maxPage)
            return array('first'=>(($c==1)?0:1), 'prev'=>(($c>1)?($c-1):1), 'from'=>1, 'to'=>$total, 'next'=>(($c<$total) ? ($c+1) : $total), 'last'=>(($c==$total)?0:$total), 'total'=>$total, 'current'=>$c);
        $from = round($c - $_maxPage/2);
        $from = ($from<1) ? 1 : $from;
        $to = $from + $_maxPage - 1;
        if ($to>$total) {
            $to = $total;
            $from = $to - $_maxPage + 1;
        }
        return array('first'=>1, 'prev'=>(($c>1)?($c-1):1), 'from'=>$from, 'to'=>$to, 'next'=>(($c<$total) ? ($c+1) : $total), 'last'=>$total, 'total'=>$total, 'current'=>$c);
    }
}

if (!function_exists('is_sequent_array')) {
    function is_sequent_array (array $array)
    {
        if (array() === $array) { 
          return true;
        }

        return array_keys($array) === range(0, count($array) - 1);
    }
}

if (!function_exists('is_assoc_array')) {
    function is_assoc_array (array $array)
    {
        if (array() === $array) {
            return false;
        }

        return array_keys($array) !== range(0, count($array) - 1);
    }
}

if (!function_exists('truncate')) {
    /**
     *
     */
    function truncate($text, $chars = 25) 
    {
        $text = $text." ";
        $text = substr($text,0,$chars);
        $text = substr($text,0,strrpos($text,' '));
        $text = $text."...";
        return $text;
    }
}

if (!function_exists('is_mobile')) {
    function is_mobile($agent) 
    {
        return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $agent);
    }
}


