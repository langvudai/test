<?php

abstract class Glib_DbTable 
{
    /**
     * ninety five decimal pattern
     * @var string
     */
    private static $nfd_pattern = null;
    /** @var string */
    private static $ins_tk = 'ins_key';
    /** @var string */
    private static $created_time = 'created_time';
    /** @var string */
    private static $updated_time = 'updated_time';
    /** @var null|MySQLConnection */
    private static $default_connection = null;
    /** @var array */
    private static $table_schema_cache = array();
    /** @var array */
    private static $interface_cache = array();
    /** @var string */
    private $where_update_delete;
    /** @var string */
    private $ins_key;
    /** @var MySQLConnection */
    protected $_connection;
    /** @var string */
    protected $_name;
    /** @var string */
    protected $_prefix;
    /** @var string */
    protected $_cmd;
    /** @var boolean [description] */
    protected $_created_time;
    /** @var boolean [description] */
    protected $_updated_time;

    /**
     * @param $config
     */
    public static function config ($config)
    {
        if (is_object($config)) {
            if (get_class($config) == 'Glib_Configuration') {
                $config = $config->mysql;
            }
            self::$default_connection = new Glib_MySQLConnection($config->host, $config->username, $config->password, $config->database);
        }
    }

    public function __construct()
    {
        if (!$this->_connection) {
            $this->_connection = self::$default_connection;
        }
    }

    /**
     * @param $sql
     * @param array|null $param
     * @return mixed
     */
    public function query ($sql, array $param = null)
    {
        $sql = $this->getQuery($sql, $param);
        return new Glib_SqlFetcher($this->_connection, $sql);
    }

    /**
     * create or update
     * @param array $data
     * @param array $data_update
     * @return mixed
     */
    public function create (array $data, array $data_update = null)
    {
        $valid_prefix = is_null($this->_prefix) || is_scalar($this->_prefix);
        if (is_scalar($this->_name) && $valid_prefix && is_array($data)) {
            $table = $this->_prefix.$this->_name;
            $this->_cmd = "INSERT INTO `$table`";
            $field = $value = array();
            if (is_array($data)) {
                $this->addCreatedTime($data);
                foreach ($data as $f => $v) {
                    if (is_object($v) && isset($v->scalar)) {
                        $field[] = "`$f`";
                        $value[] = $v->scalar;
                    } elseif (!is_null($v) && !is_array($v) && !is_object($v) && trim($v) != '') {
                        $field[] = "`$f`";
                        $value[] = is_numeric($v) ? $v : ("N'" . escape_string($v) . "'");
                    }
                }
            }
            $this->_cmd .= " (" . implode(', ', $field) . ") VALUES (" . implode(", ", $value) . ")";
            if ($data_update !== null) {
                $upd = array();
                foreach ($data_update as $f => $v) {
                    if (is_object($v) && isset($v->scalar)) {
                        $upd[] = "`$f`=" . $v->scalar;
                    } elseif (!is_null($v) && !is_array($v) && !is_object($v)) {
                        $upd[] = "`$f`=" . (is_numeric($v) ? $v : ("N'" . escape_string($v) . "'"));
                    }
                }

                $this->_cmd .= " ON DUPLICATE KEY UPDATE " . implode(', ', $upd);
            }
            return $this->_connection->query($this->_cmd);
        } else {
            Glib_Log::open('app')->error('No table created OR no data created');
        }
        return false;
    }

    /**
     * @param array $data
     * @return mixed
     */
    public function insert (array $data)
    {
        $table = $this->_prefix.$this->_name;
        $ins_key = $this->insKey();
        if (is_scalar($table) && !empty($data)) {
            $this->getTableSchema();
            if (isset(self::$table_schema_cache[$table][self::$ins_tk])) {
                $data = array_map(function($array, $ins_tk, $ins_key) {
                    $array[$ins_tk] = $ins_key;
                    return $array;
                }, $data, array_fill(0, count($data), self::$ins_tk), array_fill(0, count($data), $ins_key));
            }
            $this->_cmd = "INSERT IGNORE `$table`";
            $values = array();
            $fields = null;
            foreach ($data as $array) {
                if ($fields === null && is_array($array)) {
                    $fields = implode(', ', array_map(function($v){
                        return '`'.$v.'`';
                    }, array_keys($array)));
                }
                if (is_array($array)) {
                    $values[] = implode(', ', array_map(function($value) {
                        if (is_object($value) && isset($value->scalar)) {
                            return $value->scalar;
                        }
                        if (is_scalar($value) && $value !== null) {
                            return is_numeric($value)? $value : ("N'".escape_string($value)."'");
                        }
                        return 'NULL';
                    }, array_values($array)));
                }
            }
            $this->_cmd.= ' ('. $fields .') VALUES ('. implode('), (', $values) .')';
            $result = $this->_connection->query($this->_cmd);
            if ($result) {
                $this->ins_key = $ins_key;
            }
            return $result;
        } else {
            /*throw new Exception("No table insert OR no field insert OR no data insert", 1);*/
        }
        return false;
    }

    public function where($sql_where, array $data = null)
    {
        $this->where_update_delete = $this->getQuery($sql_where, $data);
        return $this;
    }

    /**
     * @param array $data
     * @return mixed
     */
    public function update (array $data)
    {
        $valid_prefix = is_null($this->_prefix) || is_scalar($this->_prefix);
        if (is_scalar($this->_name) && $valid_prefix && is_array($data)) {
            $table = $this->_prefix.$this->_name;
            $this->_cmd = "UPDATE `$table` SET ";
            $field = $value = array();
            if (is_array($data)) {
                $this->addUpdatedTime($data);
                $set = array_filter(array_map(function($key, $value) {
                    if (is_object($value) && isset($value->scalar)) {
                        return '`'.$key.'` = '.$value->scalar;
                    }
                    if ($value === null) {
                        return '`'.$key.'` = NULL';
                    }
                    if (is_scalar($value)) {
                        return '`'.$key.'` = '. (is_numeric($value) ? $value : ("N'" . escape_string($value) . "'"));
                    }
                    return null;
                }, array_keys($data), $data));
                $this->_cmd.= implode(', ', $set);
            }
            if ($this->where_update_delete) {
                $this->_cmd.= ' WHERE '.$this->where_update_delete;
            }
            $this->where_update_delete = '';
            return $this->_connection->query($this->_cmd);
        } else {
            Glib_Log::open('app')->error('No table updated OR no data updated');
        }
        return false;
    }

    /**
     * delete
     * @return mixed
     */
    public function delete ()
    {
        $valid_prefix = is_null($this->_prefix) || is_scalar($this->_prefix);
        if (is_scalar($this->_name) && $valid_prefix) {
            $table = $this->_prefix.$this->_name;
            $this->_cmd = "DELETE FROM `$table`";
            if ($this->where_update_delete) {
                $this->_cmd.= ' WHERE '.$this->where_update_delete;
            }
            $this->where_update_delete = '';
            return $this->_connection->query($this->_cmd);
        }
        return false;
    }

    /**
     * [getTableSchema description]
     * @return array
     */
    public function getTableSchema ()
    {
        $table = $this->_prefix.$this->_name;
        if (isset(self::$table_schema_cache[$table])) {
            return self::$table_schema_cache[$table];
        }
        self::$table_schema_cache[$table] = array();
        $rs = $this->_connection->query("SELECT * FROM information_schema.columns WHERE table_schema = '".$this->_connection->getName()."' AND table_name = '$table'");
        while ($r = $this->_connection->fetchAssoc()) {
            self::$table_schema_cache[$table][$r['COLUMN_NAME']] = $r;
        }
        return self::$table_schema_cache[$table];
    }

    /**
     * @param array $callback
     * @return mixed
     */
    public function transaction (array $callback)
    {
        $this->_connection->beginTransaction();
        foreach ($callback as $call) {
            if (!is_callable($call)) {
                $this->_connection->rollback();
                return false;
            }
            if (!call_user_func_array($call, array($this))) {
                $this->_connection->rollback();
                return false;
            }
        }
        $this->_connection->commit();
        return true;
    }

    /**
     * @return string
     */
    public function toSql ()
    {
        return $this->_cmd;
    }

    /**
     * [getAffectedRows description]
     * @return int
     */
    public function affectedRows ()
    {
        return $this->_connection->affectedRows();
    }

    /**
     * [lastId description]
     * @return int
     */
    public function lastInsertId ()
    {
        return $this->_connection->insertId();
    }

    /**
     * [lastInsert return key insert multi record]
     * @return string
     */
    public function lastInsert ()
    {
        return $this->ins_key;
    }

    /**
     * [parseSchemaInputData return data ]
     * @param  array  $data [description]
     * @return array
     */
    public function parseSchemaInputData (array $data)
    {
        $this->getTableSchema();
        $table = $this->_prefix.$this->_name;
        return array_intersect_key($data, self::$table_schema_cache[$table]);
    }

    private function addCreatedTime(array &$data)
    {
        $this->getTableSchema();
        $table = $this->_prefix.$this->_name;
        if (isset(self::$table_schema_cache[$table][self::$created_time])) {
            if (!isset($data[self::$created_time]) || $data[self::$created_time] !== false) {
                $data[self::$created_time] = time();
            }
        }
    }

    private function addUpdatedTime(array &$data)
    {
        $this->getTableSchema();
        $table = $this->_prefix.$this->_name;
        if (isset(self::$table_schema_cache[$table][self::$updated_time])) {
            $data[self::$updated_time] = time();
            if (!isset($data[self::$updated_time]) || $data[self::$updated_time] !== false) {
                $data[self::$updated_time] = time();
            }
        }
    }

    private function insKey ()
    {
        $this->createNfdPattern();
        $s = '';
        $num = hexdec(uniqid());
        while ($num) {
            $m = $num % 95;
            $s = self::$nfd_pattern[$m] . $s;
            $num = floor($num / 95);
        }
        return $s;
    }

    /**
     * create ninety five decimal pattern
     */
    private function createNfdPattern()
    {
        if (self::$nfd_pattern === null) {
            self::$nfd_pattern = str_split('qazwertyuiop[]\\sdfghjkl;\'xcvbnm,./123`4567890-=QWERTYUIOP{ }|ASDFGHJKL:"ZXCVBNM<>?~!@#$%^&*()_+');
        }
    }

    private function addTablePrefix($matches)
    {
        if (empty($this->_prefix)) {
            return '`'. $matches[1] .'`';
        }

        return '`'. trim($this->prefix, '_') .'_'. $matches[1] .'`';
    }

    private function getQuery ($sql, array $param = null)
    {
        $sql = preg_replace_callback('/`?\{_([a-z][a-z0-9_]+)\}`?/', array($this, 'addTablePrefix'), $sql);
        if (!empty($param) && is_assoc_array($param)) {
            $list_keys = array();
            $list_values = array();

            foreach ($param as $key => $v) {
                $list_keys[] = '{$'. $key .'}';
                if (is_numeric($v)) {
                    $list_values[] = "'". $v ."'";
                } else {
                    $list_values[] = "'". escape_string($v) ."'";
                }
            }
            return str_replace($list_keys, $list_values, $sql);
        }
        return $sql;
    }
}
