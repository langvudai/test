<?php 
/**
 * summary
 */
class Glib_Do
{
    /**
     * @return mixed
     */
    public function run()
    {
        $ht = new HT();
        $method_name = $ht->method;
        $result = $this->invokeMethod($method_name, $ht);
        
        if ($result === false) {
            return false;
        }

        if (is_object($result) && get_class($result) === 'Glib_Template') {
            $result->render();
        } else {
            preg_match('/^(.*_)?([A-Z])([a-zA-Z0-9]*)?$/', get_class($this), $matches);
            $dir = strtolower($matches[2]) . $matches[3];
            $template = $dir .'/'. $this->refactoryLower($method_name);
            $template = new Glib_Template($template);

            if (is_array($result)) {
                $template->data($result);
            }
            
            $template->render();
        }
    }

    /**
     * @param  array $array
     * @return void
     */
    public function responseJson($array = null)
    {
        header('Content-type: application/json');
        exit(json_encode($array));
    }

    /**
     * @param  string $request_method
     * @param  string $method_name
     * @param  HT $ht
     * @return mixed
     */
    private function runMethod($request_method, $method_name, $ht)
    {
        if (method_exists($this, $request_method.'_'.$method_name)) {
            if ($request_method === 'GET') {
                return array($this->invokeMethod($request_method.'_'.$method_name, $ht), $method_name);
            }
            return array($this->invokeMethod($request_method.'_'.$method_name, $ht), $request_method.'_'.$method_name);
        }

        if (method_exists($this, $method_name)) {
            return array($this->invokeMethod($method_name, $ht), $method_name);
        }

        return null;
    }

    /**
     * invokeMethod: invoke if method is public
     * @param  string $method
     * @param  HT $ht
     * @return mixed
     */
    private function invokeMethod($method, $ht)
    {
    	try {
    		$reflection_method = new ReflectionMethod(get_class($this), $method);
    	} catch (Exception $exception) {
            Glib_Log::open('app')->error($exception->getMessage());
        }
        $reflection_method = new ReflectionMethod(get_class($this), $method);
        $parameters = $reflection_method->getParameters();
        $arguments = array();
        foreach ($parameters as $parameter) {
            $name = $parameter->getName();

            if (isset($ht->$name)) {
                $arguments[] = $ht->$name;
            } elseif ($parameter->getClass()) {
                $arguments[] = $parameter->getClass()->newInstance();
            } else {
                $arguments[] = null;
            }
        }
        
        if ($reflection_method->isPublic()) {
            return $reflection_method->invokeArgs($this, $arguments);
        }
        return null;
    }

    /**
     * @param  [type] $string [description]
     * @return [type]         [description]
     */
    private function refactoryLower($string)
    {
        return preg_replace_callback('/(([a-z0-9])([A-Z]))/', function ($matches) {
            return $matches[2].'_'.strtolower($matches[3]);
        }, $string);
    }
}