<?php 

/**
 * @method static objectName([$arguments|$key, $value])
 */
class Glib_Globals
{
	private static $globals = array();

	/**
     * @param  [type] $name      [description]
     * @param  [type] $arguments [description]
     * @return [type]            [description]
     */
    public static function __callStatic ($name, $arguments)
    {
		if (!isset(self::$globals[$name])) {
			$parameter = null;

    		if (count($arguments) == 2 && is_scalar($arguments[0])) {
    			$parameter[$arguments[0]] = $arguments[1];
    		} elseif (!empty($arguments)) {
    			$parameter = $arguments[0];
    		}

			self::$globals[$name] = new Glib_ObjectValue($parameter);
		} else {
			if (count($arguments) == 2 && is_scalar($arguments[0])) {
				self::$globals[$name]->$arguments[0] = $arguments[1];
			}

		}

		return self::$globals[$name];
    }
}