<?php

class Glib_Log
{
    public static $logs = array();
    private $fo;

    /**
     * @param $name
     * @param null $path
     * @return Glib_Log
     * @throws Exception
     */
    public static function open ($name, $path = null)
    {
        if ($path === null) {
            return isset(self::$logs[$name]) ? self::$logs[$name] : (new Glib_Log(null));
        }
        if (file_exists($path) && is_file($path)) {
            throw new Exception("Error $path exist and is file", 1);
        } else {
            if (!file_exists($path) || !is_dir($path)) {
                $dirs = explode('/', $path);
                $dir = '';
                for ($i = 0; $i < count($dirs); $i++) {
                    $dir .= '/' . $dirs[$i];
                    is_dir($dir) || mkdir($dir, 0775);
                }
                chmod($dir, 0775);
            } else {
                chmod($path, 0755);
            }
        }

        if (file_exists($path) && is_dir($path)) {
            $filename = $path .DIRECTORY_SEPARATOR. $name .date('-dmY').'.log';
            self::$logs[$name] = new Glib_Log($filename);
            return self::$logs[$name];
        }
    }

    /**
     * Log constructor.
     * @param null $fo
     */
    public function __construct ($filename)
    {
        if ($filename) {
            $fopen = fopen($filename,'a');
            if ($fopen) {
                $this->fo = $fopen;            
            }
        }
    }

    /**
     * @param $name
     * @param $arguments
     */
    public function __call ($name, $arguments)
    {
        if ($this->fo && $arguments) {
            $type = $name === 'push' ? '' : strtoupper($name);
            $content = trim(array_shift($arguments));

            if ($arguments) {
                $option = array_map('json_encode', $arguments);
            } else {
                $option = '';
            }
            
            @fwrite($this->fo, '['.date(DATE_RFC822)."] $type $content ".implode(' ', $option).PHP_EOL);
        }
    }

    /**
     *
     */
    public function __destruct ()
    {
        @fclose($this->fo);
        $this->fo = null;
    }
}
