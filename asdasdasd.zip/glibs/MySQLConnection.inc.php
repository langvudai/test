<?php
/**
 * 
 */
class Glib_MySQLConnection 
{
    private $host;
    private $user;
    private $pass;
    private $name;
    private $mysqli;
    private $close_connect;
    private $insert_id;
    private $affected_rows;
    private $num_rows;
    private $calc_rows;
    private $result_query;

    /**
     * Connection constructor.
     * @param $argument
     */
    public function __construct ($host, $username, $password, $database)
    {
        try {
            if (!ini_get('mysql.trace_mode')) {
                @ini_set('mysql.trace_mode', 1);
            }
        } catch (Exception $exception) {
            Glib_Log::open('app')->error($exception->getMessage());
        }
        $this->host = $host;
        $this->user = $username;
        $this->pass = $password;
        $this->name = $database;
        $this->mysqli = new \mysqli();
        $this->close_connect = true;
    }

    public function __destruct ()
    {
        $this->mysqli->close();
        $this->host = null;
        $this->user = null;
        $this->pass = null;
        $this->name = null;
        $this->mysqli = null;
        $this->close_connect = null;
    }

    /**
     * close
     * @return void
     */
    public function close()
    {
        $this->mysqli->close();
        $this->close_connect = true;
    }

    /**
     * @param $sql
     * @return mixed
     */
    public function query ($sql)
    {
        if ($this->mysqli->connect_error) {
            return array();
        }
        if ($this->close_connect) {
            $this->connect();
        }
        $is_select = preg_match('/^\s*select\s+(.*)$/is', $sql, $matches);
        if (ini_get('mysql.trace_mode') && $is_select) {
            $sql = 'SELECT SQL_CALC_FOUND_ROWS '.$matches[1];
        }
        $this->result_query  = $this->mysqli->query($sql);

        if ($this->result_query ) {
            $this->insert_id = $this->mysqli->insert_id;
            $this->affected_rows = $this->mysqli->affected_rows;
            $this->num_rows = $is_select ? $this->result_query->num_rows : 0;
            if (ini_get('mysql.trace_mode')) {
                $found_rows = $this->mysqli->query('SELECT FOUND_ROWS()')->fetch_assoc();
                $this->calc_rows = is_array($found_rows) && !empty($found_rows) ? array_shift($found_rows) : 0;
            }
            return true;
        } else {
            Glib_Log::open('app')->error('Mysql query '. $this->mysqli->errno .": ". $this->mysqli->error);
            return false;
        }
    }

    /**
     * @return array|null
     */
    public function fetchAssoc ()
    {
        return $this->result_query ? $this->result_query->fetch_assoc() : NULL;
    }

    /**
     * @return mixed
     */
    public function affectedRows ()
    {
        return $this->affected_rows;
    }

    /**
     * @return mixed
     */
    public function insertId ()
    {
        return $this->insert_id;
    }

    /**
     * @return mixed
     */
    public function numRows ()
    {
        return $this->num_rows;
    }

    /**
     * @return mixed
     */
    public function calcRows ()
    {
        $this->calc_rows;
    }

    /**
     * [getHost description]
     * @return string [description]
     */
    public function getHost()
    {
        return $this->host;
    }

    /**
     * [getUser description]
     * @return string [description]
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * [getName description]
     * @return string [description]
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * beginTransaction description
     * @return boolean
     */
    public function beginTransaction()
    {
        if (version_compare(PHP_VERSION, '5.5', '>=')) {
            if ($this->mysqli->begin_transaction()) {
                $this->is_transaction = true;
                return true;
            }
        } else {
            if ($this->mysqli->query('START TRANSACTION')) {
                $this->is_transaction = true;
                return true;
            }
        }

        $this->is_transaction = false;
        return false;
    }

    /**
     * commit description
     * @return boolean
     */
    public function commit()
    {
        if (version_compare(PHP_VERSION, '5.5', '>=')) {
            if ($this->mysqli->commit()) {
                $this->is_transaction = false;
                return true;
            }
        } else {
            if ($this->mysqli->query('COMMIT')) {
                $this->is_transaction = false;
                return true;
            }
        }

        return false;
    }

    /**
     * rollback description
     * @return boolean
     */
    public function rollback()
    {
        if (version_compare(PHP_VERSION, '5.5', '>=')) {
            if ($this->mysqli->rollback()) {
                $this->is_transaction = false;
                return true;
            }
        } else {
            if ($this->mysqli->query('ROLLBACK')) {
                $this->is_transaction = false;
                return true;
            }
        }

        return false;
    }

    /**
     * connect
     * @return boolean
     */
    private function connect()
    {
        if ($this->close_connect) {
            $this->mysqli->connect($this->host, $this->user, $this->pass, $this->name);
            if ($this->mysqli->connect_error) {
                Glib_Log::open('app')->error('Mysqli Connect Error: '. $this->mysqli->connect_error, array('code' => $this->mysqli->connect_errno));
            } else {
                mysqli_set_charset($this->mysqli,"utf8");
                $this->close_connect = false;
            }
        }
        return !$this->close_connect;
    }
}
