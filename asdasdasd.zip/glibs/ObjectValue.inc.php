<?php

class Glib_ObjectValue
{
    private static $interface_cache;
    private $value;

    public static function getInterface($object)
    {
        $class_name = get_class($object);
        if (!isset(self::$interface_cache[$class_name])) {
            $reflection_class = new ReflectionClass($class_name);
            self::$interface_cache[$class_name] = $reflection_class ? $reflection_class->getInterfaceNames() : array();
        }
        return self::$interface_cache[$class_name];
    }

    /**
     * [__construct description]
     * @param array|null $argument [description]
     */
    public function __construct (array $argument = null)
    {
        $this->value = $argument === null ? array() : $argument;
    }

    /**
     * [__get description]
     * @param  [type] $name [description]
     * @return [type]       [description]
     */
    public function __get ($name)
    {
        if (isset($this->value[$name])) {
            return $this->value[$name];
        }
        return null;
    }

    /**
     * [__isset description]
     * @param  [type]  $name [description]
     * @return boolean       [description]
     */
    public function __isset ($name)
    {
        return isset($this->value[$name]);
    }

    /**
     * [__set description]
     * @param [type] $name  [description]
     * @param [type] $value [description]
     */
    public function __set($name, $value)
    {
        $this->value[$name] = $value;
    }

    /**
     * [all description]
     * @return [type] [description]
     */
    public function all()
    {
        return $this->value;
    }

    /**
     * [flip description]
     * @return [type] [description]
     */
    public function flip()
    {
        if (is_array($this->value)) {
            return array_flip($this->value);
        }
        return null;
    }

    /**
     * @return mixed|null
     */
    public function first()
    {
        if (empty($this->value)) {
            return null;
        }
        return $this->value[key($this->value)];
    }
}
