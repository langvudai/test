<?php

/**
 * engine factory:
 * {@key parameters} option
 * {@function(parameters)} no echo
 * {$function(parameters)} echo
 * {$variable} echo
 *
 * .htphp (html + php)
 */
class Glib_Template 
{
    private static $template_dir;
    private static $compiler_dir = null;
    private static $label_src = null;
    protected static $DATA = array();
    protected $_id;
    protected $___;
    protected $template;
    protected $label;
    protected static $E=array();

    /**
     * @param  string $base_path [description]
     * @return void              [description]
     */
    public static function basePath($base_path)
    {
        self::$template_dir = $base_path;
    }

    /**
     * @param  string $path     [description]
     * @return void             [description]
     */
    public static function compilerDir($path)
    {
        self::$compiler_dir = $path;
    }

    /**
     * loadLabel
     * @param  string $label_src
     * @return void
     */
    public static function loadLabel($label_src)
    {
        self::$label_src = file_exists($label_src) && is_file($label_src) && is_readable($label_src) ? $label_src : null;
    }

    /**
     * [__construct description]
     * @param string     $template [description]
     * @param array|null $data     [description]
     */
    public function __construct($template, array $data=null)
    {
        $this->_id = uniqid();
        $this->template = $template;
        self::$DATA[$this->_id] = $data === null ? array() : $data;
        if (self::$label_src !== null) {
            $label = include_once self::$label_src;
            $this->label = is_array($label) ? $label : array();
        }
    }

    /**
     * [template description]
     * @param  string $template [description]
     * @return View
     */
    public function template($template)
    {
        $this->template = $template;
        return $this;
    }

    /**
     * [data description]
     * @param  array $data [description]
     * @return View
     */
    public function data(array $data)
    {
        self::$DATA[$this->_id] = $data;
    }

    /**
     * @param null $filename
     * @param array|null $data
     * @return mixed
     */
    public function render()
    {
        if ($this->isFileExist($this->template)) {
            extract(self::$DATA[$this->_id]);
            include_once $this->template;
        } elseif ($this->isFileExist(self::$template_dir .DS. $this->template.'.htphp')) {
            extract(self::$DATA[$this->_id]);
            include_once self::$template_dir .DS. $this->template.'.htphp';
        } elseif (!empty(self::$compiler_dir) && $this->isFileExist(self::$template_dir .DS. $this->template.'.html')) {
            $file = $this->templateEngine(self::$template_dir .DS. $this->template.'.html');
            extract(self::$DATA[$this->_id]);
            include_once $file;
        }
    }

    /**
     * magic method
     */
    public function __call($name, $value)
    {
        $method = 'magic'.strtoupper(substr($name, 0, 1)).substr($name, 1);
        if (method_exists($this, $method)) {
            call_user_func_array(array($this, $method), $value);
        }
    }

    public function __set($name, $value)
    {
        return false;
    }

    public function __toString()
    {
        return '<pre>'.PHP_EOL
        .'template_dir:'.self::$template_dir.'#'.(int)file_exists(self::$template_dir).PHP_EOL
        .'compiler_dir:'.self::$compiler_dir.'#'.(int)file_exists(self::$compiler_dir).PHP_EOL
        .'label_src:'.self::$label_src.'#'.(int)$this->isFileExist(self::$label_src).PHP_EOL
        .'id:'.$this->_id.PHP_EOL
        .'template:'.$this->template.'#'.(int)file_exists($this->template).PHP_EOL
        .'template:'.self::$template_dir .DS. $this->template.'.htphp#'.(int)file_exists(self::$template_dir .DS. $this->template.'.htphp').PHP_EOL
        .'template:'.self::$template_dir .DS. $this->template.'.html#'.(int)file_exists(self::$template_dir .DS. $this->template.'.html').PHP_EOL
        .'</pre>';
    }

    /**
     * magicLoadLayout magic method layout
     * @param  [type]  $layout [description]
     * @return [type] [description]
     */
    private function magicLoadLayout($layout)
    {
        if (file_exists($layout)) {
            $filename = $layout;
        } else {
            $filename = self::$template_dir .'/'. $layout.'.html';
        }
        if (file_exists($filename) && is_file($filename) && is_readable($filename)) {
            $filename = $this->templateEngine($filename, '0');
            extract(self::$DATA[$this->_id]);
            if (!empty($filename) && file_exists($filename)) {
                include_once $filename;
            }
        }
    }

    /**
     * [magicIncludeOnceEngine description]
     * @param  [type] $path [description]
     * @return [type]       [description]
     */
    private function magicIncludeOnceEngine($path)
    {
        if (file_exists($path)) {
            $filename = $path;
        } else {
            $filename = self::$template_dir .'/'. $path.'.html';
        }
        if (file_exists($filename) && is_file($filename) && is_readable($filename)) {
            $filename = $this->templateEngine($filename, '2');
            extract(self::$DATA[$this->_id]);
            if (!empty($filename) && file_exists($filename)) {
                include_once $filename;
            }
        }
    }

    /**
     * [magicIncludeEngine description]
     * @param  [type] $path [description]
     * @return [type]       [description]
     */
    private function magicIncludeEngine($path)
    {
        if (file_exists($path)) {
            $filename = $path;
        } else {
            $filename = self::$template_dir .'/'. $path.'.html';
        }
        if (file_exists($filename) && is_file($filename) && is_readable($filename)) {
            $filename = $this->templateEngine($filename, '2');
            extract(self::$DATA[$this->_id]);
            if (!empty($filename) && file_exists($filename)) {
                include $filename;
            }
        }
    }

    /**
     * [isFileExist description]
     * @param  [type]  $file [description]
     * @return boolean       [description]
     */
    private function isFileExist($file)
    {
        return file_exists($file) && is_file($file) && is_readable($file);
    }
    /**
     * [templateEngine description]
     * @param  [type] $inc   [description]
     * @param  string $level [description]
     * @return [type]        [description]
     */
    private function templateEngine($inc, $level='1')
    {
        $compiler_dir = realpath(self::$compiler_dir);
        if (!file_exists($compiler_dir) || !is_dir($compiler_dir)) {
            return $inc;
        }
        @chmod($compiler_dir, 0775);
        $mtime = dechex(filemtime($inc));
        $mtime_label = self::$label_src === null ? 0 : dechex(filemtime(self::$label_src));
        $filename = $level.md5(str_replace(DS, '', $inc));
        $file_compile = $compiler_dir .DS. $filename.$mtime.$mtime_label.'.php';
        if (true || !file_exists($file_compile)) {
            $glob_files = glob($compiler_dir .DS. $filename.'*.php');
            if (is_array($glob_files)) {
                foreach ($glob_files as $file) {
                    @unlink($file);
                }
            }
            if ($level==0) {
                $this->createEngineerLayout($inc, $file_compile);
            } else {
                $this->createEngineer($inc, $file_compile);
            }
        }
        return empty($file_compile) ? $inc : $file_compile;
    }

    /*
     * {@layout <path_to_template_layout> [$condition]} $condition: variable boolean
     * {@nominify} 
     * {@partition name} name [a-zA-Z0-9_\-\.]+
     * {@/partition} 
     */
    private function createEngineer($filename, &$file_compile)
    {
        $fopen = fopen($file_compile, 'w');
        if (!$fopen) {
            throw new Exception($file_compile.' is not permission');
        }
        $content = file_get_contents($filename);
        $nominify = preg_match('/\{@nominify\s*\}/is', $content);
        if ($nominify) {
            $content = preg_replace('/\{@nominify\s*\}/is', '', $content);
        }
        $content = preg_replace(array('/\\\\{/s', '/\\\\}/s'), array('&#123;', '&#125;'), $content);
        if (preg_match('/^(<!--)?\s*\{\@layout\s+([a-zA-Z0-9\-\.\/_]+)(\s+(\$[a-z][a-zA-Z0-9_]*))?\s*\}\s*(-->)?([\r\n])?/', $content, $matches)) {
            $layout_name = $matches[2];
            $layout_cond = empty($matches[4]) ? 'TRUE' : $matches[4];
            $content = str_ireplace($matches[0], '', $content);
        }
        $content = $this->engineContent($content);
        if (@$layout_name) {
            $content = '<?php if ('.$layout_cond.') { ob_start(); } ?>'. $content .'<?php if ('.$layout_cond.') { self::$E[$this->_id][\'content\'] = ob_get_clean(); $this->loadLayout( \''.addcslashes($layout_name, "'").'\' ); } ?>';
        }
        $content = $this->enginePartition($content);
        $content = preg_replace('/\{@\/partition\}/s', '', $content); 
        $content = preg_replace(array('/&#123;/s', '/&#125;/s'), array('{', '}'), $content);
        $result_write = fwrite($fopen, $nominify ? $content : preg_replace('/([\s\t]+)/', ' ', str_replace(PHP_EOL, '', $content)) );
        fclose($fopen);
        if ($result_write) {
            chmod($file_compile, 0644);
        } else {
            $file_compile = '';
        }
    }

    /*
     * {@nominify} 
     * {@content} 
     * {@load partition_name} partition_name [a-zA-Z0-9_\-\.]+
     */
    private function createEngineerLayout($filename, &$file_compile)
    {
        $fopen = fopen($file_compile, 'w');
        if (!$fopen) {
            throw new Exception($file_compile.' is not permission');
        }
        $content = file_get_contents($filename);
        $content = preg_replace(array('/\\\\{/s', '/\\\\}/s'), array('&#123;', '&#125;'), $content);
        $nominify = preg_match('/\{@nominify\s*\}/is', $content);
        if ($nominify) {
            $content = preg_replace('/\{@nominify\s*\}/is', '', $content);
        }
        $content = $this->engine_content($content);
        $content = preg_replace('/(<!--)?\s*\{\@content\}\s*(-->)?/is', '<?php echo self::$E[$this->_id][\'content\'] ?>', $content);
        $content = preg_replace('/(<!--)?\s*\{@load\s+([a-z0-9_\-\.]+)\}\s*(-->)?/i', '<?php if (isset(self::$E[$this->_id][\'part_\\2\'])) echo self::$E[$this->_id][\'part_\\2\']; ?>', $content);
        $content = preg_replace(array('/&#123;/s', '/&#125;/s'), array('{', '}'), $content);
        $result_write = fwrite($fopen, $nominify ? $content : preg_replace('/([\s\t]+)/', ' ', str_replace(PHP_EOL, '', $content)) );
        fclose($fopen);
        if ($result_write) {
            chmod($file_compile, 0644);
        } else {
            $file_compile = '';
        }
    }

    /*
     * {@partition name} name [a-zA-Z0-9_\-\.]+
     * {@/partition} 
     */
    private function enginePartition ( $content ) 
    {
        $i = stripos($content, '{@partition ');
        $j = stripos($content, '{@/partition}', $i);
        while ($i>-1 && $j>$i) {
            $partition = substr($content, $i, $j-$i);
            preg_match('/\{@partition\s+([a-zA-Z0-9_\-\.]+)\}/s', $partition, $matches);
            $partition = '<?php ob_start(); ?>'.$partition.'<?php self::$E[$this->_id][\'part_'.$matches[1].'\']=ob_get_clean() ?>';
            $partition = preg_replace('/\{@partition\s+([a-zA-Z0-9_\-\.]+)\}/s', '', $partition); 
            $content = $partition.substr($content, 0, $i).substr($content, $j);
            $i = stripos($content, '{@partition ', $j);
            $j = stripos($content, '{@/partition}', $i);
        }
        return $content;
    }

    /*
     * {@label ....}
     * {@var $variable=}
     * {@if ...}
     * {@/if}
     * {@for ...}
     * {@/for}
     * {@foreach ...}
     * {@/foreach}
     * {@while ...}
     * {@/while}
     * {@function(parameters)} no echo
     * {$function(parameters)} echo
     * {$variable} echo
     * {@$variable} no echo
     * {@include path} include path [a-zA-Z0-9\-\.\/_]+)
     * {@include_once path} include_once path [a-zA-Z0-9\-\.\/_]+)
     */
    private function engineContent($content)
    {
        $content = preg_replace_callback('/\{@label\s+([\wàáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ][^\{\r\n\}]+)\s*\}/is', array($this, 'engineLabel'), $content);
        $content = preg_replace(array(
            '/\<\?php([\s\n\r])/is', 
            '/\{\?php\}/is', 
            '/\{\?\/php\}/is', 
            '/\{\?\@([^\{\r\n\}]+)\}/s', 
            '/\{\?\=([^\{\r\n\}]+)\}/s', 
        ), array(
            '&lt;?php\\1', 
            '<?php ', 
            ' ?>', 
            '<?php \\1; ?>', 
            '<?php echo( \\1 );?>', 
        ), $content);
        $content = preg_replace('/\{@var\s+\$([a-z][a-zA-Z0-9_])\s*\=([^\{\r\n\}]+)\}/', '<?php $\\1 = \\2; ?>', $content);

        $content = preg_replace(array(
            '/(\{@if\s([^\{\r\n\}]+)\})/is', 
            '/(\{@else\s([^\{\r\n\}]+)\})/is', 
            '/(\{@else\})/is', 
            '/(\{@\/if\})/is', 
            '/(\{@foreach\s([^\{\r\n\}]+)\})/is', 
            '/(\{@\/foreach\})/is', 
            '/(\{@for\s([^\{\r\n\}]+)\})/is', 
            '/(\{@\/for\})/is', 
            '/(\{@while\s([^\{\r\n\}]+)\})/is', 
            '/(\{@\/while\})/is', 
        ), array(
            '<?php if( \\2 ): ?>', 
            '<?php elseif( \\2 ): ?>', 
            '<?php else: ?>', 
            '<?php endif; ?>', 
            '<?php foreach( \\2 ): ?>', 
            '<?php endforeach; ?>', 
            '<?php for( \\2 ): ?>', 
            '<?php endfor; ?>', 
            '<?php while( \\2 ): ?>', 
            '<?php endwhile; ?>', 
        ), $content);

        $content = preg_replace_callback('/\{@([a-z][a-zA-Z0-9_]*)\(([^\{\r\n\}]*)\)\s*\}/', array($this, 'callFunction'), $content);
        $content = preg_replace_callback('/\{\$([a-z][a-zA-Z0-9_]*)\(([^\{\r\n\}]*)\)\s*\}/', array($this, 'echoCallFunction'), $content);
        $content = preg_replace('/\{(\$[a-z][^\{\r\n\}]*)\}/', '<?php echo \\1; ?>', $content);
        $content = preg_replace('/\{\@(\$[a-z][^\{\r\n\}]*)\}/', '<?php \\1; ?>', $content);
        $content = preg_replace_callback('/(\{\@(include|include_once)\s+([a-zA-Z0-9\-\.\/_]+)\})/s', array($this, 'engineInclude'), $content);
        return $content;
    }

    private function engineLabel($matches)
    {
        if (isset($this->label[$matches[1]])) {
            return $this->label[$matches[1]];
        }
        return $matches[1];
    }

    private function callFunction($matches)
    {
        if (function_exists($matches[1])) {
            return '<?php '.$matches[1].' ('.$matches[2].'); ?>';
        }
        return '';
    }

    private function echoCallFunction($matches)
    {
        if (function_exists($matches[1])) {
            return '<?php echo '.$matches[1].' ('.$matches[2].'); ?>';
        }
        return '';
    }

    private function engineInclude($matches)
    {
        if ($matches[2] == 'include') {
            return '<?php $this->includeEngine(\''.$matches[2].'\');?>';
        }
        return '<?php $this->includeOnceEngine(\''.$matches[2].'\');?>';
    }
}