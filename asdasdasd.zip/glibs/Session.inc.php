<?php 

if (!class_exists('Glib_Session') && defined('USE_SESSION_FILE') && USE_SESSION_FILE) {
    class Glib_Session
    {
        private static $ssid, $path, $value=array(), $timeout;

        private static function fwrite_stream($fp, $string) {
            for ($written = 0; $written < strlen($string); $written += $fwrite) {
                $fwrite = fwrite($fp, substr($string, $written));
                if ($fwrite === false) {
                    return $written;
                }
            }
            return $written;
        }

        private static function write_session()
        {
            $file = self::$path ? (self::$path . '/' .self::$ssid) : self::$ssid;
            $s = serialize(self::$value);
            $i = rand(strpos($s, '{') , strrpos($s, ';'));
            $i = strpos($s, ';', $i);
            $s = substr($s, 0, $i).';s:5:""'.substr($s, $i);
            if (@is_writable($file)) {
                $fp = fopen ( $file , 'wb' );
                self::fwrite_stream ( $fp, $s);
                fclose($fp);
            } else {
                $fp = fopen ( $file , 'wb' );
                self::fwrite_stream ( $fp, $s);
                fclose($fp);
                chmod($file, 0600);
            }
        }

        private static function read_session()
        {
            $file = self::$path ? (self::$path . '/' .self::$ssid) : self::$ssid;
            if (@is_readable($file) && filesize($file)) {
                $filetime = filemtime($file) ? filemtime($file) : filectime($file);
                if ($filetime + self::$timeout > time()) {
                    $fp = fopen ( $file , 'rb' );
                    $contents = fread($fp, filesize($file));
                    fclose($fp);
                    @$res = unserialize(str_ireplace(';s:5:""', '', $contents));
                    if ($res !== false) {
                        self::$value = $res;
                    } else {
                        self::$value = array();
                    }
                } else {
                    self::$value = array();
                }
            } else {
                self::$value = array();
            }
        }

        private static function is_life_session()
        {
            $file = self::$path ? (self::$path . '/' .self::$ssid) : self::$ssid;
            if (@is_readable($file)) {
                $filetime = filemtime($file) ? filemtime($file) : filectime($file);
                if ($filetime + self::$timeout > time()) {
                    return true;
                }
            }
            return false;
        }

        public static function start($path='', $timeout = 3600, $id='')
        {
            ini_set('session.cookie_lifetime', 86400);
            ini_set('session.gc_maxlifetime', 86400);
            session_name('ht_ss_'.dechex(filemtime(__FILE__)));
            @session_start(); 
            self::$ssid = $id ? $id : session_id();
            ($path && !file_exists($path)) && @mkdir($path);
            if ($path && @is_dir($path)) {
                self::$path = $path;
            } else {
                @is_dir(dirname(__FILE__).'/sesiond'.filemtime(__FILE__)) || mkdir(dirname(__FILE__).'/sesiond'.filemtime(__FILE__));
                self::$path = dirname(__FILE__).'/sesiond'.filemtime(__FILE__);
            }
            self::$timeout = $timeout;
            self::read_session();
            count(self::$value) && self::write_session();
            return self::$ssid;
        }
        
        public static function set($id, $value)
        {
            self::$value[$id] = $value;
            self::write_session();
            return true;
        }

        public static function exist($id)
        {
            return self::is_life_session() && isset(self::$value[$id]);
        }

        public static function get($id){
            if (self::is_life_session()) {
                return isset(self::$value[$id]) ? self::$value[$id] : NULL;
            }
            return NULL;
        }
        
        public static function delete($id){
            if (self::is_life_session()) {
                unset(self::$value[$id]);
                self::write_session();
            }
        }
        
        public static function destroy()
        {
            $file = self::$path ? (self::$path . '/' .self::$ssid) : self::$ssid;
            if (file_exists($file) && is_writable($file)) {
                unlink($file);
            }
            self::$value = array();
            self::write_session();
            session_destroy();
        }

        public function __set($name, $value){self::set($name, $value);}
        public function __get($name){return self::get($name);}
    }
} elseif (!class_exists('Glib_Session')) {
    class Glib_Session
    {
        private static $id, $sb, $value=array(), $timeout;

        public static function start($timeout = 3600)
        {
            session_name('ht_ss_'.dechex(filemtime(__FILE__)));
            @session_start(); 
            self::$timeout = (int)$timeout ? (int)$timeout : 3600;
            self::$id = '__ID_'.filemtime(__FILE__);
            self::$sb = '_'.filemtime(__FILE__);
            $_SESSION[self::$sb]=time();
            if ($_SESSION[self::$sb] + self::$timeout > time() && isset($_SESSION[self::$id])) {
                $res = unserialize(self::d($_SESSION[self::$id]));
                if ($res !== false) {
                    self::$value = $res;
                }
            }
        }
        private static function e($s)
        {
            $i = rand(strpos($s, '{') , strrpos($s, ';'));
            $i = strpos($s, ';', $i);
            return substr($s, 0, $i).';s:5:""'.substr($s, $i);
        }
        private static function d($string)
        {
            return str_ireplace(';s:5:""', '', $string);
        }

        public static function set($id, $value)
        {
            self::$value[$id] = $value;
            $_SESSION[self::$id] = self::e(serialize(self::$value));
            $_SESSION[self::$sb] = time();
            return true;
        }

        public static function exist($id)
        {
            if ($_SESSION[self::$sb] + self::$timeout > time()) {
                $_SESSION[self::$sb]=time();
                return isset(self::$value[$id]);
            }
            return false;
        }

        public static function get($id){
            if ($_SESSION[self::$sb] + self::$timeout > time()) {
                $_SESSION[self::$sb]=time();
                return isset(self::$value[$id]) ? self::$value[$id] : NULL;
            }
            return NULL;
        }
        
        public static function delete($id){
            if ($_SESSION[self::$sb] + self::$timeout > time()) {
                $_SESSION[self::$sb]=time();
                if (isset(self::$value[$id])) {
                    unset(self::$value[$id]);
                    $_SESSION[self::$id] = self::e(serialize(self::$value));
                }
            }
        }
        
        public static function destroy()
        {
            session_destroy();
        }

        public function __set($name, $value){self::set($name, $value);}
        public function __get($name){return self::get($name);}
    }
}