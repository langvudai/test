<?php

/**
 * 
 */
class Glib_SqlFetcher 
{
    private $resource;
    private $sql;

    /**
     * @param [type] $a [description]
     * @param [type] $b [description]
     */
    public function __construct ($a, $b)
    {
        if (is_object($a) && get_class($a) == 'Glib_MySQLConnection') {
            $this->resource = null;
            if(is_string($b)) {
                $b = preg_replace('/([^\\\\])(;)/', "$1\\\\$2", $b);
                $this->sql = $b;
                if ($a->query($this->sql)) {
                    if (preg_match('/^select/i',$this->sql)) {
                        if ($a->numRows() > 0) {
                            $this->resource = $a;
                        }
                    }
                }
            }
        }
    }

    /**
     * [fetch description]
     * @param  string  $field_key [description]
     * @param  boolean $group     [description]
     * @return [type]             [description]
     */
    public function fetch ($field_key = null, $group=false)
    {
        if ($this->resource) {
            $rt = array();
            $row = $this->resource->fetchAssoc();
            $row = array_map('stripcslashes', $row);
            if (!is_null($field_key) && isset($row[$field_key]) && $row[$field_key]!='') {
                if ($group) {
                    $rt[$row[$field_key]][] = $row;
                    while ($row = $this->resource->fetchAssoc()) {
                        $row = array_map('stripcslashes', $row);
                        $rt[$row[$field_key]][] = $row;
                    }
                } else {
                    $rt[$row[$field_key]] = $row;
                    while ($row = $this->resource->fetchAssoc()) {
                        $row = array_map('stripcslashes', $row);
                        $rt[$row[$field_key]] = $row;
                    }
                }
            } else {
                $rt[] = $row;
                while ($row = $this->resource->fetchAssoc()) {
                    $row = array_map('stripcslashes', $row);
                    $rt[] = $row;
                }
            }
            return $rt;
        }
        return null;
    }

    /**
     * @return mixed
     */
    public function fetchRow ()
    {
        if ($this->resource) {
            $rt = array();
            $row = $this->resource->fetchAssoc();
            $row = array_map('stripcslashes', $row);
            return $row;
        }
        return null;
    }

    /**
     * [fetchArrayKey description]
     * @param  [type] $field_value [description]
     * @param  [type] $field_key   [description]
     * @return [type]              [description]
     */
    public function fetchArrayKey ($field_value = null, $field_key = null)
    {
        if ($this->resource && empty($field_key)) {
            $rt = array();
            $point = NULL;
            while ($row = $this->resource->fetchAssoc()) {
                $row = array_map('stripcslashes', $row);
                $i = 1;
                if (!empty($field_value) && isset($row[$field_value])) {
                    $value = $row[$field_value];
                    unset($row[$field_value]);
                } else {
                    $value = 1;
                }
                $cn = count($row);
                foreach ($row as $k=>$v) {
                    if (is_null($point) || $i==1) {
                        if (!isset($rt["$v"])) {
                            $rt["$v"] = $i==$cn ? $value : array();
                        }
                        $point = &$rt[$v];
                    } else {
                        if (!isset($point["$v"])) {
                            $point["$v"] = $i==$cn ? $value : array();
                        }
                        $point = &$point[$v];
                    }
                    $i++;
                }
            }
            return $rt;
        } elseif ($this->resource && !empty($field_value)) {
            $col = array_diff(array_map('trim', explode(',', $field_key)), array($field_value));
            $rt = array();
            $p = null;
            while ($r = $this->resource->fetchAssoc()) {
                $r = array_map('stripcslashes', $r);
                foreach ($col as $i => $c) {
                    if ($i == 0) {
                        if (!isset($rt[$r[$c]])) {
                            $rt[$r[$c]] = array();
                        }
                        $p = &$rt[$r[$c]];
                    } else {
                        if (!isset($p[$r[$c]])) {
                            $p[$r[$c]] = array();
                        }
                        $p = &$p[$r[$c]];
                    }
                }
                $p = $r[$field_value];
            }
            return $rt;
        }
        return null;
    }

    /**
     * @param $column
     * @param null $key
     * @param bool $group
     * @return mixed
     */
    public function fetchOnce ($column, $key = null, $group = false)
    {
        if ($this->resource) {
            $rt = array();
            if ($key) {
                if ($group) {
                    while ($row = $this->resource->fetchAssoc()) {
                        $row = array_map('stripcslashes', $row);
                        if (isset($row[$column]) && isset($row[$key])) {
                            $rt[$row[$key]][] = $row[$column];
                        }
                    }
                } else {
                    while ($row = $this->resource->fetchAssoc()) {
                        $row = array_map('stripcslashes', $row);
                        if (isset($row[$column]) && isset($row[$key])) {
                            $rt[$row[$key]] = $row[$column];
                        }
                    }
                }
            } else {
                while ($row = $this->resource->fetchAssoc()) {
                    $row = array_map('stripcslashes', $row);
                    if (isset($row[$column])) {
                        $rt[] = $row[$column];
                    }
                }
            }
            return $rt;
        }
        return null;
    }

    public function toSql()
    {
        return $this->sql;
    }
}
