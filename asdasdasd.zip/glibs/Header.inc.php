<?php 
class Glib_Header
{
    /**
     * [setHeaderTextPlain description]
     */
    public static function setHeaderTextPlain()
    {
        header('Content-Type: text/plain');
    }

    /**
     * [setHeaderJson description]
     */
    public static function setHeaderJson()
    {
        header('Content-type: application/json');
    }

    /**
     * [setHeaderXML description]
     */
    public static function setHeaderXML()
    {
        header("Content-Type: application/xml; charset=utf-8");
    }

    /**
     * [setHeaderDownloadFile description]
     * @param [type]  $attachFileName [description]
     * @param integer $fileSize       [description]
     */
    public static function setHeaderDownloadFile($attachFileName, $fileSize=0)
    {
        header("Content-Disposition: attachment; filename=" . $attachFileName);
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Description: File Transfer");
        if ($fileSize>0) {
            header("Content-Length: " . $fileSize);
        }
    }

    /**
     * 
     * set header 403
     * @param $html_or_path 
     */
    public static function setHeader403($html_or_path='')
    {
        header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden', true, 403);

        if (is_readable($html_or_path) && is_file($html_or_path)) {
            $html = include $html_or_path;
            exit($html);
        } else {
            exit($html_or_path);
        }
    }

    /**
     * 
     * set header 404
     * @param $html_or_path 
     */
    public static function setHeader404($html_or_path='')
    {
        header($_SERVER['SERVER_PROTOCOL'] . ' 404 Page not found', true, 404);
        
        if (is_readable($html_or_path) && is_file($html_or_path)) {
            exit(include $html_or_path);
        } else {
            exit($html_or_path);
        }
    }

    /**
     * 
     * set header 500
     * @param $html_or_path 
     */
    public static function setHeader500($html_or_path='')
    {
        header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500);

        if (is_readable($html_or_path) && is_file($html_or_path)) {
            exit(include $html_or_path);
        } else {
            exit($html_or_path);
        }
    }
}
