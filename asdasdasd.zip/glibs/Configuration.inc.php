<?php

class Glib_Configuration
{
    private static $configs = array();
    private $config;

    /**
     * [load description]
     * @param  [type] $filename [description]
     * @return [type]           [description]
     */
    public static function load($filename)
    {
        if (empty(self::$configs) && file_exists($filename) && is_file($filename) && is_readable($filename)) {
            $current = pathinfo($filename, PATHINFO_FILENAME);
            $current_dir = dirname($filename);
            $dirs = array($current_dir);
            while ($dir = array_shift($dirs)) {
                $key = ltrim(str_replace($current_dir, '', $dir), '/');
                if (!empty($key)) {
                    $key = str_replace('/', '.', $key).'.';
                }
                $d = dir($dir);
                while (false !== ($entry = $d->read())) {
                    $file = $entry !== '.' && $entry !== '..' ? realpath($dir. DS .$entry) : null;
                    if ($file && is_dir($file)) {
                        $dirs[] = $file;
                    } elseif ($file && is_file($file) && is_readable($file)) {
                        $name = pathinfo($entry, PATHINFO_FILENAME);
                        self::$configs[$key.$name] = $file;
                    }
                }
                $d->close();
            }
            self::$configs[$current] = new Glib_Configuration(self::$configs[$current]);
        }
    }

    /**
     * [get description]
     * @param  string $name [description]
     * @return [type]       [description]
     */
    public static function get ($name = null)
    {
        if ($name === null) {
            $name = key(self::$configs);
        }
        if (isset(self::$configs[$name]) && is_object(self::$configs[$name])) {
            return self::$configs[$name];
        }
        if (isset(self::$configs[$name]) && is_scalar(self::$configs[$name])) {
            self::$configs[$name] = new Configuration(self::$configs[$name]);
            return self::$configs[$name];
        }
        return null;
    }

    public function __construct($file_patch)
    {
        $array = include_once $file_patch;
        if (is_array($array)) {
            $collection = array();
            foreach ($array as $key => $value) {
                if (is_callable($value)) {
                    $collection[$key] = $value;
                    unset($array[$key]);
                }
                if (is_array($value)) {
                    $array[$key] = new Glib_ObjectValue($value);
                }
            }

            foreach ($collection as $key => $call) {
                $value = call_user_func_array($call, array($array));
                if (!empty($value)) {
                    $array[$key] = $value;
                }
            }
        }
        if (!empty($array)) {
            $this->config = $array;
        }
    }

    /**
     * [__get description]
     * @param  [type] $name [description]
     * @return [type]       [description]
     */
    public function __get($name)
    {
        if (isset($this->config[$name])) {
            if (is_array($this->config[$name])) {
                return new Glib_ObjectValue($this->config[$name]);
            }
            return $this->config[$name];
        }
        return isset($this->config[$name]) ? $this->config[$name] : null;
    }

    /**
     * [__isset description]
     * @param  [type]  $name [description]
     * @return boolean       [description]
     */
    public function __isset($name)
    {
        return isset($this->config[$name]);
    }

    /**
     * [__toString description]
     * @return string [description]
     */
    
    public function __toString()
    {
        return json_encode($this->config);
    }

    public function __set($n, $value)
    {
        return false;
    }
}
