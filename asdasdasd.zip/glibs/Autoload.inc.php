<?php 

class Glib_Autoload
{
	private static $registered = array();
	private $prefix;
	private $path;
	private $filename;

	/**
	 * [init description]
	 * @return [type] [description]
	 */
	public static function init($prefix, $path)
	{
		if (!isset(self::$registered[$prefix])) {
            self::$registered[$prefix] = new Glib_Autoload($prefix, $path);
        }
	}
	
	/**
	 * [__construct description]
	 */
	public function __construct($prefix, $path)
	{
		$this->prefix = '_'.trim($prefix).'_';
		$this->path = $path;
		spl_autoload_register(array($this, 'includeOnceIfMatchPrefix'));
	}

	private function includeOnceIfMatchPrefix($class)
	{
		$paths = $this->getPathArray('__'.$class);
		$end = end($paths);
		unset($paths[key($paths)]);
		$filename = $this->path.DIRECTORY_SEPARATOR.implode(DIRECTORY_SEPARATOR, array_map(function($value) {
			return preg_replace(array('/^(.*([sxz]|ch|sh))$/', '/^(.*[^aeiou])y$/', '/^.*[^s]$/'), array('\\1es', '\\1ies', '\\0s'), strtolower($value));
		}, $paths)).DIRECTORY_SEPARATOR.$end;
		
		if ($this->existFile($filename, '.inc.php') || $this->existFile($filename, '.php')) {
			include_once $this->filename;
		}
	}

	private function getPathArray($class)
	{
		$i = stripos($class, $this->prefix);
		if ($i) {
			return explode('_', substr($class, $i + strlen($this->prefix)));
		}

		return array();
	}

	/**
	 * [existFile description]
	 * @param  [type] $filename  [description]
	 * @param  [type] $extension [description]
	 * @return [type]            [description]
	 */
	private function existFile($filename, $extension)
	{
		$filename = ($filename.$extension);

		if ($filename && file_exists($filename) && is_file($filename) && is_readable($filename)) {
			$this->filename = $filename;
			return true;
		}

		return false;
	}
}
