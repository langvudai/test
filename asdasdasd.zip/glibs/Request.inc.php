<?php

/**
 * summary
 */
class Glib_Request
{
    private static $uri_start;
    private static $request_uri = null;
    private $_request;

    const FILE = 'FILE';
    const POST = 'POST';
    const GET = 'GET';

    public static function getUri()
    {
        $u = explode('?', $_SERVER['REQUEST_URI']);
        $php_self = urldecode($_SERVER['PHP_SELF']);
        if (stripos($u[0], 'index.php')) {
            self::$uri_start = substr($u[0], 0, strpos($u[0], 'index.php')).'index.php';
            self::$request_uri = substr($u[0], strlen(self::$uri_start));
        } else {
            self::$uri_start = substr($php_self,0, stripos($php_self, 'index.php')-1);
            self::$request_uri = substr($u[0], strlen(self::$uri_start));
        }
        return self::$request_uri;
    }

    public static function getMethod()
    {
        if (strtoupper($_SERVER['REQUEST_METHOD']) === 'POST' && isset($_POST['_method'])) {
            $method = strtoupper($_POST['_method']);
            unset($_POST['_method']);
            return $method;
        }
        return strtoupper($_SERVER['REQUEST_METHOD']);
    }

    /**
     * summary
     */
    public function __construct($method='GET')
    {
        if ($method === 'FILE') {
            $this->_request = $this->getFiles();
        } else {
            $_method = self::getMethod();
            if ($_method === $method) {
                if ($method === 'GET') {
                    $this->_request = $_GET;
                } else {
                    $this->_request = $_POST;
                }
            } else {
                $this->_request = null;
            }
        }
    }

    public function __get($name)
    {
        return isset($this->_request[$name]) ? $this->_request[$name] : NULL;
    }

    public function all()
    {
        return $this->_request;
    }

    private function getFiles()
    {
        $request = array();
        foreach ($_FILES as $name => $value) {
            if (is_array($value['name'])) {
                $request[$name] = array();
                foreach ($value['error'] as $i => $error) {
                    if ($error) {
                        return array($name => (object)array('error'=>$error));
                    }
                    $request[$name][] = (object)array(
                        'name' => $value['name'][$i],
                        'type' => $value['type'][$i],
                        'tmp_name' => $value['tmp_name'][$i],
                        'size' => $value['size'][$i],
                        'filename' => pathinfo($value['name'][$i], PATHINFO_FILENAME),
                        'extension' => pathinfo($value['name'][$i], PATHINFO_EXTENSION),
                    );
                }
            } else {
                if ($value['error']) {
                    return array($name => (object)array('error'=>$value['error']));
                }
                $request[$name] = (object)array(
                    'name' => $value['name'],
                    'type' => $value['type'],
                    'tmp_name' => $value['tmp_name'],
                    'size' => $value['size'],
                    'filename' => pathinfo($value['name'], PATHINFO_FILENAME),
                    'extension' => pathinfo($value['name'], PATHINFO_EXTENSION),
                );
            }
        }
        return $request;
    }
}
