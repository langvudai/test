;
function isElement (obj) {
    try {
        return obj instanceof HTMLElement;
    } 
    catch(e) {
        return (typeof obj==="object") && (obj.nodeType===1) && (typeof obj.style === "object") && (typeof obj.ownerDocument ==="object");
    }
}
/*var contentp = '<section class="wrap-popup"><div class="popup"><div class="top-popup clearfix"><a href="#" title="" class="logo"><img src="images/img2.png" alt=""></a><h2 class="name">Steven Nguyen <span class="live">has a post scheduded go live</span></h2><p class="time fl">March 25, 2018, at 09:00 AM</p><div class="social fr"><a href="#" title=""><img src="images/Ellipse.png" alt=""></a><a href="#" title=""><img src="images/Ellipse.png" alt=""></a><a href="#" title=""><img src="images/Ellipse.png" alt=""></a><a href="#" title=""><img src="images/Ellipse.png" alt=""></a><a href="#" title=""><img src="images/Ellipse.png" alt=""></a></div></div><div class="content-popup clearfix"><h3 class="title">Nàng "Hiểu Phương" của "Tháng năm rực rỡ" vừa bật mí loạt hình mới toanh, đa sắc của mình.</h3><article><a href="#" title="" class="logo"><img src="images/thumb.png" alt="" class="thumb"></a><div class="cp-left fl"><h3 class="title">Hoàng Yến Chibi: ‘Không ai kín cổng cao tường mãi, tôi cũng vậy!’</h3><p class="sapo">Sau thành công từ bộ phim Tháng năm rực rỡ với vai Hiểu Phương nhận được nhiều sự yêu mến, Hoàng Yến Chibi càng có thêm động lực để bắt tay vào thực hiện...</p></div></article></div><div class="bottom-popup clearfix"><div class="box-post fr"><a href="" title="" class="btn-pri btn-del"><img src="images/del.png" alt=""></a><a href="" title="" class="btn-pri btn-edit"><img src="images/edit.png" alt=""></a><a href="" title="" class="btn-pos">Post Now</a></div></div><a class="btn-close" click="closeShowpoupcalendar"><img src="images/Close.png" alt=""></a></div></section>';*/

/*var pdtCalenderPopupPosition = {};*/
window.pdtCalender = function(selectorStr, options) {
	this.get=function(e){var t="string"==typeof e.url?e.url:null,n="function"==typeof e.done?e.done:function(){},s="function"==typeof e.fail?e.fail:function(){};if(null!=t){var l=window.XMLHttpRequest?new XMLHttpRequest:window.ActiveXObject?new ActiveXObject("Microsoft.XMLHTTP"):null;l&&(l.onreadystatechange=function(){if(4==l.readyState)if(200==l.status)if(null!=l.responseXML)n.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),n.call(this,json)}catch(e){n.call(this,l.responseText)}else if(null!=l.responseXML)s.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),s.call(this,json)}catch(e){s.call(this,l.responseText)}},l.open("GET",t,!0),l.send(null))}};
	if (document.querySelector(selectorStr)) {
		this.selector = document.querySelector(selectorStr);
		this.selector.innerHTML = '';
		var tmp = document.querySelector(selectorStr);
		this.offsetLeftBody = tmp.offsetLeft;
		this.offsetTopBody = tmp.offsetTop;
		while(tmp.offsetParent.tagName!='BODY') {
			tmp = tmp.offsetParent;
			this.offsetLeftBody = tmp.offsetLeft;
			this.offsetTopBody = tmp.offsetTop;
		}
		this.popupContent=null;
		this.popupContentWidth=505;
		this.popupContentHeight=340;
		this.popupMoreOn=false;
		this.dateItems={};
		this.notes={};
		var self=this, settings={}, i, j, 
		regYmd=/^\d\d\d\d\-(0\d|1[0-2])\-([012]\d|3[01])$/,
		regVNtime=/^([012]\d|3[01])\/(0\d|1[0-2])\/\d\d\d\d\s+[012]?\d\:\d\d\:\d\d$/,
		days = [[], [1,'MON'], [2,'TUE'], [3,'WED'], [4,'THU'], [5,'FRI'], [6,'SAT'], [0,'SUN']],
		defMonth = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
		defHour =[
			[{time:'05:00 AM', v:5}, {time:'06:00 AM', v:6}],
			[{time:'07:00 AM', v:7}, {time:'08:00 AM', v:8}],
			[{time:'09:00 AM', v:9}, {time:'10:00 AM', v:10}],
			[{time:'11:00 AM', v:11}, {time:'12:00 PM', v:12}],
			[{time:'01:00 PM', v:13}, {time:'02:00 PM', v:14}],
			[{time:'03:00 PM', v:15}, {time:'04:00 PM', v:16}],
			[{time:'05:00 PM', v:17}, {time:'06:00 PM', v:18}],
			[{time:'07:00 PM', v:19}, {time:'08:00 PM', v:20}],
			[{time:'09:00 PM', v:21}, {time:'10:00 PM', v:22}],
			[{time:'11:00 PM', v:23}, {time:'12:00 AM', v:24}],
			[{time:'01:00 AM', v:1}, {time:'02:00 AM', v:2}],
			[{time:'03:00 AM', v:3}, {time:'04:00 AM', v:4}],
		],
		table=document.createElement('table'),
		thead=document.createElement('thead'),
		tbody=document.createElement('tbody');
		this.selector.innerHTML='';
		if (options!=undefined && options.constructor=={}.constructor) {
			settings = options;
		}
		this.selector.className = 'pdt-calender';
		this.selector.appendChild(table);
		if (settings.viewNote!=undefined && typeof settings.viewNote=='function') {
			this.onShowPopup=settings.viewNote;
		}

		table.className = settings.format!=undefined ? settings.format : 'month';
		this.format = table.className;

		this.selectDate = settings.selectDate && regYmd.test(settings.selectDate) ? (new Date(settings.selectDate)) : (new Date());
		this.selectDate.setHours(0,0,0,0);
		this.year = this.selectDate.getFullYear();
		this.month = this.selectDate.getMonth();
		this.date = this.selectDate.getDate();
		this.day = this.selectDate.getDay();
		this.collections = [];
		var createCollections = function() {
			var y=this.year, m=this.month, i,
			firstDay = (new Date(y, m, 1)).getDay(),
			firstDate = (new Date(y, m, 1)).getDate(),
			lastDate = (new Date(y, m + 1, 0)).getDate(),
			lastDay = (new Date(y, m + 1, 0)).getDay(),
			offsetDay = (firstDay>0) ? firstDay-1 : 6;
			for (i=1; i<=offsetDay; i++) {
				var d = new Date(y, m, 1-i),
				o = {date: d, otherMonth: true};
				if (i==1) {
					o.lastDom = true;
				}
				this.collections.unshift(o);
			}
			for (i = firstDate; i <= lastDate; i++) {
				var d = new Date(y, m, i), 
				o = {date: d, otherMonth: false};
				if (i == firstDate) {
					o.firstDom = true;
				}
				if (i == lastDate) {
					o.lastDom = true;
				}
				this.collections.push(o);
			}
			if (lastDay>0) {
				var n = 7-lastDay;
				for (i=1; i<=n; i++) {
					var d = new Date(y, m, i + lastDate), 
					o = {date: d, otherMonth: true};
					if (i == 1) {
						o.firstDom = true;
					}
					this.collections.push(o);
				}
			}
		}; 
		var renderHeader=function(){
			var tr = document.createElement('tr');
			for (i = 0; days[i]; i++) {
				var th = document.createElement('th');
				if (days[i][0]!=undefined) {
					th.innerHTML = days[i][1];
				}
				if (days[i][0]==this.day) {
					th.className = 'active';
				}
				tr.appendChild(th);
			}
			thead.appendChild(tr);
			table.appendChild(thead);
		}; 
		var insertNode=function(t){
			if (this.notes[t]) {
				var items=[], h;
				for (var i=5; i<=29; i++) {
					h = i>24 ? i%24 : i;
					if (this.notes[t][h]) {
						this.notes[t][h].map(function(value, index, arr) {
							items.push( '<div>' + 
								'<div class="time ' +(value.status==undefined?'':value.status)+ '">'  +value.timeFormat+ '</div>' + 
								'<div class="fan-icon">' + 
									(value.profiles!=undefined && Array.isArray(value.profiles) ? value.profiles.map(function(val, j) { 
										return j < 3 ? ('<a><img src="'+val+'" /></a>') : (j==3 ? '<a>...</a>' : '') ;
									}).join('') : '' ) + 
								'</div>' + 
								'<a class="title" data-id="'+value.id+'" click="showpoupcalendar" data-unixtime="'+t+'">' + 
								(value.type==undefined?'':('<i class="'+value.type+'"></i>')) + 
								value.title + '</a>' + 
							'</div>' );
						});
					}
				}
				if (items.length>0) {
					return '<div class="event">' + items.join('') + '</div>' + (items.length>2 ? ('<a class="action showmore" click="showmore">+View more</a>'): '');
				}
			}
			return '';
		};
		var insertNodeWeek=function(t){
			if (this.notes[t]) {
				var h;
				for (h in this.notes[t]) {
					var items=[];
					this.notes[t][h].map(function(value, index, arr) {
						items.push( '<div class="' +(h%2==1 ? 'odd ':'even ')+ '">' + 
							'<a class="title '+(value.status==undefined?'':value.status)+'" data-id="'+value.id+'" data-hour="'+h+'" click="showpoupcalendar" data-unixtime="'+t+'_'+(h%2==1?h:h-1)+'">' + 
							(value.type==undefined?'':('<i class="'+value.type+'"></i>')) + 
							value.title + '</a>' + 
						'</div>' );
					});
					if (h%2==1) {
						self.dateItems[t+'_'+h].querySelector('.event').innerHTML=items.join('');
					} else {
						self.dateItems[t+'_'+(h-1)].querySelector('.event').innerHTML+=items.join('');
					}
				}
				for (var i = 1; i <= 23; i=i+2) {
					if (self.dateItems[t+'_'+i].querySelector('.event').querySelectorAll('div.odd, div.even').length>2) {
						self.dateItems[t+'_'+i].innerHTML += '<a class="action showmore" click="showmore">+View more</a>';
					}
				}
			}
		};
		var renderBody=function(){
			for (var i = 0; this.collections[i]; i++) {
				if (i%7==0) {
					var tr = document.createElement('tr');
					tbody.appendChild(tr);
					var td = document.createElement('td');
					tr.appendChild(td);
				}
				var td = document.createElement('td'), 
				backdrop = document.createElement('div'), 
				id = this.collections[i].date.getTime();
				backdrop.className='backdrop-shoremore';
				this.dateItems[id] = document.createElement('div');
				this.dateItems[id].id = 'pdt-'+id;
				td.appendChild(this.dateItems[id]);
				td.appendChild(backdrop);
				this.dateItems[id].innerHTML = '<a class="hidden" click="closeShowmore">&times</a>' + 
					'<div class="day-item ' + 
					(this.collections[i].otherMonth ? ' disabled ': '') + 
					(this.collections[i].firstDom ? ' first-day-month ': '') + 
					(this.collections[i].lastDom ? ' last-day-month ': '') + 
					'">' +
					'<span>' +defMonth[this.collections[i].date.getMonth()]+ ' </span>' + 
					'<span>' +this.collections[i].date.getDate()+ '</span>' + 
					'</div>' + 
					insertNode.call(this, id);
				if (this.selectDate.getTime()==id) {
					td.className = 'active';
				}
				tr.appendChild(td);
			}
			table.appendChild(tbody);
		};
		var renderBodyWeek=function(){
			var start, end;
			table.appendChild(tbody);
			for (var index = 0; this.collections[index]; index++) {
				var id = this.collections[index].date.getTime();
				if (this.selectDate.getTime()==id) {
					start = index - Math.floor(index%7);
					end = start+6;
					for (var r = 0; r < 12; r++) {
						var tr = document.createElement('tr'), 
						td = document.createElement('td'), 
						hour = defHour[r][0].v;
						tbody.appendChild(tr);
						tr.appendChild(td);
						td.innerHTML = '<div>'+defHour[r][0].time+'</div><div>'+defHour[r][1].time+'</div>';
						for (var i = start; i <= end; i++) {
							var td = document.createElement('td');
							var backdrop = document.createElement('div'), 
							id = this.collections[i].date.getTime()+'_'+hour;
							backdrop.className='backdrop-shoremore';
							this.dateItems[id] = document.createElement('div');
							this.dateItems[id].id = 'pdt-'+id;
							this.dateItems[id].setAttribute('data-hour', hour);
							td.appendChild(this.dateItems[id]);
							td.appendChild(backdrop);
							//if (hour == defHour[0][0].v) {
								this.dateItems[id].innerHTML = '<a class="hidden" click="closeShowmore">&times</a>' + 
									'<div class="day-item ' + 
									(this.collections[i].otherMonth ? ' disabled ': '') + 
									(this.collections[i].firstDom ? ' first-day-month ': '') + 
									(this.collections[i].lastDom ? ' last-day-month ': '') + 
									'">' +
									'<span>' +defMonth[this.collections[i].date.getMonth()]+ ' </span>' + 
									'<span>' +this.collections[i].date.getDate()+ '</span>' + 
									'</div><div class="event">' + 
									'</div>';
							/*} else {
								this.dateItems[id].innerHTML = '<a class="hidden" click="closeShowmore">&times</a><div class="event"></div>';
							}*/
							tr.appendChild(td);
						}
					}
					break;
				}
			}
			
			for (var i = start; i <= end; i++) {
				var t=this.collections[i].date.getTime();
				insertNodeWeek.call(this, t);
			}
		};
		renderHeader.call(this);
		createCollections.call(this);
		/* get data */
		if (settings.notes!=undefined && typeof settings.notes == 'string') {
			this.get({
				url: settings.notes,
				done: function(data) {
					if (Array.isArray(data)) {
						for (i = 0; data[i]; i++) {
							if (data[i].create_time && regVNtime.test(data[i].create_time)) {
								var d = new Date(data[i].create_time.replace(/^([012]\d|3[01])\/(0\d|1[0-2])\/(\d{4})\s+([^\s]+)$/, function(all,d,m,y){ return y+'-'+m+'-'+d })),
								time = data[i].create_time.replace(/^([^\s]+)\s+([012]?\d)\:(\d\d)\:(\d\d)$/, function(all, a, b, c, d){
									h = parseInt(b);
									return h==0?24:h;
								});
								d.setHours(0,0,0,0);
								if (self.notes[d.getTime()]==undefined) {
									//self.notes[d.getTime()] = [];
									self.notes[d.getTime()] = {};
									for (var h = 1; h <= 24; h++) {
										self.notes[d.getTime()][h]=[];
									}
								}
								self.notes[d.getTime()][time].push({
									create_time: data[i].create_time,
									date: d,
									timeFormat: data[i].create_time.replace(/^([^\s]+)\s+([^\s]+)$/, function(all, a, b){return b}),
									time: time,
									title: data[i].message.length>22 ? data[i].message.substr(0,22).replace(/\s+([^\s]+)?$/, '...') : data[i].message,
									status: data[i].status,
									profiles: data[i].profiles,
									type: data[i].message_type=='link' ? 'fas fa-link' : (data[i].message_type=='image' ? 'far fa-image':''),
									id: data[i].id
								});
							}
						}
					}
					settings.format==undefined ? renderBody.call(self) :(settings.format=='week' ? renderBodyWeek.call(self) : renderBody.call(self));
				}, fail: function() {
					settings.format==undefined ? renderBody.call(self) :(settings.format=='week' ? renderBodyWeek.call(self) : renderBody.call(self));
					/*renderBody.call(self);*/
				}
			})
		} else {
			if (settings.notes!=undefined && Array.isArray(settings.notes)) {
				for (i = 0; data[i]; i++) {
					if (data[i].create_time && regVNtime.test(data[i].create_time)) {
						var d = new Date(data[i].create_time.replace(/^([012]\d|3[01])\/(0\d|1[0-2])\/(\d{4})\s+([^\s]+)$/, function(all,d,m,y){ return y+'-'+m+'-'+d })),
						time = data[i].create_time.replace(/^([^\s]+)\s+([012]?\d)\:(\d\d)\:(\d\d)$/, function(all, a, b, c, d){
									h = parseInt(b);
									return h==0?24:h;
								});
						d.setHours(0,0,0,0);
						if (this.notes[d.getTime()]==undefined) {
							//this.notes[d.getTime()] = [];
							self.notes[d.getTime()] = {};
							for (var h = 1; h <= 24; h++) {
								self.notes[d.getTime()][h]=[];
							}
						}
						this.notes[d.getTime()][time].push({
							create_time: data[i].create_time,
							date: d,
							timeFormat: data[i].create_time.replace(/^([^\s]+)\s+([^\s]+)$/, function(all, a, b){return b}),
							time: data[i].create_time.replace(/^([^\s]+)\s+([012]?\d)\:(\d\d)\:(\d\d)$/, function(all, a, b, c, d){return parseInt(b)}),
							title: data[i].message.substr(0,22).replace(/\s+([^\s]+)?$/, '...'),
							status: data[i].status,
							profiles: data[i].profiles,
							type: data[i].message_type=='link' ? 'fas fa-link' : (data[i].message_type=='image' ? 'far fa-image':''),
							id: data[i].id
						});
					}
				}
			}
			settings.format==undefined ? renderBody.call(this) :(settings.format=='week' ? renderBodyWeek.call(this) : renderBody.call(this));
			/*renderBody.call(this);*/
		}

		this.selector.onclick=function(e){
			try {
			    e = e || window.event;
			    if (!(("which" in e) ? (e.which == 3) : (("button" in e) ? (e.button == 2) : false))) {
			        var act=undefined, i=0, el = e.srcElement || e.target;
			        if (el && (typeof el.getAttribute=='function') && el.getAttribute('click')) {
			            e.targetElement = el;
			            act = 'onClick_'+el.getAttribute('click');
			        }
			        while (!act && (i++<5) && (el=el.parentNode)) {
			            if (el && (typeof el.getAttribute=='function') && el.getAttribute('click')) {
			                e.targetElement = el;
			                act = 'onClick_'+el.getAttribute('click');
			            }
			        }
			        if (act && typeof self[act]=='function') {
			            self[act].call(self, e);
			        }
			    }
			} catch (ex) {
			    console.log(ex)
			}
		}
	}
};
/*document.addEventListener('mousemove', function(e) {
	if (e.clientX!=undefined) {
		pdtCalenderPopupPosition.clientX = e.clientX;
	}
	if (e.clientY!=undefined) {
		pdtCalenderPopupPosition.clientY = e.clientY;
	}
});*/
pdtCalender.prototype.onClick_showmore = function(e) {
	/*if (this.popupContent && isElement(this.popupContent)) {
		this.popupContent.style.display='none';
	}*/
	try{document.querySelector('.popup-content.in').className='popup-content'}catch(ex){}
	e.targetElement.parentNode.className='popup-more';
	this.popupMoreOn=true;
	e.targetElement.parentNode.nextElementSibling.className='backdrop-shoremore in';
};
pdtCalender.prototype.onClick_closeShowmore = function(e) {
	e.targetElement.parentNode.className='';
	this.popupMoreOn=false;
	document.querySelector('.backdrop-shoremore.in').className='backdrop-shoremore';
	try{document.querySelector('.popup-content.in').className='popup-content'}catch(ex){}
	/*if (this.popupContent && isElement(this.popupContent)) {
		this.popupContent.style.display='none';
	}*/
}
pdtCalender.prototype.onClick_closeShowpoupcalendar = function(e) {
	try{document.querySelector('.popup-content.in').className='popup-content'}catch(ex){}
	/*if (this.popupContent && isElement(this.popupContent)) {
		this.popupContent.style.display='none';
	}*/
	this.popupMoreOn=false;
}
pdtCalender.prototype.onClick_showpoupcalendar = function(e) {
	try{document.querySelector('.popup-content.in').className='popup-content'}catch(ex){}
	/*if (this.popupContent && isElement(this.popupContent)) {
		this.popupContent.style.display='none';
	}*/
	window.ee = e;
	window.tt = e.targetElement;
	var id=e.targetElement.dataset.unixtime, divId = '#pdt-'+id, tmp, X, Y;
	//var hour = this.format=='month' ? 5 :0;
	if (this.dateItems[id].X==undefined||this.dateItems[id].Y==undefined) {
		tmp=e.targetElement.parentNode;
		X = tmp.offsetLeft;
		Y = tmp.offsetTop;
		while (tmp.offsetParent && tmp.offsetParent.className!='pdt-calender') {
			tmp = tmp.offsetParent;
			X += tmp.offsetLeft; 
			Y += tmp.offsetTop;
		}
		X += this.offsetLeftBody;
		Y += this.offsetTopBody;
		this.dateItems[id].X=X;
		this.dateItems[id].Y=Y;
	} else {
		X=this.dateItems[id].X;
		Y=this.dateItems[id].Y;
	}

	if (!document.querySelector(divId).querySelector('div.popup-content')) {
		var popup = document.createElement('div');
		popup.className = 'popup-content';
		document.querySelector(divId).appendChild(popup);
	}
	this.popupContent = document.querySelector(divId).querySelector('div.popup-content');
	//this.popupContent.style.display='';
	this.popupContent.className = 'popup-content in';
	if (this.onShowPopup!=undefined && typeof this.onShowPopup=='function') {
		this.onShowPopup.call(e.targetElement, e, this);
		/*this.popupContent.innerHTML = this.onShowPopup.call(e.targetElement, e, this);*/
	} else {
		this.popupContent.innerHTML = '<section class="wrap-popup"><div class="popup">loading content<a class="btn-close" click="closeShowpoupcalendar"><img src="images/Close.png" alt=""></a></div></section>';
	}
	if (X<this.popupContentWidth) {
		this.popupContent.style.left = '100%';
		this.popupContent.className += ' right ';
	} else {
		this.popupContent.className += ' left ';
		this.popupContent.style.left = -this.popupContentWidth + 'px';
	}
	/*window.div1 = this.dateItems[id];
	console.log(tt.offsetTop);
	console.log(tt.offsetTop-50-div1.offsetHeight);*/
	var scrollMore = this.popupMoreOn ? (this.dateItems[id].querySelector('.event').scrollTop) : 0;
	if (Y<this.popupContentHeight) {
		this.popupContent.style.top = e.targetElement.offsetTop-30+'px';
		this.popupContent.className += ' top ';
	} else {
		this.popupContent.style.top = (e.targetElement.offsetTop-(this.popupContentHeight-50)-scrollMore) + 'px';
		this.popupContent.className += ' botton ';
	}
	/*this.popupContent.style.top = Y<250 ? (e.targetElement.offsetTop-20+'px') : ((e.targetElement.offsetTop-260-scrollMore) + 'px');*/		
};
