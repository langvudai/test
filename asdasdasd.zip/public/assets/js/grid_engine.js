/*
	jsTmpl.grid({
	    id: "table id", //required
	    columns: [
	        {feild:"name", label:"label", format:function(){return 'html'}},
	    ], //required
	    data: [{data}], //option, array or {rows:[{data}]} or url
	    done: function(result_tmpl){} //option
	}) // return thead and tbody
	*/
if (jsTmpl && typeof jsTmpl == 'function') {
	jsTmpl.grid = function (setting) {
	    var table=setting.id!=undefined?document.getElementById(setting.id):undefined;
	    if (table && setting.columns!=undefined && Array.isArray(setting.columns) && (typeof setting.columns[0] == "object") && setting.columns[0].feild!=undefined) {
	        var columns=[], data=setting.data,thead='',tbody='',tfoot='',template='';
	        for (var i = 0; setting.columns[i]; i++) {
	            columns.push({});
	            thead+='<th>' + (setting.columns[i].label!=undefined?setting.columns[i].label:'') + '</th>';
	            if ((setting.columns[i].format==undefined)||(typeof setting.columns[i].format != 'function')) {
	                template += '<td>${' + (setting.columns[i].feild=='#'?'$index + 1':setting.columns[i].feild) + '}</td>';
	            } else {

	            }
	        }
	        jsTmpl.template('grid_tmpl_'+setting.id, '<tr>'+template+'</tr>');
	        if (data!=undefined && Array.isArray(data)) {
	            tbody = jsTmpl('grid_tmpl_'+setting.id, data);
	            table.innerHTML = '<thead><tr>' +thead+ '</tr></thead><tbody>' +tbody+ '</tbody><tfoot>' +tfoot+ '</tfoot>';
	            if (typeof setting.done == 'function') {
	                setting.done.call(this, tbody);
	            }
	        } else if ((typeof data == 'object') && Array.isArray(data.rows)) {
	        	tbody = jsTmpl('grid_tmpl_'+setting.id, data.rows);
	        	table.innerHTML = '<thead><tr>' +thead+ '</tr></thead><tbody>' +tbody+ '</tbody><tfoot>' +tfoot+ '</tfoot>';
	        	if (typeof setting.done == 'function') {
	        	    setting.done.call(this, tbody);
	        	}
	        } else {
	            if (typeof data == 'string') {
	                var x = window.XMLHttpRequest ? new XMLHttpRequest : window.ActiveXObject ? new ActiveXObject("Microsoft.XMLHTTP") : null;
	                if (x) {
	                    x.onreadystatechange = function() {
	                    if (4 == x.readyState)
	                        if (200 == x.status) {
	                            try {
	                                var data = JSON.parse(x.responseText), rows=[];
	                                if ((typeof data == 'object') && Array.isArray(data.rows)) {
	                                	rows = data.rows;
	                                } else if (Array.isArray(data)) {
	                                	rows = data;
	                                }
	                                tbody = jsTmpl('grid_tmpl_'+setting.id, rows);
	                                table.innerHTML = '<thead><tr>' +thead+ '</tr></thead><tbody>' +tbody+ '</tbody><tfoot>' +tfoot+ '</tfoot>';
	                                if (typeof setting.done == 'function') {
	                                    setting.done.call(this, data);
	                                }
	                            } catch (e) {}
	                        }
	                    }
	                    x.open("GET", data, true);
	                    x.setRequestHeader("Request-Content-Type", "json");
	                    x.send(null)
	                }
	            }
	        }
	    }
	}
}