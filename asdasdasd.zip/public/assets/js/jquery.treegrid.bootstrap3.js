$.extend($.fn.treegrid.defaults, {
    expanderExpandedClass: 'fa fa-minus',
    expanderCollapsedClass: 'fa fa-plus'
});