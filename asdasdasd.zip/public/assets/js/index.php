<?php 

$u = explode('?', $_SERVER['REQUEST_URI']);
//echo $u[0];
$php_self = urldecode($_SERVER['PHP_SELF']);
        if (stripos($u[0], 'index.php')) {
            $_uriStart = substr($u[0], 0, strpos($u[0], 'index.php')).'index.php';
            $_requestUri = substr($u[0], strlen($_uriStart));
        } else {
            $_uriStart = substr($php_self,0, stripos($php_self, 'index.php')-1);
            $_requestUri = substr($u[0], strlen($_uriStart));
            /*$_uriStart = $uri_start;
            if (empty($uri_start)) {
                $_requestUri = $u[0];
            } elseif (strpos($u[0], $uri_start)){
                $_requestUri = substr($u[0], strpos($u[0], $uri_start)+strlen($uri_start));
            }*/
        }
        echo $php_self.'<br>'.$_uriStart.'<br>'.$_requestUri;
        /*return $_requestUri;*/
exit();


/*$php_self = urldecode($_SERVER['PHP_SELF']);
$query_string = urldecode($_SERVER['REQUEST_URI']);
//echo $php_self;
echo substr($php_self,0, stripos($php_self, 'index.php'));
exit();
$script_name = $_SERVER['SCRIPT_NAME'];
$rewrite = stripos(' '.$php_self, $script_name) ? substr($php_self, strlen($script_name)) : '/';
$requestUri = $rewrite . $query_string;
$scrip_file = substr($script_name, strrpos($script_name, '/')+1);
$uri_start = stripos($_SERVER['REQUEST_URI'], $scrip_file) ? $script_name : substr($script_name, 0, stripos($script_name, $scrip_file)-1);
$_uriStart = $uri_start;
$_requestUri = $requestUri;*/