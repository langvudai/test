/*
jsTmpl.template(name) return true if exist && has been processed
jsTmpl.template(name, HTML ELEMENT)
jsTmpl.template(name, '#id')
jsTmpl.template(name, 'string template')
jsTmpl.template({name: name, url: url})
jsTmpl.delete(name) delete object template
jsTmpl(templateName, Array({data}, ..), {dataSet})
jsTmpl.fn.callback=function(...){...}
*/
;(function(a, b) {
    var lsTmpl = {
        "javascript": {
            open:";$fnargs;"
        },
        "each": {
            open: "if($notnull_1){$each($1b,function(i){this.$index=i;with(this){",
            close: "}});}"
        },
        "if": {
            open: "if(($notnull_1) && $1b){",
            close: "}"
        },
        "else": {
            _default: { $1: "true" },
            open: "}else if(($notnull_1) && $1a){"
        },
        "html": {
            open: "if($notnull_1){__.push($1a);}"
        },
        "=": {
            open: "if($notnull_1){__.push($encode($1a));}"
        },
        "encode": {
            _default: { $1: "$data" },
            open: "if($notnull_1){__.push($encode($1a));}"
        },
        "!": {
            open: ""
        }
    }, htTmplFn = {}, jsJson={}.constructor;
    function chkundef(target) {
        if (typeof target=='string' && target.indexOf('.')) {
            var p=target.split('.'), i, name=[], __=[];
            for (i = 0; p[i]; i++) {
                name.push(p[i]);
                __.push("typeof(" + name.join('.') + ")!=='undefined'")
            }
            return __.join(' && ');
        } else {
            return "typeof(" + target + ")!=='undefined'";
        }
    }
    function isElement (obj) {
        try {
            return obj instanceof HTMLElement;
        } 
        catch(e) {
            return (typeof obj==="object") && (obj.nodeType===1) && (typeof obj.style === "object") && (typeof obj.ownerDocument ==="object");
        }
    }
    function factoryTmpl ( tmplContent ) {
        var 
        fnContent = 
            /*"if (this.returnNull) return '" + 
            tmplContent.replace(/^\s+|\s+$/g, '')
            .replace( /([\\'])/g, "\\$1" )
            .replace( /[\r\t\n]/g, " " )
            .replace( /\\\{/g, "&#123;" )
            .replace( /\\\}/g, "&#125;" )
            .replace( /\$\{([^\}]*)\}/g, "" )
            .replace( /\{\{([^jeih\!=])/g, "&#123;&#123;\\$1" )
            .replace( /(\{\{if\s+[^\{]*\/if\}\})|(\{\{each\s+[^\{]*\/each\}\})/g, "" )
            + "'; " + */
            "var __=[], call; $data=this;" + 
            "var $encode=$fn['__'+$fn.__uniqId].encode;" + 
            "var $each=$fn['__'+$fn.__uniqId].each;" + 
            "with(this) {__.push('" + 
            tmplContent.replace(/^\s+|\s+$/g, '')
            .replace( /([\\'])/g, "\\$1" )
            .replace( /[\r\t\n]/g, " " )
            .replace( /\\\{/g, "&#123;" )
            .replace( /\\\}/g, "&#125;" )
            .replace( /\\\./g, "&#46;" )
            .replace( /\$\{([^\}]*)\}/g, "{{= $1}}" )
            .replace( /\{\{javascript\:([^\{\n\}]+)\}\}/g, "{{javascript(\$1)}}")
            .replace( /\{\{(\/?)(\w+|.)(?:\(((?:[^\}]|\}(?!\}))*?)?\))?(?:\s+(.*?)?)?(\(((?:[^\}]|\}(?!\}))*?)\))?\s*\}\}/g,
                function( all, slash, type, fnargs, target, parens, args ) {
                    var tmpl = lsTmpl[ type ], def, expr, exprAutoFnDetect, fn;
                    if ( typeof tmpl == 'undefined' ) {
                        throw "Unknown template: " + type;
                        return all;
                    }
                    def = tmpl._default || [];
                    if ( parens && !/\w$/.test(target)) {
                        target += parens;
                        parens = "";
                    }
                    if ( target ) {
                        target = unescape( target );
                        args = args ? ("," + unescape( args ) + ")") : (parens ? ")" : "");
                        expr = parens ? (target.indexOf(".") > -1 ? target + unescape( parens ) : ("($fn." + target + ").call(this" + args)) : target;
                        exprAutoFnDetect = parens ? expr : "(typeof(" + target + ")==='function'?(" + target + ").call(this):(" + target + "))";
                    } else {
                        exprAutoFnDetect = expr = def.$1 || "null";
                    }
                    fnargs = unescape( fnargs );
                    var joinTarget = '', tmp1, j, b='';
                    if (type=="=" && /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(target)) {
                        tmp1 = target.split('.');
                        for (j = 0; tmp1[j]; j++) {
                            b += j>0 ? ('.' + tmp1[j]) : tmp1[j];
                            joinTarget += (j>0 ? ' && ':'') + "typeof(" + b + ")!=='undefined' && (" + b + ")!=null";
                        }
                    } else {
                        joinTarget = parens ? ("typeof($fn." + target + ")!=='undefined' && ($fn." + target + ")!=null") : (chkundef(target) + " && (" + target + ")!=null");
                    }
                    return "');" +
                        tmpl[ slash ? "close" : "open" ]
                            .split( "$notnull_1" ).join( target ? joinTarget : "true" )
                            .split( "$1a" ).join( exprAutoFnDetect )
                            .split( "$1b" ).join( target )
                            .split( "$1" ).join( expr )
                            .split( "$fnargs" ).join( fnargs ) +
                        "__.push('";
                })
            + "')};" + 
            "return __.join('');";
            fnContent = fnContent.replace(/&#46;/g, '.');
        return Function("$index", "$fn", fnContent);
    }
    a.jsTmpl = function (templateName, data, dataSet) {
        try{
            if (this.newFuntion && (typeof templateName=='string')) {
                var templateString = templateName;
                templateName=null;
            }
        }catch(epdt){}
        if (typeof templateName=='string') {
            if (data == undefined && typeof htTmplFn[templateName] == 'function') {
                return true;
            }
            if (!data) {
                data = []
            }
            if ((typeof data == "object") && (data.constructor === jsJson)) {
                data = [data]
            }
            if ((typeof dataSet == "object") && dataSet && dataSet.constructor === jsJson) {
                var fnCt="try{";
                for(var f in dataSet) {
                    fnCt+="this[\"$"+f.replace(/"/g, '\"')+"\"]=\""+dataSet[f]+"\";";
                }
                var getValue=Function(fnCt+";return this}catch(e){console.log(e)}");
            } else {
                var getValue=function(){return this}
            }
            if (Array.isArray(data) && typeof htTmplFn[templateName] == 'function') {
                return data.map(function(value, index) {
                    try { return htTmplFn[templateName].call(getValue.call(value), index, jsTmpl.fn); }
                    catch (e) { console.log(e) }
                }).join('');
            }
            return '';
        } else {
            var self=this, callRun=data; 
            this.render=function(tmp_name, dat, dataset) {
                if (this.newFuntion && typeof this.newFuntion=='string') {
                    dataset=dat;dat=tmp_name;tmp_name=this.newFuntion;
                }
                if (dat == undefined &&  tmp_name!=undefined && typeof htTmplFn[tmp_name] == 'function') {
                    return true;
                }
                if (!dat) {
                    dat = []
                }
                if ((typeof dat == "object") && (dat.constructor === jsJson)) {
                    dat = [dat]
                }
                if ((typeof dataset == "object") && dataset && dataset.constructor === jsJson) {
                    var fnCt="try{";
                    for(var f in dataset) {
                        fnCt+="this[\"$"+f.replace(/"/g, '\"')+"\"]=\""+dataset[f]+"\";";
                    }
                    var getValue=Function(fnCt+";return this}catch(e){console.log(e)}");
                } else {
                    var getValue=function(){return this}
                }
                if (tmp_name && Array.isArray(dat) && typeof htTmplFn[tmp_name] == 'function') {
                    return dat.map(function(value, index) {
                        try { return htTmplFn[tmp_name].call(getValue.call(value), index, self.fn); }
                        catch (e) { console.log(e) }
                    }).join('');
                }
                return '';
            };
            this.mod=""; 
            this.act=""; 
            this.settings={}; 
            this.curModAct=""; 
            this.query={}; 
            this.noState=false; 
            if (templateName!=undefined && templateName.constructor=={}.constructor) {
                this.settings = templateName
            }
            this.template = function (name, obj) {
                if (!name) {
                    var r=[],i;
                    for (i in htTmplFn) {
                        r.push(i)
                    }
                    return r;
                }
                if (typeof name=="string" && htTmplFn[name] && name!='@') {
                    return htTmplFn[name];
                }
                if (obj!=undefined && isElement(obj) && obj.tagName=='SCRIPT') {
                    if (obj.getAttribute('name')) {
                        name = obj.getAttribute('name');
                    }
                    htTmplFn[name] = factoryTmpl(obj.innerHTML);
                } else if (typeof obj == "string") {
                    try {
                        id=obj.substr(0,1)=='#'?obj.substr(1):'';
                        if (id && document.getElementById(id) && document.getElementById(id).tagName=="SCRIPT") {
                            if (id&&document.getElementById(id).getAttribute('name')) {
                                name = document.getElementById(id).getAttribute('name');
                            }
                            htTmplFn[name] = factoryTmpl(document.getElementById(id).innerHTML);
                        } else {
                            htTmplFn[name] = factoryTmpl(obj);
                        }
                    } catch (e) {
                        htTmplFn[name] = factoryTmpl(obj);
                    }
                }
            };
            if (templateString!=undefined) {
                this.newFuntion = 'name'+this.fn.__uniqId;
                this.template(this.newFuntion, templateString);
            }
            this.delete  = function (name) {
                if (typeof name=="string" && htTmplFn[name] && name!='@') {
                    delete htTmplFn[name];
                }
                return this;
            };
            this.getHash = function() {
                this.mod=""; 
                this.act=""; 
                if (location.hash.length > 1) {
                    this.query={}; 
                    var a = location.hash.substr(1).split('/');
                    if (a.length > 1) {
                        this.mod = a.shift();
                        this.act = a.shift();
                        if (a.length > 0) {
                            for (var i=0; a[i]; i=i+2) {
                                this.query[a[i]] = a[i+1]!=undefined ? encodeURIComponent(a[i+1]) : '';
                            }
                        }
                    } else if (a.length > 0) {
                        this.mod = a[0];
                    }
                } 
            };
            this.setHash = function() {
                this.noState = true;
                if (Object.keys(this.query).length > 0) {
                    window.location = '#'+this.mod+'/'+this.act+'/'+decodeURIComponent(JSON.stringify(this.query).replace(/^\{"|"\}$/g, "").replace(/"[\:,]"/g, "/"));
                } else {
                    window.location = '#'+this.mod+'/'+this.act+'/';
                }
                this.noState = false;
            };
            this.toHash = function() {
                if (Object.keys(self.query).length > 0) {
                    return '#'+self.mod+'/'+self.act+'/'+JSON.stringify(self.query).replace(/^\{"|"\}$/g, "").replace(/"[\:,]"/g, "/");
                } else {
                    return '#'+self.mod+'/'+self.act+'/';
                }
                return '#';
            };
            this.getFURI = function() {
                if (typeof this.settings.uri=='string') {
                    var a = this.settings.uri.split('/').map(function(v) {return v.replace(/^[\- ]+|[\- ]+$/g, '')});
                } else {
                    var b = typeof this.settings.baseUrl=='string' && this.settings.baseUrl.length>0 ? this.settings.baseUrl : '/',
                    i=location.href.indexOf(b), l=b.length,
                    a = location.href.substr(i+l).replace(/[\#\?].*$/g,'').split('/').map(function(v) {return v.replace(/^[\- ]+|[\- ]+$/g, '')});
                }
                this.mod=""; 
                this.act=""; 
                this.query={}; 
                if (a!=undefined && Array.isArray(a))
                    if (a.length > 1) {
                        this.mod = a.shift();
                        this.act = a.shift().replace(/^\#+|\#+$/, '');
                        if (a.length > 0) {
                            for (var i=0; a[i]; i=i+2) {
                                this.query[a[i]] = a[i+1]!=undefined ? encodeURIComponent(a[i+1]) : '';
                            }
                        }
                    } else if (a.length > 0) {
                        this.mod = a[0];
                    }
            }
            this.toURI = function() {
                var b = typeof this.settings.baseUrl=='string' && this.settings.baseUrl.length>0 ? this.settings.baseUrl : '/';
                if (Object.keys(self.query).length > 0) {
                    return b+self.mod+'/'+self.act+'/'+JSON.stringify(self.query).replace(/^\{"|"\}$/g, "").replace(/"[\:,]"/g, "/");
                }
                return b+self.mod+'/'+self.act+'/';
                /*if (this.settings.baseUrl) {
                    return this.settings.baseUrl+this.toHash().substr(1);
                } else {
                    return '/'+this.toHash().substr(1)
                }*/
            };
            this.toQuery = function() {
                var q = this.settings.baseUrl ? (this.settings.baseUrl+'?mod='+this.mod+'&act='+this.act):('/?mod='+this.mod+'&act='+this.act);
                if (Object.keys(this.query).length > 0) {
                    return q+'&'+JSON.stringify(this.query).replace(/^\{"|"\}$/g, "").replace(/","/g, "&").replace(/"\:"/g, "=");
                }
                return q;
            };
            this.get=function(e){var t="string"==typeof e.url?e.url:null,n="function"==typeof e.done?e.done:function(){},s="function"==typeof e.fail?e.fail:function(){};if(null!=t){var l=window.XMLHttpRequest?new XMLHttpRequest:window.ActiveXObject?new ActiveXObject("Microsoft.XMLHTTP"):null;l&&(l.onreadystatechange=function(){if(4==l.readyState)if(200==l.status)if(null!=l.responseXML)n.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),n.call(this,json)}catch(e){n.call(this,l.responseText)}else if(null!=l.responseXML)s.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),s.call(this,json)}catch(e){s.call(this,l.responseText)}},l.open("GET",t,!0),l.send(null))}};
            this.getTmpl=function(e){var t="string"==typeof e.url?e.url:null,n="function"==typeof e.done?e.done:function(){},s="function"==typeof e.fail?e.fail:function(){};if(null!=t){var l=window.XMLHttpRequest?new XMLHttpRequest:window.ActiveXObject?new ActiveXObject("Microsoft.XMLHTTP"):null;l&&(l.onreadystatechange=function(){if(4==l.readyState)if(200==l.status)if(null!=l.responseXML)n.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),n.call(this,json)}catch(e){n.call(this,l.responseText)}else if(null!=l.responseXML)s.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),s.call(this,json)}catch(e){s.call(this,l.responseText)}},l.open("GET",t,!0),l.setRequestHeader("X","js-template-engine"),l.send(null))}};
            this.getJson=function(e){var t="string"==typeof e.url?e.url:null,n="function"==typeof e.done?e.done:function(){},s="function"==typeof e.fail?e.fail:function(){};if(null!=t){var l=window.XMLHttpRequest?new XMLHttpRequest:window.ActiveXObject?new ActiveXObject("Microsoft.XMLHTTP"):null;l&&(l.onreadystatechange=function(){if(4==l.readyState)if(200==l.status)if(null!=l.responseXML)n.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),n.call(this,json)}catch(e){n.call(this,l.responseText)}else if(null!=l.responseXML)s.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),s.call(this,json)}catch(e){s.call(this,l.responseText)}},l.open("GET",t,!0),l.setRequestHeader("X","json"),l.send(null))}};
            this.getSync=function(e){var t="string"==typeof e.url?e.url:null,n="function"==typeof e.done?e.done:function(){},s="function"==typeof e.fail?e.fail:function(){};if(null!=t){var l=window.XMLHttpRequest?new XMLHttpRequest:window.ActiveXObject?new ActiveXObject("Microsoft.XMLHTTP"):null;l&&(l.onreadystatechange=function(){if(4==l.readyState)if(200==l.status)if(null!=l.responseXML)n.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),n.call(this,json)}catch(e){n.call(this,l.responseText)}else if(null!=l.responseXML)s.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),s.call(this,json)}catch(e){s.call(this,l.responseText)}},l.open("GET",t,false),l.send(null))}};
            this.getSyncTmpl=function(e){var t="string"==typeof e.url?e.url:null,n="function"==typeof e.done?e.done:function(){},s="function"==typeof e.fail?e.fail:function(){};if(null!=t){var l=window.XMLHttpRequest?new XMLHttpRequest:window.ActiveXObject?new ActiveXObject("Microsoft.XMLHTTP"):null;l&&(l.onreadystatechange=function(){if(4==l.readyState)if(200==l.status)if(null!=l.responseXML)n.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),n.call(this,json)}catch(e){n.call(this,l.responseText)}else if(null!=l.responseXML)s.call(this,l.responseXML);else try{json=JSON.parse(l.responseText),s.call(this,json)}catch(e){s.call(this,l.responseText)}},l.open("GET",t,false),l.setRequestHeader("X","js-template-engine"),l.send(null))}};
            this.postForm=function(e,t,n,o){/* postForm(url, obj, done, fail) */if("string"==typeof e){var s=null;if("object"==typeof(s="string"==typeof t&&t.indexOf("\n")<0&&document.querySelector(t)?new FormData(document.querySelector(t)):null!=t&&isElement(t)&&"FORM"==t.tagName?new FormData(t):t)&&s.constructor==(new FormData).constructor){s.append(document.activeElement.name,document.activeElement.value);var c=window.XMLHttpRequest?new XMLHttpRequest:window.ActiveXObject?new ActiveXObject("Microsoft.XMLHTTP"):null,l="function"==typeof n?n:function(){},a="function"==typeof o?o:function(){};c.open("POST",e,!0),c.onreadystatechange=function(){if(4==c.readyState)if(200==c.status)if(null!=c.responseXML)l.call(this,c.responseXML);else try{json=JSON.parse(c.responseText),l.call(this,json)}catch(e){l.call(this,c.responseText)}else if(null!=c.responseXML)a.call(this,c.responseXML);else try{json=JSON.parse(c.responseText),a.call(this,json)}catch(e){a.call(this,c.responseText)}},c.send(s)}}else"function"==typeof o&&o.call()};
            document.addEventListener('click', function(e) {
                try {
                    e = e || window.event;
                    if (!(("which" in e) ? (e.which == 3) : (("button" in e) ? (e.button == 2) : false))) {
                        var act=undefined, i=0, el = e.srcElement || e.target;
                        if (el && (typeof el.getAttribute=='function') && el.getAttribute('click')) {
                            e.targetElement = el;
                            act = 'onClick_'+el.getAttribute('click');
                        }
                        while (!act && (i++<5) && (el=el.parentNode)) {
                            if (el && (typeof el.getAttribute=='function') && el.getAttribute('click')) {
                                e.targetElement = el;
                                act = 'onClick_'+el.getAttribute('click');
                            }
                        }
                        if (act && typeof jsTmpl[act]=='function') {
                            jsTmpl[act].call(jsTmpl, e);
                        } else if (act && typeof window[act]=='function') {
                            window[act].call(el, e);
                        }
                    }

                } catch (ex) {
                    console.log(ex)
                }
            }, false);
            document.addEventListener( "contextmenu", function(e) {
                try {
                    e = e || window.event;
                    var act=undefined, getCtx = function(){
                        try {
                            var i=0, el = e.srcElement || e.target;    
                            if ( el.getAttribute('contextmenu') ) {
                                e.targetElement = el;
                                act = 'onContextmenu_'+el.getAttribute('contextmenu');
                                return true;
                            } else {
                                while ((i++<5) && (el = el.parentNode)) {
                                    if ( el && el.getAttribute('contextmenu') ) {
                                        e.targetElement = el;
                                        act = 'onContextmenu_'+el.getAttribute('contextmenu');
                                        return true;
                                    }
                                }
                            }
                        } catch (e) {}
                        return false;
                    };
                    if (getCtx()) {
                        e.preventDefault();
                        if (typeof jsTmpl[act]=='function') {
                            jsTmpl[act].call(jsTmpl, e);
                        }
                    }
                } catch (ex) {
                    console.log(ex)
                }
            }, false);

            "function"==typeof callRun&&callRun.call(this);
        }
    };
    a.jsTmpl.prototype.newFuntion = true;
    a.jsTmpl.prototype.fn = {__uniqId: new Date().getTime()};
    a.jsTmpl.prototype.fn['__'+a.jsTmpl.prototype.fn.__uniqId] = {
        encode: function( text ) {
            return ("" + text).split("<").join("&lt;").split(">").join("&gt;").split('"').join("&#34;").split("'").join("&#39;");
        },
        each: function (array, callback) {
            if (typeof callback=='function') {
                if ((typeof array == "object") && (array.constructor === jsJson)) {
                    var j=0;
                    for (var i in array) {
                        callback.call({$value:array[i], $key:i}, j++);
                    }
                } else if (Array.isArray(array)) {
                    for (var i = 0; i < array.length; i++) {
                        callback.call(array[i], i);
                    }
                }
            }
        }
    }
    a.jsTmpl.fn = {__uniqId: new Date().getTime()};
    a.jsTmpl.fn['__'+a.jsTmpl.fn.__uniqId] = {
        encode: function( text ) {
            return ("" + text).split("<").join("&lt;").split(">").join("&gt;").split('"').join("&#34;").split("'").join("&#39;");
        },
        each: function (array, callback) {
            if (typeof callback=='function') {
                if ((typeof array == "object") && (array.constructor === jsJson)) {
                    var j=0;
                    for (var i in array) {
                        callback.call({$value:array[i], $key:i}, j++);
                    }
                } else if (Array.isArray(array)) {
                    for (var i = 0; i < array.length; i++) {
                        callback.call(array[i], i);
                    }
                }
            }
        }
    }
    a.jsTmpl.template = function (name, obj) {
        if (!name) {
            var r=[],i;
            for (i in htTmplFn) {
                r.push(i)
            }
            return r;
        }
        if (typeof name=="object") {
            if (typeof name.url=="string" && typeof name.name=="string") {
                var url=name.url;
                name=name.name;
            }
        }
        if (typeof name=="string" && htTmplFn[name] && name!='@') {
            return htTmplFn[name];
        }
        if (url!=undefined) {
            var a = window.XMLHttpRequest ? new XMLHttpRequest : window.ActiveXObject ? new ActiveXObject("Microsoft.XMLHTTP") : null;
            if (a) {
                a.onreadystatechange = function() {
                if (4 == a.readyState)
                    if (200 == a.status)
                        htTmplFn[name] = factoryTmpl(a.responseText);
                }
                a.open("GET", url, false);
                a.setRequestHeader("Request-Content-Type", "template");
                a.send(null);
            }
        } else {
            if (obj!=undefined && isElement(obj) && obj.tagName=='SCRIPT') {
                if (obj.getAttribute('name')) {
                    name = obj.getAttribute('name');
                }
                htTmplFn[name] = factoryTmpl(obj.innerHTML);
            } else if (typeof obj == "string") {
                try {
                    id=obj.substr(0,1)=='#'?obj.substr(1):'';
                    if (id && document.getElementById(id) && document.getElementById(id).tagName=="SCRIPT") {
                        if (id&&document.getElementById(id).getAttribute('name')) {
                            name = document.getElementById(id).getAttribute('name');
                        }
                        htTmplFn[name] = factoryTmpl(document.getElementById(id).innerHTML);
                    } else {
                        htTmplFn[name] = factoryTmpl(obj);
                    }
                } catch (e) {
                    htTmplFn[name] = factoryTmpl(obj);
                }
            }
        }
    };
    a.jsTmpl.delete = function (name) {
        if (typeof name=="string" && htTmplFn[name] && name!='@') {
            delete htTmplFn[name];
        }
    };
    
})(window, document);
