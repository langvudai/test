/*$(document).ready(function(){
    window.chon1 = function (t) {
        if (!t.checked) {
            if (t.parentNode && t.parentNode.nextElementSibling) {
                el=t.parentNode.nextElementSibling.children; 
                for(i=0; i<childs.length; i++) {
                    el.item(i).children.item(0).children.item(0).checked = false;
                }
            }
        }
    }
    window.parent_click = function (t) {
        if (!t.checked) {
            if (t.parentNode && t.parentNode.nextElementSibling) {
                el=t.parentNode.nextElementSibling.children; 
                for (i=0; i<el.length; i++) {
                    el.item(i).children.item(0).children.item(0).checked = false;
                }
            }
        }
    }

    window.child_click = function (t) {
        if (t.checked) {
            try {
                t.parentNode.parentNode.parentNode.parentNode.children.item(0).children.item(0).checked=true;
            } catch(Ex) {}
        }
    }
    window.selectAll = function () {
        $('.tab-content .active input:checkbox').prop('checked', true)
    }
    window.UnselectAll = function () {
        $('.tab-content .active input:checkbox').prop('checked', false)
    }
    if (document.getElementById('role-id'))
    document.getElementById('role-id').onchange=function(e) {
        $('.hidden-xs.hidden-sm.hidden-md.hidden-lg').removeClass('hidden-xs hidden-sm hidden-md hidden-lg');
        var url = $(this).data('baseurl') +'/id/'+ this.value+'?debug=';
        $.showLoading();
        $.get(url).done(function(data){
            $.hideLoading();
            $( '#permission input').prop('checked', false);
            for (var i in data) {
                var chk=document.querySelector('#permission input[type="checkbox"][name="'+i+'"]');
                if (chk) {
                    chk.checked = data[i] == 1;
                }
            }
        }).fail($.hideLoading).error($.hideLoading);
    };
    if (document.getElementById('permission-form'))
    document.getElementById('permission-form').onsubmit=function(e){
        e.preventDefault();
        $(this).ajaxPost(function(response) {
            window.rdata = response;
            if (response.status==1) {
                $.alertr(response.message || response.messege);                
            }
            $('.modal').modal('hide');
        });
    }

    $('#modal1').on('show.bs.modal', function(event){
        var button = $(event.relatedTarget); 
        var modal = $(this); 
        modal.find('.modal-title').text(button.attr('title'));
        modal.find('form').attr('action', button.attr('action'));
        if (button.attr('name')=='ADDNEWROLE') {
            modal.find('form').find('input[name="name"]').val('');
            modal.find('form').find('textarea[name="description"]').val('');
        } else {
            modal.find('form').find('input[name="name"]').val(button.parent().prev().prev().html());
            modal.find('form').find('textarea[name="description"]').val(button.parent().prev().html());
        }
    });
    if (document.getElementById('form1'))
    document.getElementById('form1').onsubmit=function(e) {
      e.preventDefault();
      $(this).ajaxPost(function(response) {
        if (response.status==1) {
            $.alertr(response.message);
            var roleName = document.querySelector('#form1 input[name="name"]').value;
            var roleDescription = document.querySelector('#form1 textarea[name="description"]').value;
            if (response.action == 'add') {
                $('#role-id').append('<option value="' +response.id+ '">' +roleName+ '</option>');
                var tr = '<tr>' + 
                    '<td id="col-role-name-' +response.id+ '">' +roleName+ '</td>' + 
                    '<td id="col-role-description-' +response.id+ '">' +roleDescription+ '</td>';
                var editable = document.getElementById('url-edit-action');
                if (editable) {
                    tr += '<td class="text-center">' + 
                    '<a class="p5 edit-user-btn" id="' +response.id+ '" title="' +editable.title+ '" data-toggle="modal" data-target="#roleForm" data-keyboard="false" data-backdrop="static" role="button" action="' +editable.getAttribute('url')+response.id+ '"><i class="fa fa-pencil"></i></a>' +
                    '</td>';
                }
                var deleteable = document.getElementById('enable-del-action');
                if (editable) {
                    tr += '<td class="text-center">'
                        +'<a class="p5" data-toggle="modal" data-target="#confirmDelete" data-id="'+response.id+'" data-rolename="'+roleName+'" data-keyboard="false" data-backdrop="static">'
                            +'<i class="fa fa-times color-red"></i>'
                        +'</a>'
                    +'</td>';
                }
                tr += '</tr>';
                $('#tbody').append(tr);
            }
            if (response.action == 'edit') {
                document.querySelector('#role-id option[value="' +response.id+ '"]').innerHTML = roleName;
                document.getElementById('col-role-name-' +response.id).innerHTML = roleName;
                document.getElementById('col-role-description-' +response.id).innerHTML = roleDescription;
            }
            $('.modal').modal('hide');
        }
      });
    };
    if (document.getElementById('form2'))
    document.getElementById('form2').onsubmit=function(e) {
      e.preventDefault();
      $(this).ajaxPost(function(response) {
          window.rdata = response;
          if (response.status==1) {
              $.alertr(response.message || response.messege);
              if (document.querySelector('#col-role-name-'+response.id)) {
                var TR = document.querySelector('#col-role-name-'+response.id).parentNode;
                TR.parentNode.removeChild(TR);
              }
              if (document.querySelector('#role-id option[value="'+response.id+'"]')) {
                  var Opt = document.querySelector('#role-id option[value="'+response.id+'"]');
                  Opt.parentNode.removeChild(Opt);
                  document.getElementById('permission').className='box-body nav-tabs-custom hidden-xs hidden-sm hidden-md hidden-lg no-shadow';
                  document.getElementById('permission').nextElementSibling.className = 'box-footer hidden-xs hidden-sm hidden-md hidden-lg';
                  document.getElementById('role-id').value=0
              }
          }
          $('.modal').modal('hide');
      });
    };
})*/

/*function reloadHistory(argument) {
    jsTmpl.re
}*/

