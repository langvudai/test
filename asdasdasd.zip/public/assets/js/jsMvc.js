;(function(a, b) {
	a.jsMvc=function (options) {
		this.abc=123;
		this.Controller=new jsMvc.Controller();
		this.
	};
	a.jsMvc.Controller=function () {

	};
	a.onpopstate=function(){
		// jsMvc.run(jsMvc.);
	}
})(window, document);

tmp = function(data, dataset) {
	var __=[], call; 
	data=this;
	var $encode=$fn['__'+$fn.__uniqId].encode;
	var $each=$fn['__'+$fn.__uniqId].each;
	with(data) {
		__.push('<h1>aaaaaa</h1> <div class="');
		if((typeof(username=="ducthanh")!=='undefined' && (username=="ducthanh")!=null) && username=="ducthanh"){
			__.push(' class1 ');
		} else if((true) && true) {
			__.push(' class2 ');
		}
		__.push('"></div>"')
	};
	return __.join('');



	__.push('<h1>aaaaaa</h1><div class="');
	{{if username=='ducthanh'}}
	 class1 
	{{else}}
	 class2 
	{{/if}}
	__.push('"></div>"<span>');
	{{for a in name}}
		a
		{{if a == '1'}}
		b
		{{/if}}
		c
	{{/each}}
</span>
	
}


((function anonymous($index,$fn
	) {
	var __=[], call; $data=this;var $encode=$fn['__'+$fn.__uniqId].encode;var $each=$fn['__'+$fn.__uniqId].each;with(this) {__.push('<h1>aaaaaa</h1> <div class="');if((typeof(username=="ducthanh")!=='undefined' && (username=="ducthanh")!=null) && username=="ducthanh"){__.push(' class1 ');}else if((true) && true){__.push(' class2 ');}__.push('"></div>"')};return __.join('');
	})