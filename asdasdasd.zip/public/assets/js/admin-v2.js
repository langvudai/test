;/**
 * Number.prototype.format(n, x, s, c)
 * 
 * @param integer n: length of decimal
 * @param integer x: length of whole part
 * @param mixed   s: sections delimiter
 * @param mixed   c: decimal delimiter
 */
Number.prototype.inRange = function(a, b) {
	return (this>=parseInt(a)) && (this<=parseInt(b));
};
Number.prototype.format = function(n, x, s, c) {
	var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
		num = this.toFixed(Math.max(0, ~~n));
	return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
};
String.prototype.nl2br = function() {
	return this.toString().replace(/\n/, '<br />');
}
String.prototype.toNumber = function() {
	try {
		return parseFloat(this)
	} catch (e) {
		try {
			return parseInt(this)
		} catch (e) {
			return 0;
		}
	}
};
Function.prototype.clone = function() {
	var that = this;
	var temp = function temporary() { return that.apply(this, arguments); };
	for(var key in this) {
		if (this.hasOwnProperty(key)) {
			temp[key] = this[key];
		}
	}
	return temp;
};
function isElement (obj) {
	try {
		return obj instanceof HTMLElement;
	} 
	catch(e) {
		return (typeof obj==="object") && (obj.nodeType===1) && (typeof obj.style === "object") && (typeof obj.ownerDocument ==="object");
	}
}
function hasClass(el, cl) {
	if (isElement(el)) {
		var cls=' '+el.className+' ', reg = new RegExp(' '+cl+' ', 'g');
		return reg.test(cls)
	}
	return false;
}
function addClass(el, cl) {
	if (isElement(el)) {
		var cls=' '+el.className+' ', reg = new RegExp(' '+cl+' ', 'g');
		cls=cls.replace(reg, ' ')+' '+cl;
		el.className = cls.replace(/^\s+|\s+$/g,'');
	}
}
function delClass(el, cl) {
	if (isElement(el)) {
		var cls=' '+el.className+' ', reg = new RegExp(' '+cl+' ', 'g');
		el.className = cls.replace(reg, ' ').replace(/^\s+|\s+$/g,'')
	}
}
function selectAllCheckBox() {
	if (el = this) {
		while (el.className.indexOf('box')==-1 && el.parentNode) {
			el = el.parentNode
		}
		var chk=el.querySelectorAll('input[type="checkbox"]');
		for (var i = 0; chk[i]; i++) {
			chk[i].checked = true
		}
	}
}
function unSelectAllCheckBox() {
	if (el = this) {
		while (el.className.indexOf('box')==-1 && el.parentNode) {
			el = el.parentNode
		}
		var chk=el.querySelectorAll('input[type="checkbox"]');
		for (var i = 0; chk[i]; i++) {
			chk[i].checked = false
		}
	}
}
childClick = function () {
    if (this.checked) {
        try {
            this.parentNode.parentNode.parentNode.parentNode.children.item(0).children.item(0).checked=true;
        } catch(Ex) {}
    }
}
parentClick = function () {
    if (!this.checked) {
        if (this.parentNode && this.parentNode.nextElementSibling) {
            el=this.parentNode.nextElementSibling.children; 
            for (i=0; i<el.length; i++) {
                el.item(i).children.item(0).children.item(0).checked = false;
            }
        }
    }
}
function preview_banner() {
	//e.preventDefault();
	if (document.querySelector('#preview-banner')) {
		$('#preview-banner').find('.modal-lg-img').removeClass('modal-lg-img');
		$('#preview-banner').find('.modal-body').html('<a><img class="img-responsive" src="'+this.href+'" /></a>');
		$('#preview-banner').find('a').click(function() {
			if (this.parentNode.parentNode.parentNode.className=='modal-dialog') {
				this.parentNode.parentNode.parentNode.className='modal-dialog modal-lg-img'
			} else {
				this.parentNode.parentNode.parentNode.className='modal-dialog';
			}
		})
		$('#preview-banner').modal();
	}
	return false;
}
function select2Run(){
	try {
		$('.select2:not(.tag)').select2();
		$('.select2.tag').select2({tags: true, width: '100%'});
	} catch (e) { console.log(e) }
}
function ajax_upload_image(){
	var me=this;
	this.value='';
}
function loadicondropdown() {
	if (document.querySelectorAll('.icon-dropdown').length) {
		var icondd = document.querySelectorAll('.icon-dropdown');
		for (var i=0; icondd[i]; i++) {
			var Li=icondd[i].querySelectorAll('li');
			icondd[i].lsi=[];
			for (var j = 0; Li[j]; j++) {
				icondd[i].lsi.push(Li[j].getAttribute('value'));
			}
			icondd[i].querySelector('input[name="icon"]').onfocus=function(e){
				this.parentNode.className='icon-dropdown focus';
			};
			/*icondd[i].querySelector('input[name="icon"]').onblur=function(e){
				this.parentNode.className='icon-dropdown';
			};*/
			icondd[i].querySelector('input[name="icon"]').onkeyup=function(e){
				e.preventDefault();
				keyCode = parseInt(e.keyCode);
				// window.e = e;
				// console.log(e.keyCode);
				if (keyCode.inRange(48, 57) || keyCode.inRange(96, 105) || keyCode.inRange(65, 90) || keyCode==8 || keyCode==32) {
					this.parentNode.querySelector('div').querySelector('i').className = '';
					var ListIcon=this.parentNode.lsi, key = this.value.replace(/([\s]+)/g, '\\s+').replace(/\*/g,'.'), regIcon = new RegExp('.*'+key+'.*', 'i');
					this.parentNode.querySelector('ul').innerHTML = ListIcon.map(function(val) {
						return regIcon.test(val) ? ('<li click="selectIcon" value="'+val+'"><i class="fa fa-'+val+'"></i><span>'+val+'</span></li>'):'';
					}).join('');
				} else if (keyCode==38) { // up
					// if (this.parentNode.querySelectorAll('ul li').length == 1) {
					//     this.parentNode.querySelector('ul li').className = 'hover';
					// }
					// if (this.parentNode.querySelectorAll('ul li').length > 1) {
					//     if (this.parentNode.querySelector('ul li.hover')) {

					//     }
					// }
				} else if (keyCode==40) { // down
					// if (this.parentNode.querySelectorAll('ul li').length == 1) {
					//     this.parentNode.querySelector('ul li').className = 'hover';
					// }
				} else if (keyCode==13) { // enter
				}
			}
			// icondd[i].querySelector('input[name="icon"]').onkeypress=function(e){
			//     //e.preventDefault();
			//     keyCode = parseInt(e.keyCode);
			//     if (keyCode==38) { // up
			//         e.preventDefault();
			//     } else if (keyCode==40) { // down
			//         e.preventDefault();
			//     } else if (keyCode==13) { // enter
			//         e.preventDefault();
			//     }
			// }
		}
	}
	document.addEventListener('click', function(e) {
	  try {
		if (e.target.parentNode.parentNode.parentNode.className != 'icon-dropdown focus'
		  &&e.target.parentNode.parentNode.className != 'icon-dropdown focus'
		  &&e.target.parentNode.className != 'icon-dropdown focus') {
		  document.querySelector('.icon-dropdown.focus').className = 'icon-dropdown';
		}
	  } catch (e) {}
	});
}
function summernote_customize() {
	(function (factory) {if (typeof define === 'function' && define.amd) {define(['jquery'], factory);} else if (typeof module === 'object' && module.exports) {module.exports = factory(require('jquery'));} else {factory(window.jQuery);}}(function ($) {
		$.extend($.summernote.plugins, {
			'images': function (context) {
				var self = this;
				var ui = $.summernote.ui;
				context.memo('button.images', function () { 
					var button = ui.button({
						contents: '<i class="note-icon-picture"/>',
						tooltip: 'images',
						click: function () {
							self.$panel.modal();
						}
					});
					var $images = button.render();
					return $images;
				});
				this.initialize = function () {
					/*console.log(context.options.browserImage);*/
					this.$panel = $('<div class="modal fade">' + 
					  '<div class="modal-dialog modal-lg">' + 
					    '<div class="modal-content">' + 
					      '<div class="modal-header">' + 
					        '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' + 
					        '<h4 class="modal-title">Browser image</h4>' + 
					        '<form action="'+context.options.browserImage+'"><input class="form-control" type="file" name="files" accept="image/*" /></form>' + 
					      '</div>' + 
					      '<div class="modal-body">' + 
					      '</div>' + 
					      '<div class="modal-footer">' + 
					        '<button type="button" class="btn btn-primary">Insert</button>' + 
					      '</div>' + 
					    '</div>' + 
					  '</div>' + 
					'</div>');
					this.$panel.find('.modal-header form > input').on('change', function(){
						var me=this;
						if (context.options.browserImage) {
							$.ajax({
								url: jsTmpl.settings.baseUrl+'upload/image',
								type: "POST",
								data: new FormData(this.parentNode), 
								processData: false,
								contentType: false,
								success: function (data) {
									self.$panel.find('.modal-body').append($('<label class="summernote-customize-image-item">' + 
										'<input type="radio" class="hidden" value="'+data.src+'" name="summernote_customize_images" />' + 
										'<div>' + 
											'<img src="'+data.src+'">' + 
										'</div>' + 
									'</label>'));
									me.value = '';
								}
							}).fail(function(){
							});
						} else {
							alert('browserImage is undefined');
						}
					});
					this.$panel.find('.modal-footer form > button').on('click', function(){ 
					});
					this.$panel.appendTo('body');
				};
				this.destroy = function () { this.$panel.remove(); this.$panel = null; };

			},
			'imgTab': function (context) {
				var self = this;
				var ui = $.summernote.ui;
				context.memo('button.imgTab', function () { 
					var button = ui.button({
						contents: 'Image tabs',
						tooltip: 'image tab',
						click: function () {
							self.$panel.modal();
						}
					});
					var $images = button.render();
					return $images;
				});
				this.initialize = function () {
					var uniqId = parseInt(new Date().getTime()+'0');
					this.$panel = $('<div class="modal fade">' + 
					  '<div class="modal-dialog modal-lg">' + 
					    '<div class="modal-content">' + 
					      '<div class="modal-header">' + 
					        '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' + 
					        '<h4 class="modal-title">Image tabs</h4>' + 
					        '<form action="'+context.options.browserImage+'"><input class="form-control" type="file" name="files" accept="image/*" /></form>' + 
					      '</div>' + 
					      '<div class="modal-body preview-upload">' + 
					      '</div>' + 
					      '<div class="modal-footer">' + 
					        '<button type="button" class="btn btn-primary">Insert</button>' + 
					      '</div>' + 
					    '</div>' + 
					  '</div>' + 
					'</div>');
					this.$panel[0].querySelector('input[name="files"]').onchange=function(e){
						var formData = new FormData(this.parentNode), url=this.parentNode.action;
						$.ajax({
							url: url,
							type: "POST",
							data: formData, 
							processData: false,
							contentType: false,
							success: function (data) {
								if (data.status) {
									uniqId++;
									self.$panel.find('.modal-body.preview-upload').append($('<div id="'+uniqId+'"><img src="'+data.src+'" style="max-height:100px"><a style="right:10px;top:10px" onclick="$(this).parent().remove()">&times;</a></div>'))
								}
								self.$panel[0].querySelector('input[name="files"]').value=null;
							}
						}).fail(function(){
							self.$panel[0].querySelector('input[name="files"]').value=null;
						});
					};
					this.$panel[0].querySelector('.modal-footer button').onclick=function(){
						var tabs='', tabcontents='', active=' active';
						self.$panel.find('.modal-body.preview-upload').children().each(function(index){
							tabs+='<li class="'+active+'"><a href="#tabname'+this.id+'" data-toggle="tab">'+this.id+'</a></li>';
							tabcontents+='<div class="tab-panel '+active+'" id="tabname'+this.id+'"><img src="'+this.querySelector('img').src+'" class="img-responsive" /></div>';
							active='';
						}).promise().done(function(){
							var div=document.createElement('div');
							div.innerHTML='<ul class="nav nav-tabs">'+tabs+'</ul><div class="tab-content">'+tabcontents+'</div>';
							context.invoke('editor.insertNode', div);
						});
						self.$panel.modal('hide');
					};
				};
				this.destroy = function () { this.$panel.remove(); this.$panel = null; };
			}
		});
	}));
	try {
		$.summernote.toolbar = {
			basic:[['font', ['bold', 'italic', 'underline', 'clear']],['para', ['ol', 'paragraph']],['view', ['codeview']]],
			advance:[
	            ['style', ['style']],
	            ['font', ['bold', 'italic', 'underline', 'clear']],
	            ['fontname', ['fontname']],
	            ['color', ['color']],
	            ['fontsize', ['fontsize']],
	            ['para', ['ul', 'ol', 'paragraph']],
	            ['height', ['height']],
	            ['table', ['table']],
	            ['insert', [/*'images', */'link', 'picture', 'imgTab', 'hr']],
	            ['view', ['codeview']]
	        ]
		};
		// $.summernoteToolbar['basic'] = [['font', ['bold', 'italic', 'underline', 'clear']],['color', ['color']],['view', ['codeview']]];
		// $.summernoteToolbar['advance'] = [
		//           ['style', ['style']],
		//           ['font', ['bold', 'italic', 'underline', 'clear']],
		//           ['fontname', ['fontname']],
		//           ['color', ['color']],
		//           ['fontsize', ['fontsize']],
		//           ['para', ['ul', 'ol', 'paragraph']],
		//           ['height', ['height']],
		//           ['table', ['table']],
		//           ['insert', ['link', 'picture', 'hr']],
		//           ['hello', ['hello']],
		//           ['view', ['codeview']]
		//       ];
		$('textarea[editor="summernote"][toolbar]').summernote();
	} catch (e) {
		console.log(e)
	}
}
function loaded() {
	var self=this;
	('function' == typeof loadicondropdown) && loadicondropdown();
	if ($('.tree-menu')) $('.tree-menu').treegrid({treeColumn: 1});
	if ($('.tree-category')) $('.tree-category').treegrid({
		treeColumn: 2, 
		expanderExpandedClass: 'folder-open-o', 
		expanderCollapsedClass: 'folder-o'
	});
	('function' == typeof summernote_customize) && ('object'==typeof $.summernote) && summernote_customize();
	('function' == typeof select2Run) && select2Run();
}
var modal={
  modalid:{},
  open:function(selector){
	if (document.querySelector(selector)) {
	  this.modalid[selector] = {
		el : document.querySelector(selector),
		class : document.querySelector(selector).className
	  }
	  this.modalid[selector].el.style.display='block';
	  var me = this;
	  setTimeout(function(){
		me.modalid[selector].el.className = me.modalid[selector].class+' in';
	  }, 50)
	}
  },
  hide:function(selector){
	if (this.modalid[selector]) {
	  this.modalid[selector].el.className = this.modalid[selector].class;
	  var me = this;
	  setTimeout(function(){
		me.modalid[selector].el.style.display='';
	  }, 100);
	}
  }
};
/*jsTmpl*/
window.onpopstate=function(){
	jsTmpl.run();
}
jsTmpl.prototype.uploadImg = function(el, selector) {
	if (isElement(el)) {
		var url = this.settings.baseUrl+'upload/image', 
		formData = new FormData, 
		dir = el.dataset.dir,
		name = el.dataset.name;
		//alert(el.name);
		//formData.append(el.name, 'UPLOAD_IMG');
		if (el.tagName=='INPUT' && el.type=='file') {
			formData.append(el.name, el.files[0]);
			formData.append('dir', dir);
			this.postForm(url, formData, function(response) {
				if (response.status==1) {
					if (typeof selector=="function") {
						selector.call(el, response);
					} else {
						var div=document.createElement('div');
						div.innerHTML='<img src="'+response.src+'" class="img-responsive" /><a onClick="this.parentNode.remove()">&times;</a>' + 
						'<input type="hidden" name="'+name+'" value="'+response.filename+'" />';
						if (name.length==name.indexOf("[]")+2) {
							document.querySelector(selector).appendChild(div);
						} else {
							document.querySelector(selector).innerHTML=div.outerHTML;
						}
					}
				}
				el.value='';
			});
		}
	}
};
jsTmpl.prototype.createUrl = function(value, selector, prefix, isrenew) {
	if (document.querySelector(selector)) {
		var tagName = document.querySelector(selector).tagName, 
		curl = tagName=='INPUT'||tagName=='TEXTAREA' ? document.querySelector(selector).value : document.querySelector(selector).innerHTML, 
		value = value.replace(/^\s+|\s+$/,''), 
		prefix = prefix.replace(/^\s+|\s+$/,''), 
		formData = new FormData();
		formData.append('value', value);
		formData.append('prefix', prefix);
		if (curl.replace(/^\s+|\s+$/,'').length==0 || isrenew) {
			this.postForm(this.settings.baseUrl+'index/createurl', formData, function (response) {
				if (response.status==1) {
					if (tagName=='INPUT'||tagName=='TEXTAREA') {
						document.querySelector(selector).value = response.url
					} else {
						document.querySelector(selector).innerHTML = response.url
					}
				}
			});
		}
	}
};
jsTmpl.prototype.run=function(){
	this.getFURI();
	if (typeof this.init == 'function') {
		this.init.call(this);
	}
	var mod_=this.mod.replace(/^(\w)(.*)$/, function(a,b,c){return b.toUpperCase()+c.toLowerCase()})+'_',
	ctrlact=mod_+this.act.toLowerCase();
	if (typeof this[ctrlact] == 'function') {
		this[ctrlact].call(this);
	} else if (typeof this[mod_] == 'function') {
		this[mod_].call(this);
	} else if (typeof this._ == 'function') {
		this._.call(this);
	}
};
jsTmpl.prototype.pushStateRun = function(url) {
	window.history.pushState({url:url},"",url);
	this.run();
};
jsTmpl.prototype.fn.indentTreeGrid=function(data){
	return this.parent!=undefined && this.parent ? ('treegrid-'+this.id+' treegrid-parent-' + this.parent) : ('treegrid-'+this.id);
};
jsTmpl.prototype.fn.indentOptionTree=function(){
	s = '';    
	if (!isNaN(this.level)) {
		var n = parseInt(this.level);
		for (var i = n - 1; i >= 0; i--) {
			s += '&ndash; ';
		}
	}
	return s;
}
jsTmpl.prototype.fn.nl2br=function(s){
	return s.toString().replace(/\n/, '<br />');
}
jsTmpl.prototype.breadcrumb = function(data) {
	var self=this;
	if (document.querySelector('ol#breadcrumb')) {
		document.querySelector('ol#breadcrumb').innerHTML = '';
		if (data.breadcrumb&&Array.isArray(data.breadcrumb)) {
			document.querySelector('ol#breadcrumb').innerHTML = data.breadcrumb.map(function(value, index) {
				var text=value.text, mod=value.mod ? value.mod : '', act=value.act ? value.act : '', url=value.url ? value.url : '';
				delete value.text;
				delete value.mod;
				delete value.act;
				delete value.url;
				return '<li>' + 
				(mod ? ('<a click="goUrl" href="'+ self.settings.baseUrl + mod + '/' + act + 
					JSON.stringify(value).replace(/(\{"|"\:"?)/g, "/").replace(/(,"|"\}|^\{|\}$)/g, "") + 
					'">' + 
					(mod=='dashboard'||mod=='home' ? '<i class="fa fa-home"></i>' :'') + 
					'<span>' + (mod=='dashboard'||mod=='home'?'':text) + '</span></a>'
				) : (url ? ('<a click="goUrl" href="'+url+'"><span>'+text+'</span></a>') : text)) + 
				'</li>';
			}).join('')
		}
	}
}
jsTmpl.prototype.validateForm = function(el) {
	var required = el.querySelectorAll('input[required], textarea[required], select[required]'), 
	requiredLen = required.length,
	blurcallback=function(){
		var value=this.value,
		regex = this.getAttribute('pattern') ? (new RegExp(this.getAttribute('pattern'))): (new RegExp('^.+$'));
		this.className = this.className.replace(/\sinvalid/g, '');
		if (!regex.test(value)) {
			this.className += ' invalid';
		}
	};
	for (var i=0; required[i]; i++) {
		required[i].onblur=blurcallback;
		blurcallback.call(required[i]);
	}
	if (el.querySelectorAll('input[required].invalid, textarea[required].invalid, select[required].invalid').length) {
		return false
	}
	return true;
};
jsTmpl.prototype.createTemplateEngine=function(tmpl, texthtml, modact) {
	var i, j=-1, script_tmpl, tmp=document.createElement('div');
	while ((i=texthtml.indexOf('<script ')) > -1) {
		j = texthtml.indexOf('</script>', i);
		script_tmpl = texthtml.substr(i, j-i) + '</script>';
		texthtml = texthtml.replace(script_tmpl,'');
		tmp.innerHTML += script_tmpl;
		i=-1;
		j=-1;
	}
	script_tmpl = tmp.querySelectorAll('script[type="text/x-js-tmpl"][name]');
	for (var i=0; script_tmpl[i]; i++) {
		this.template(script_tmpl[i].getAttribute('name'), script_tmpl[i].innerHTML);
		script_tmpl[i].innerHTML='';
	}
	texthtml += tmp.outerHTML;
	this.template(tmpl, texthtml);
}
jsTmpl.prototype.evalScript=function(el) {
	var js = [], i, s;
	if (isElement(el)) {
		js = el.querySelectorAll('script[type="text/javascript"]');
	} else {
		if (typeof el=='string') {
			var t=document.createElement('div');
			t.innerHTML = el;
			js = t.querySelectorAll('script[type="text/javascript"]');
		}
	}
	for (i = 0; js[i]; i++) {
		s = document.createElement('script');
		s.appendChild(document.createTextNode(js[i].innerHTML));
		js[i].parentNode.removeChild(js[i]);
		document.querySelector('header').appendChild(s);
		s.parentNode.removeChild(s);
	}
}
jsTmpl.prototype.factory=function(opt){
	var tmpl = (this.mod ? this.mod:'_') + (this.act ? this.act:'_') + 'tmpl'+opt.status, me=this;
	var callback1 = function () {
		var dataset=JSON.parse(JSON.stringify(me.query));
		dataset.mod = me.mod;
		dataset.act = me.act;
		window.datasets = dataset;
		if (opt.data) {
			if (opt.selector==undefined) {
				return me.render(tmpl, opt.data, dataset);
			}
			if (document.querySelector(opt.selector)) {
				document.querySelector(opt.selector).innerHTML = me.render(tmpl, opt.data, dataset);
				me.evalScript(document.querySelector(opt.selector));
			}
		} else {
			if (opt.selector==undefined) {
				return me.render(tmpl,[{}]);
			}
			if (document.querySelector(opt.selector)) {
				document.querySelector(opt.selector).innerHTML = me.render(tmpl,[{}]);
				me.evalScript(document.querySelector(opt.selector));
			}
		}
		if (typeof opt.done=='function') {
			opt.done.call(me, opt.data)
		}
	};

	if (!this.template(tmpl)) {
		var tmp = document.createElement('div');
		if (opt.texthtml==undefined) {
			this.getTmpl({url:this.settings.baseUrl+this.mod+'/'+this.act, done:function(texthtml){
				me.createTemplateEngine(tmpl, texthtml);
				callback1();
			}});
		} else {
			this.createTemplateEngine(tmpl, opt.texthtml)
			callback1();
		}
	} else {
		callback1();
	}
};
jsTmpl.prototype.hideLoading=function(){if (document.getElementById('loading')) document.getElementById('loading').className=""}; 
jsTmpl.prototype.showLoading=function(){if (document.getElementById('loading')) document.getElementById('loading').className='run'};
jsTmpl.prototype.alert = function(message,title,type) {
	if (document.getElementsByTagName('main')) {
		var main=document.getElementsByTagName('main')[0];
		if (!document.getElementById('alertr')) {
			var div=document.createElement('div');
			div.id="alertr";
			div.appendChild(document.createElement('div'));
			main.insertBefore(div, main.childNodes[0]);
		}
		if (div = main.childNodes[0].childNodes[0]) {
			var msg=document.createElement('div');
			msg.className="alert alert-dismissible alert-" + (type == 1 ? "success":"danger");
			msg.innerHTML='<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' + message;
			div.appendChild(msg);
			setTimeout(function(){div.removeChild(msg)}, 5000);
		}
		document.documentElement.scrollTop = 0;
	} else {
		var main=document.createElement('main');
		main.style="background: rgba(0, 0, 0, 0.2); bottom: 0; left: 0; position: fixed; right: 0; top: 0; z-index: 999999999999";
		var div=document.createElement('div');
		div.style="background: #fff;border: 1px solid #ccc;box-sizing: border-box;height: 200px;left: 50%;margin-left: -150px;margin-top: -100px;padding-top: 20px;position: fixed;top: 50%;width: 300px";
		main.appendChild(div);
		var h5=document.createElement('h5');
		h5.style="border-bottom: 1px solid #f5f5f5;font-weight: bold;height: 20px;left: 0;margin: 0;padding: 2px 22px 2px 2px;position: absolute;top: 0;width: 100%";
		h5.innerHTML=title;
		div.appendChild(h5);
		var a=document.createElement('a');
		a.style="color: #999;cursor: pointer;height: 20px;line-height: 20px;position: absolute;right: 0;text-align: center;top: 0;width: 20px";
		a.innerHTML="&times";
		a.onmouseover=function(){this.style.color="#f00"}
		a.onmouseout=function(){this.style.color="#999"}
		a.onclick=function(){main.parentNode.removeChild(main)}
		div.appendChild(a);
		var div=document.createElement('div');
		div.style="float: left;height: 100%;overflow: auto;width: 100%";
		main.querySelector('div').appendChild(div);
		var div=document.createElement('div');
		div.style="display: table;height: 100%;width: 100%";
		main.querySelector('div>div').appendChild(div);
		var div=document.createElement('div');
		div.style="display: table-cell;text-align: center;vertical-align: middle";
		div.innerHTML=message;
		main.querySelector('div>div>div').appendChild(div);
		document.getElementsByTagName('body')[0].appendChild(main);
		document.documentElement.scrollTop = 0;
	}
}
jsTmpl.prototype.init = function() {
	var self=this;
	if (document.querySelector('script[type="text/x-navigation-tmpl"]')) {
		var tmp = document.querySelector('script[type="text/x-navigation-tmpl"]'),
		src=tmp.getAttribute('src');
		if (src) {
			this.template('@', tmp);
			this.getJson({
				url: src,
				done: function(response) {
					tmp.outerHTML = self.render('@', response.data);
				}
			});
		}
		try{var e=null,t=null;document.getElementById("swipedetect").addEventListener("touchstart",function(n){e=n.touches[0].clientX,t=n.touches[0].clientY},!1),document.getElementById("swipedetect").addEventListener("touchmove",function(n){if(e&&t){var c=n.touches[0].clientX,l=n.touches[0].clientY,u=e-c,o=t-l;Math.abs(u)>Math.abs(o)&&0>u&&(document.getElementById("left-side").className="collapse-left open"),e=null,t=null}},!1)}catch(n){}
	}
	if (document.querySelector('script[type="text/x-language-tmpl"]')) {
		this.template('language-tmpl', document.querySelector('script[type="text/x-language-tmpl"]'));
		document.querySelector('script[type="text/x-language-tmpl"]').outerHTML='';
	}
	this.init = null;
	console.log('!!!')
};
jsTmpl.prototype.languageChange = function(lang) {
	var me=this;
	if (!document.querySelector('#lang-control')) {
		try {
			var li=document.createElement('li');
			li.id="lang-control";
			li.className="dropdown";
			li.innerHTML='<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"></a>';
			li.innerHTML+='<ul class="dropdown-menu">' + 
			lang.list.map(function(value) {
				return '<li><a data-lang="'+value.lang+'"><i class="icon-lang-'+value.lang+'" value="'+value.lang+'"></i>'+value.name+'</a></li>';
			}).join("\n") + 
			'</ul>';
			document.querySelector('#navbar-right').appendChild(li);
		} catch (ex) {}
	}
	if (lang.list!=undefined && lang.list.length>1) {
		document.querySelector('#lang-control > a').innerHTML=document.querySelector('a[data-lang="'+lang.selected.lang+'"]').innerHTML+' <span class="caret"></span>';
		for (var i = 0; lang.list[i]; i++) {
			if (lang.list[i].href) {
				if (document.querySelector('a[data-lang="'+lang.list[i].lang+'"]')) {
					document.querySelector('a[data-lang="'+lang.list[i].lang+'"]').onclick=function(e){
						var curlang = document.querySelector('#lang-control > a [value]').getAttribute('value'),
						selectlang = this.querySelector('[value]').getAttribute('value');
						if (curlang!=selectlang) {
							document.querySelector('#lang-control > a').innerHTML=this.innerHTML+' <span class="caret"></span>';
							me.query.lang=this.dataset.lang;
							me.pushStateRun(me.toURI());
						}
					};
				}
			} else {
				if (document.querySelector('a[data-lang="'+lang.list[i].lang+'"]')) {
					document.querySelector('a[data-lang="'+lang.list[i].lang+'"]').onclick=function(e){
						var curlang = document.querySelector('#lang-control > a [value]').getAttribute('value'),
						selectlang = this.querySelector('[value]').getAttribute('value');
						if (curlang!=selectlang) {
							document.querySelector('#lang-control > a').innerHTML=this.innerHTML+' <span class="caret"></span>';
							var langControl=document.querySelectorAll('.form-control-lang.active');
							for (var i = 0; langControl[i]; i++) {
								langControl[i].className=langControl[i].className.replace(/ active /i, ' ');
							}
							var langControlA=document.querySelectorAll('.form-control-lang.'+this.dataset.lang);
							for (var i = 0; langControlA[i]; i++) {
								langControlA[i].className+=' active ';
							}
						}
					}
				}
			}
		}
		
	}
};
jsTmpl.prototype.Logout = function() {
	this.mod='logout';
	var me=this;
	this.get({url:this.toURI(),done:function(response){
		me.settings.userId=0;
		window.location = me.settings.baseUrl;
	}});
};
/*onClick_*/
jsTmpl.prototype.onClick_closeToggle = function(){
	var me=this;
	var tmp=document.querySelectorAll('.sidebar-menu > li.active');
	for (var i = 0; tmp[i]; i++) {
		if (!tmp[i].querySelector('ul span.active')) {
			tmp[i].className='';
			if (tmp[i].querySelector('ul')) {
				tmp[i].querySelector('ul').style.height='';
			}
		}
	}
}
jsTmpl.prototype.onClick_signIn = function(event) {
	var me=this;
	event.preventDefault();
	this.mod='login';
	this.act='checkpassword';
	this.postForm(this.toURI(), 'form', function (response) {
		if (response.status==1) {
			if (response.redirect) {
				window.location=response.redirect
			} else {
				try{
					document.body.innerHTML = document.querySelector('script[type="text/html-logged"]').innerHTML;
					me.settings.userId = response.userId;
					if (response.displayname) {
						document.querySelector('displayname').outerHTML = response.displayname
					}
					jsTmpl.getJson({
						/*url: me.settings.baseUrl+'index/navbar', */
						url: me.settings.navUrl, 
						done:function(response){
							document.querySelector('navigation').outerHTML = me.render('tmpl-navigation', response.data);
						}
					});
					var e=null,t=null;document.getElementById("swipedetect").addEventListener("touchstart",function(n){e=n.touches[0].clientX,t=n.touches[0].clientY},!1),document.getElementById("swipedetect").addEventListener("touchmove",function(n){if(e&&t){var c=n.touches[0].clientX,l=n.touches[0].clientY,u=e-c,o=t-l;Math.abs(u)>Math.abs(o)&&0>u&&(document.getElementById("left-side").className="collapse-left open"),e=null,t=null}},!1);
				}catch(n){}
			}
		}
	});
};
jsTmpl.prototype.onClick_submit = function(event) {
	var me=this;
	if (el = event.targetElement) {
		while (el.tagName != "FORM" && el.parentNode) {
			el = el.parentNode
		}
		if (el.tagName == "FORM") {
			event.preventDefault();
			if (this.validateForm(el)) {
				var formData = new FormData(el), 
				submitDone=event.targetElement.dataset.submitDone ? event.targetElement.dataset.submitDone : '', 
				submitFail=event.targetElement.dataset.submitFail ? event.targetElement.dataset.submitFail : '', 
				me=this;
				//formData.append(document.activeElement.name, document.activeElement.value);
				this.showLoading();
				$('.modal').modal('hide');
				this.postForm(el.action, el, function(response) {
					window.xhr = this;
					me.hideLoading();
					if (response.logout==1||response.denied==1) {
						window.location=me.settings.baseUrl;
					}
					if (submitDone!=undefined && typeof window[submitDone] == 'function') {
						window[submitDone].call(me, response);
					} else if (response.redirect) {
						//window.location=response.redirect;
						me.pushStateRun(response.redirect);
					} else {
						(response.status!=undefined) && (response.message!=undefined) && me.alert(response.message, response.title!=undefined?response.title:'', response.status);
						var dataset=JSON.parse(JSON.stringify(me.query));
						if (response.offsetRow) {
							dataset.offsetRow = response.offsetRow;
						}
						dataset.mod = me.mod;
						dataset.act = me.act;
						if (dataset.page) {
							dataset.page = "/page/" + dataset.page;
						}
						var script_tmpl = document.querySelectorAll('script[type="text/x-js-tmpl"][name][data][target]');
						for (var i = 0; script_tmpl[i]; i++) {
							var tmpl_name = script_tmpl[i].getAttribute('name'), 
							dataName = script_tmpl[i].getAttribute('data'), 
							target = script_tmpl[i].getAttribute('target'), 
							data = [];
							if (response[dataName]!=undefined && (Array.isArray(response[dataName]) || response[dataName].constructor=={}.constructor)) { 
								data = response[dataName]
							}
							if ((response[dataName]!=undefined||response.clear) && me.template(tmpl_name) && document.querySelector(target)) {
								document.querySelector(target).innerHTML = me.render(tmpl_name, data, dataset);
							}
						}
					}
				}, function(){
					me.hideLoading();
					if (submitFail!=undefined && typeof window[submitFail] == 'function') {
						window[submitFail].call(el);
					} else {
						me.alert('submit fail!','Fail', 0)
					}
				});
			}
		}
	}
};
jsTmpl.prototype.onClick_goUrl = function(e) {
	e.preventDefault();
	var me=this;
	var el = e.targetElement;
	if (e.targetElement.tagName=='A') {
		this.pushStateRun(e.targetElement.href)
	} else {
		if (el && el.dataset) {
			var url = (el.dataset.act && el.dataset.mod) ? (this.settings.baseUrl+'/'+el.dataset.mod+'/'+el.dataset.act) : (el.dataset.mod ? (this.settings.baseUrl+'/'+el.dataset.mod) :'');
			if (url) {
				this.pushStateRun(url);
			}
			/*if (el.dataset.act && el.dataset.mod) {
				window.location = this.options.baseUrl+'#'+el.dataset.mod+'/'+el.dataset.act
			} else if (el.dataset.mod) {
				window.location = this.options.baseUrl+'#'+el.dataset.mod
			}*/
		}
	}
};
jsTmpl.prototype.onClick_navChange = function(e) {
	e.preventDefault();
	var me=this, node;
	/*if (document.querySelector('#left-side .sidebar-menu span.active')) document.querySelector('#left-side .sidebar-menu span.active').className='';
	if (document.querySelector('#left-side .sidebar-menu span.active')) document.querySelector('#left-side .sidebar-menu span.active').className='';
	if (document.querySelector('#left-side .sidebar-menu span.active')) document.querySelector('#left-side .sidebar-menu span.active').className='';*/
	if (document.querySelector('#left-side .sidebar-menu span.active')) delClass(document.querySelector('#left-side .sidebar-menu span.active'), 'active');
	if (document.querySelector('#left-side .sidebar-menu span.active')) delClass(document.querySelector('#left-side .sidebar-menu span.active'), 'active');
	if (document.querySelector('#left-side .sidebar-menu span.active')) delClass(document.querySelector('#left-side .sidebar-menu span.active'), 'active');
	//e.targetElement.querySelector('span').className='active';
	addClass(e.targetElement.querySelector('span'), 'active');
	if (document.querySelector('#left-side .sidebar-menu .child-list-append.active')) {
		document.querySelector('#left-side .sidebar-menu .child-list-append.active').innerHTML='';
		document.querySelector('#left-side .sidebar-menu .child-list-append.active').className='child-list-append';
	}
	this.onClick_closeToggle();
	node = e.targetElement.parentNode;
	while (node = node.parentNode) {
		if (node.tagName=='UL'&&node.className=='tree') {
			//node.parentNode.className='active';
			addClass(node.parentNode, 'active');
			break
		}
	}
	if (e.targetElement.parentNode.getAttribute('level')=="0") {
		//e.targetElement.parentNode.className='active';
		addClass(e.targetElement.parentNode, 'active');
	}
	if (e.targetElement.tagName=='A') {
		this.pushStateRun(e.targetElement.href)
	}
};
jsTmpl.prototype.onClick_toggle = function(e) {
	var me=this;
	if (e.targetElement && e.targetElement.dataset.target) {
		var id = '#'+e.targetElement.dataset.target, height, toggleTarget; 
		if (toggleTarget = document.querySelector(id)) {
			height = toggleTarget.style.height;
			if (height) {
				toggleTarget.style.height='';
				e.targetElement.parentNode.className='';
			} else {
				toggleTarget.style.height= toggleTarget.dataset.height + 'px';
				e.targetElement.parentNode.className='active';
			}
		}
	}
};
jsTmpl.prototype.onClick_selectIcon = function(e) {
	var v=e.targetElement.getAttribute('value');
	e.targetElement.parentNode.parentNode.className = 'icon-dropdown';
	e.targetElement.parentNode.parentNode.querySelector('div').innerHTML='<span><i class="fa fa-'+v+'"></i></span>';
	e.targetElement.parentNode.parentNode.querySelector('input').value = v;
};
jsTmpl.prototype.onClick_active_modal = function(e) {
	var me=this;
};
jsTmpl.prototype.onClick_getUrlalias = function(e) {
	var me=this;
	e.preventDefault();
	if (!document.querySelector('main #getUrl')) {
		var div=document.createElement('div');
		div.className='modal fade modal-box';
		div.id='getUrl';
		div.innerHTML='<div class="backdrop" onClick="modal.hide(\'#getUrl\')"></div><div class="modal-dialog"><div class="modal-content"><button type="button" class="close" onClick="modal.hide(\'#getUrl\')" style="cursor: pointer;position: absolute;right: 0;top: 0;z-index: 99999">&times;</button><div class="modal-body"></div></div></div>';
		document.querySelector('main').appendChild(div);
	}
	modal.open('#getUrl');
	var url=e.targetElement.href;
	alert(url);
	this.getJson({
		url:url,
		done:function(response){

		}
	})
};

jsTmpl.prototype.onClick_search = function(e) {
	var me=this;
	var keyword = document.querySelector('#keyword') ? document.querySelector('#keyword').value : '';
	this.query.search = encodeURIComponent(keyword);
	if (this.query.page) {
		this.query.page = "1";
	}
	this.pushStateRun(this.toURI());
};
jsTmpl.prototype.onClick_confirmDelete = function(e) {
	e.preventDefault();
	if (document.querySelector('.modal.confirmDelete')) {
		var el=e.targetElement, j=Object.assign({}, el.dataset), k=Object.keys(j), me=this;
		document.querySelector('.modal.confirmDelete .modal-body').innerHTML = el.getAttribute('title') + k.map(function(v) {
			return '<input type="hidden" name="'+v+'" value="'+j[v]+'" />';
		}).join('');
		modal.open('.modal.confirmDelete');
		document.querySelector('.modal.confirmDelete form').onreset=function(e){
			modal.hide('.modal.confirmDelete');
		}
		document.querySelector('.modal.confirmDelete form').onsubmit=function(e){
			e.preventDefault();
			me.postForm(this.action, this, function(response){
				modal.hide('.modal.confirmDelete');
				if (response.status==1) {
					me.run();
				}
			});
		}
	}
};

/*  Mod Mod__act  */
/*  default callback  */
jsTmpl.prototype._ = function() {
	var me=this, 
	tmpl = (this.mod ? this.mod:'') +'-'+ (this.act ? this.act:'') + '-tmpl';
	var callback1 = function (response, dataset) {
		document.querySelector('main').innerHTML = me.render(tmpl, (response.data && (typeof response.data == "object") && response.data.constructor=={}.constructor) ? response.data : {} , dataset);
		var script_tmpl = document.querySelectorAll('script[type="text/x-js-tmpl"][name][data][target]');
		for (var i = 0; script_tmpl[i]; i++) {
			var tmpl_name = script_tmpl[i].getAttribute('name'), dataName = script_tmpl[i].getAttribute('data'), target = script_tmpl[i].getAttribute('target'), data=[];
			if (response[dataName]!=undefined && (Array.isArray(response[dataName]) || response[dataName].constructor=={}.constructor)) { 
				data = response[dataName]
			}
			if (me.template(tmpl_name) && document.querySelector(target)) {
				document.querySelector(target).innerHTML = me.render(tmpl_name, data, dataset);
			}
		}
		if (typeof me.settings.loaded=='function') {
			me.settings.loaded.call(me)
		}
		if (response.message) {
			me.alert(response.message, response.title!=undefined?response.title:'', response.status)
		}
	}
	this.showLoading();
	this.getJson({
		url: this.toURI(),
		done:function(response){
			me.hideLoading();
			if (response.logout==1||response.denied==1) {
				window.location=me.settings.baseUrl;
			}
			if (document.querySelector('main')) {
				document.querySelector('main').innerHTML = '';
			}
			if (response.status!=undefined && response.status!=0) {
				tmpl+=response.status;
				me.responseData = response;
				var dataset=JSON.parse(JSON.stringify(me.query));
				if (response.offsetRow) {
					dataset.offsetRow = response.offsetRow;
				}
				dataset.mod = me.mod;
				dataset.act = me.act;
				if (dataset.page) {
					dataset.page = "/page/" + dataset.page;
				}
				if (response.breadcrumb!=undefined) {
					me.breadcrumb(response)
				}
				if (response.navChild!=undefined&&response.navChild.name!=undefined&&response.navChild.list!=undefined && document.querySelector('#child-list-append-'+response.navChild.name)) {
					document.querySelector('#child-list-append-'+response.navChild.name).innerHTML = response.navChild.list.map(function(value) {
						return '<a href="'+value.url+'" click="goUrl">'+value.text+'</a>';
					}).join('');
					document.querySelector('#child-list-append-'+response.navChild.name).className='child-list-append active';
				}
				if (response.language!=undefined) {
					me.languageChange(response.language)
				} else {
					try{document.querySelector('#lang-control').remove()}catch(e){}
				}
				if (!me.template(tmpl)) {
					me.getTmpl({
						url: me.toURI(), 
						done:function(texthtml){
							me.createTemplateEngine(tmpl, texthtml, tmpl);
							callback1(response, dataset);
						}
					});
				} else {
					callback1(response, dataset);
				}
			} else {
			}
		},
		fail: function(){
			alert(000)
		}
	});
}
jsTmpl.prototype.Login_logout = function() {
	var me=this;
	this.get({url:this.toURI(),done:function(response){
		me.options.userId=0;
		window.location = me.options.baseUrl;
	}});
};
jsTmpl.prototype.Profile_ = function() {
	if (this.settings.userId==undefined||this.settings.userId==0) {
		window.location = '#!';
	} else {
		this.mod='profile';
		this.act='';
		var me = this;
		this.showLoading();
		this.getJson({
			url:this.toURI(), 
			done:function(response){
				me.hideLoading()
				if (response.logout==1||response.denied==1) {
					window.location=me.settings.baseUrl;
				}
				me.breadcrumb(response);
				try{document.querySelector('#lang-control').remove()}catch(e){}
				if (response.status!=undefined && response.status!=0) {
					me.factory({
						status: response.status, 
						mtime: response.mtime, 
						header: response.header, 
						data: response.data, 
						selector:'main' 
					});
				} else {
					me.factory({status:'', selector:'main'});
				}
			}, 
			fail: this.hideLoading
		})
		try {
			document.querySelector('#left-side .sidebar-menu span.active').className='';
			document.querySelector('#left-side .sidebar-menu span.active').className='';
		} catch (e) {}
		this.onClick_closeToggle();
	}
};
jsTmpl.prototype.User_ = function() {
	if (this.act.length>0) {
		return this._.call(this);
	}
	if (this.settings.userId==undefined||this.settings.userId==0) {
		window.location = '#!';
	} else {
		this.mod='user';
		this.act='';
		var me = this, jsonData, 
		process=function(data){
			var dataset=JSON.parse(JSON.stringify(me.query));
			dataset.offsetRow = data.offsetRow;
			dataset.mod = me.mod;
			dataset.act = me.act;
			if (dataset.page) {
				dataset.page = "/page/" + dataset.page;
			}
			document.querySelector('#tbody').innerHTML=me.render('tmpl-grid-user', data.rows, dataset ) ;
			document.querySelector('.pagination').innerHTML=me.render('tmpl-pagination', data.pagination);
			document.querySelector('#confirmDelete form').onsubmit=function(e){
				e.preventDefault();
				var formData = new FormData(this);
				formData.append(document.activeElement.name, document.activeElement.value);
				me.showLoading();
				$.ajax({
					url: me.toURI(),
					type: "POST",
					data: formData, 
					processData: false,
					contentType: false,
					success: function (data) {
						me.hideLoading();
						if (data.logout==1||response.denied==1) {
							window.location=me.settings.baseUrl;
						}
						me.onClick_closeToggle();
						if (data.status==1) {
							me.readyState=true;
							delete me.query.page;
							location = me.toHash();
							process(data);
						}
						$('#confirmDelete').modal('hide');
					}
				}).fail(me.hideLoading);
			}
		};
		this.showLoading();
		this.getJson({
			url: this.toURI(),
			done:function(response){
				me.hideLoading();
				if (response.logout==1||response.denied==1) {
					window.location=me.settings.baseUrl;
				}
				if (response.status!=undefined && response.status!=0) {
					me.breadcrumb(response);
					try{document.querySelector('#lang-control').remove()}catch(e){}
					me.factory({
						status: response.status, 
						mtime: response.mtime, 
						data: response,
						selector:'main',
						done:function(response){
							process(response);
							$('#confirmDelete').on('show.bs.modal', function(event){
								var button = $(event.relatedTarget);
								document.querySelector('#confirmDelete input[name="id"]').value = button.data('id');
								document.querySelector('#confirmDelete input[name="username"]').value = button.data('username');
								document.querySelector('[field-name="username"]').innerHTML = button.data('username');
							})
						}
					});
				}
			},
			fail: this.hideLoading
		})
	}
};
jsTmpl.prototype.User_add = function() {
	if (this.settings.userId==undefined||this.settings.userId==0) {
		window.location = '#!';
	} else {
		var me = this;
		this.showLoading();
		this.getJson({
			url:this.toURI(), 
			done:function(response){
				window.response = response;
				if (response.logout==1||response.denied==1) {
					window.location=me.settings.baseUrl;
				}
				me.hideLoading()
				me.breadcrumb(response);
				try{document.querySelector('#lang-control').remove()}catch(e){}
				if (response.status!=undefined && response.status!=0) {
					me.factory({
						status: response.status, 
						mtime: response.mtime, 
						data: response.data, 
						done: loaded, 
						selector: 'main'
					});
				} else {
					me.factory({
						status:'',
						mtime:response.mtime, 
						done:loaded,
						selector:'main'
					});
				}
			}, 
			fail: this.hideLoading
		})
	}
};
jsTmpl.prototype.User_edit = function() {
	if (this.settings.userId==undefined||this.settings.userId==0) {
		window.location = '#!';
	} else {
		var me = this;
		this.showLoading();
		this.getJson({
			url:this.toURI(), 
			done:function(response){
				me.hideLoading();
				if (response.logout==1||response.denied==1) {
					window.location=me.settings.baseUrl;
				}
				me.breadcrumb(response);
				try{document.querySelector('#lang-control').remove()}catch(e){}
				if (response.status!=undefined && response.status!=0) {
					me.factory({
						status:response.status, 
						mtime:response.mtime, 
						data:response.data, 
						done:loaded,
						selector:'main'
					});
				} else {
					me.factory({
						status:'',
						mtime:response.mtime, 
						done:loaded,
						selector:'main'
					});
				}
			}, 
			fail: this.hideLoading
		})
	}
};
jsTmpl.prototype.Role_ = function() {
	if (this.settings.userId==undefined||this.settings.userId==0) {
		window.location = '#!';
	} else {
		this.mod='role';
		this.act='';
		var me = this;
		this.showLoading();
		this.getJson({
			url: this.toURI(),
			done:function(response){
				me.hideLoading();
				if (response.logout==1||response.denied==1) {
					window.location=me.settings.baseUrl;
				}
				me.breadcrumb(response);
				try{document.querySelector('#lang-control').remove()}catch(e){}
				/*alert(12);
				alert(response.message);*/
				// if (response.message) {
				// 	me.alert(response.message, response.title!=undefined?response.title:'', response.status)
				// }
				if (response.status!=undefined && response.status!=0) {
					me.factory({
						status:response.status, 
						mtime:response.mtime, 
						data: response,
						selector:'main',
						done:function(response){
							process(response);
						}
					});
				}
			},
			fail: this.hideLoading
		});
		function process(data) {
			var dataset=JSON.parse(JSON.stringify(me.query));
			dataset.offsetRow = data.offsetRow;
			dataset.mod = me.mod;
			dataset.act = me.act;
			if (dataset.page) {
				dataset.page = "/page/" + dataset.page;
			}
			if (document.querySelector('#role-id')) {
				document.querySelector('#role-id').onchange = function(e) {
					document.querySelector('.box-body.permission').className = this.value != "0" ? 'box-body permission':'box-body permission hidden';
					if (this.value) {
						me.showLoading();
						me.getJson({
							url: me.toURI() + '?rolepermission=rolepermission&roleid='+this.value,
							done:function(response){
								me.hideLoading();
								if (response.status==1) {
									$('input[type="checkbox"][name="permissions[]"]').prop('checked', false);
									for (var i=0; response.permission[i]; i++) {
										document.querySelector('input[type="checkbox"][value="'+response.permission[i]+'"][name="permissions[]"]').checked=true
									}
								}
							},
							fail: me.hideLoading
						});
						// if (data.message) {
						// 	me.alert(data.message, data.title!=undefined?data.title:'', data.status)
						// }
					}
				}
				if (data.roleName && me.template('tmpl-select-role-id')) {
					document.querySelector('#role-id').innerHTML=me.render('tmpl-select-role-id', data.roleName);
				}
			}
			if (data.roleName && me.template('tmpl-tbody-roles') && document.querySelector('#tbody')) {
				document.querySelector('#tbody').innerHTML=me.render('tmpl-tbody-roles', data.roleName);
			}
			if (data.permission && me.template('tmpl-permission') && document.querySelector('#permission')) {
				document.querySelector('#permission').innerHTML=me.render('tmpl-permission', data.permission);
			}
			$('#confirmDelete').on('show.bs.modal', function(event){
				var button = $(event.relatedTarget);
				document.querySelector('#confirmDelete [name="id"]').value = button.data('id');
				document.querySelector('#confirmDelete [name="name"]').value = button.data('name');
				document.querySelector('#confirmDelete [alt="name"]').innerHTML = button.data('name');
			});
			$('#roleForm').on('show.bs.modal', function(event){
				var button = $(event.relatedTarget);
				document.querySelector('#roleForm button[click="submit"]').value = button.data('button');
				if (button.data('button')=='EDIT') {
					document.querySelector('#roleForm [name="id"]').value = button.data('id');
					document.querySelector('#roleForm [name="name"]').value = button.data('name');
					document.querySelector('#roleForm [name="description"]').value = button.data('description');
					document.querySelector('#roleForm [name="actived"]').checked = button.data('actived')==1 ? true : false;
				} else {
					document.querySelector('#roleForm [name="id"]').value = '';
					document.querySelector('#roleForm [name="name"]').value = '';
					document.querySelector('#roleForm [name="description"]').value = '';
					document.querySelector('#roleForm [name="actived"]').checked = false;
				}
			});
		};
	}
};
jsTmpl.prototype.Page_ = function() {
	/*if (this.act.length>0) {
		return this._.call(this);
	}*/
	if (this.settings.userId==undefined||this.settings.userId==0) {
		window.location = '/';
	} else {
		this.mod='page';
		this.act='';
		var me = this, jsonData, 
		process=function(data){
			var dataset=JSON.parse(JSON.stringify(me.query));
			dataset.offsetRow = data.offsetRow;
			dataset.mod = me.mod;
			dataset.act = me.act;
			if (dataset.page) {
				dataset.page = "/page/" + dataset.page;
			}
			document.querySelector('#tbody').innerHTML=me.render('tmpl-grid-user', data.rows, dataset ) ;
			document.querySelector('.pagination').innerHTML=me.render('tmpl-pagination', data.pagination);
			document.querySelector('#confirmDelete form').onsubmit=function(e){
				e.preventDefault();
				var formData = new FormData(this);
				formData.append(document.activeElement.name, document.activeElement.value);
				me.showLoading();
				$.ajax({
					url: me.toURI(),
					type: "POST",
					data: formData, 
					processData: false,
					contentType: false,
					success: function (data) {
						me.hideLoading();
						if (data.logout==1||response.denied==1) {
							window.location=me.settings.baseUrl;
						}
						me.onClick_closeToggle();
						if (data.status==1) {
							me.readyState=true;
							delete me.query.page;
							location = me.toHash();
							process(data);
						}
						$('#confirmDelete').modal('hide');
					}
				}).fail(me.hideLoading);
			}
		};
		this.showLoading();
		this.getJson({
			url: this.toURI(),
			done:function(response){
				me.hideLoading();
				if (response.logout==1||response.denied==1) {
					window.location=me.settings.baseUrl;
				}
				if (response.status!=undefined && response.status!=0) {
					if (response.navChild!=undefined && response.navChild.name!=undefined && response.navChild.list!=undefined && document.querySelector('#child-list-append-'+response.navChild.name)) {
						document.querySelector('#child-list-append-'+response.navChild.name).innerHTML = response.navChild.list.map(function(value) {
								if (value.active) {
									return '<a href="'+value.url+'" click="goUrl" style="color:#fff;font-weight:bold">'+value.text+'</a>';
								}
								return '<a href="'+value.url+'" click="goUrl">'+value.text+'</a>';
							}).join('');
						document.querySelector('#child-list-append-'+response.navChild.name).className='child-list-append active';
					}
					me.breadcrumb(response);
					try{document.querySelector('#lang-control').remove()}catch(e){}
					me.factory({
						status:response.status, 
						//header:response.header,
						data: response,
						// selector:'#content',
						selector:'main',
						done:function(response){
							process(response);
							$('#confirmDelete').on('show.bs.modal', function(event){
								var button = $(event.relatedTarget);
								document.querySelector('#confirmDelete input[name="id"]').value = button.data('id');
								document.querySelector('#confirmDelete input[name="username"]').value = button.data('username');
								document.querySelector('[field-name="username"]').innerHTML = button.data('username');
							})
						}
					});
				}
			},
			fail: this.hideLoading
		})
	}
};
jsTmpl.prototype.Page_set = function() {
	/*if (this.act.length>0) {
		return this._.call(this);
	}*/
	if (this.settings.userId==undefined||this.settings.userId==0) {
		window.location = '/';
	} else {
		this.mod='page';
		this.act='set';
		var me = this, jsonData, 
		process=function(data){
			var dataset=JSON.parse(JSON.stringify(me.query));
			dataset.offsetRow = data.offsetRow;
			dataset.mod = me.mod;
			dataset.act = me.act;
			if (dataset.page) {
				dataset.page = "/page/" + dataset.page;
			}
			document.querySelector('#tbody').innerHTML=me.render('tmpl-grid-user', data.rows, dataset ) ;
			document.querySelector('.pagination').innerHTML=me.render('tmpl-pagination', data.pagination);
			document.querySelector('#confirmDelete form').onsubmit=function(e){
				e.preventDefault();
				var formData = new FormData(this);
				formData.append(document.activeElement.name, document.activeElement.value);
				me.showLoading();
				$.ajax({
					url: me.toURI(),
					type: "POST",
					data: formData, 
					processData: false,
					contentType: false,
					success: function (data) {
						me.hideLoading();
						if (data.logout==1||response.denied==1) {
							window.location=me.settings.baseUrl;
						}
						me.onClick_closeToggle();
						if (data.status==1) {
							me.readyState=true;
							delete me.query.page;
							location = me.toHash();
							process(data);
						}
						$('#confirmDelete').modal('hide');
					}
				}).fail(me.hideLoading);
			}
		};
		this.showLoading();
		this.getJson({
			url: this.toURI(),
			done:function(response){
				me.hideLoading();
				if (response.logout==1||response.denied==1) {
					window.location=me.settings.baseUrl;
				}
				if (response.status!=undefined && response.status!=0) {
					if (response.navChild!=undefined && response.navChild.name!=undefined && response.navChild.list!=undefined && document.querySelector('#child-list-append-'+response.navChild.name)) {
						//alert(1)
						document.querySelector('#child-list-append-'+response.navChild.name).innerHTML = response.navChild.list.map(function(value) {
								return '<a href="'+value.url+'" click="goUrl">'+value.text+'</a>';
							}).join('');
						document.querySelector('#child-list-append-'+response.navChild.name).className='child-list-append active';
					}
					me.breadcrumb(response);
					try{document.querySelector('#lang-control').remove()}catch(e){}
					me.factory({
						status:response.status, 
						//header:response.header,
						data: response,
						// selector:'#content',
						selector:'main',
						done:function(response){
							process(response);
							$('#confirmDelete').on('show.bs.modal', function(event){
								var button = $(event.relatedTarget);
								document.querySelector('#confirmDelete input[name="id"]').value = button.data('id');
								document.querySelector('#confirmDelete input[name="username"]').value = button.data('username');
								document.querySelector('[field-name="username"]').innerHTML = button.data('username');
							})
						}
					});
				}
			},
			fail: this.hideLoading
		})
	}
};
jsTmpl.prototype.Findex_ = function() {
	var me=this, 
	tmpl = (this.mod ? this.mod:'') +'-'+ (this.act ? this.act:'') + '-tmpl';
	var callback1 = function (response, dataset) {
		document.querySelector('main').innerHTML = me.render(tmpl, (response.data && (typeof response.data == "object") && response.data.constructor=={}.constructor) ? response.data : {} , dataset);
		var script_tmpl = document.querySelectorAll('script[type="text/x-js-tmpl"][name][data][target]');
		//console.log(script_tmpl);
		for (var i = 0; script_tmpl[i]; i++) {
			var tmpl_name = script_tmpl[i].getAttribute('name'), data = script_tmpl[i].getAttribute('data'), target = script_tmpl[i].getAttribute('target');
			if (me.template(tmpl_name) && (Array.isArray(response[data]) || response[data].constructor=={}.constructor) && document.querySelector(target)) {
				document.querySelector(target).innerHTML = me.render(tmpl_name, response[data], dataset);
			}
		}
		// me.evalScript(document.querySelector('main'));
		if (typeof me.settings.loaded=='function') {
			me.settings.loaded.call(me)
		}
	}
	this.showLoading();
	this.getJson({
		url: this.toURI(),
		done:function(response){
			me.hideLoading();
			if (response.logout==1||response.denied==1) {
				window.location=me.settings.baseUrl;
			}
			if (document.querySelector('main')) {
				document.querySelector('main').innerHTML = '';
				//document.querySelector('main').innerHTML = '<div class="content-header"><h1 class="pull-left hidden-xs" id="h1"></h1><ol class="breadcrumb" id="breadcrumb"></ol><div class="pull-right pt15" id="actions"></div></div><section class="content" id="content"></section>';
			}
			if (response.status==1) {
				//alert(tmpl)
				me.responseData = response;
				//window.responseData = response;
				var dataset=JSON.parse(JSON.stringify(me.query));
				if (response.offsetRow) {
					dataset.offsetRow = response.offsetRow;
				}
				dataset.mod = me.mod;
				dataset.act = me.act;
				if (dataset.page) {
					dataset.page = "/page/" + dataset.page;
				}
				if (response.breadcrumb!=undefined) {
					//me.headercontent(response.header)
					me.breadcrumb(response)
				}
				if (response.navChild!=undefined&&response.navChild.name!=undefined&&response.navChild.list!=undefined && document.querySelector('#child-list-append-'+response.navChild.name)) {
					document.querySelector('#child-list-append-'+response.navChild.name).innerHTML = response.navChild.list.map(function(value) {
						return '<a href="'+value.url+'" click="goUrl">'+value.text+'</a>';
					}).join('');
					document.querySelector('#child-list-append-'+response.navChild.name).className='child-list-append active';
				}
				if (response.language!=undefined) {
					me.languageChange(response.language)
				} else {
					try{document.querySelector('#lang-control').remove()}catch(e){}
				}

				if (!me.template(tmpl)) {
					me.getTmpl({
						url: me.toURI(), 
						done:function(texthtml){
							me.createTemplateEngine(tmpl, texthtml, tmpl);
							callback1(response, dataset);
						}
					});
				} else {
					callback1(response, dataset);
				}
			} else {

			}
		},
		fail: function(){
			alert(000)
		}
	})
	/*if (document.querySelector('#left-side .sidebar-menu span.active')) document.querySelector('#left-side .sidebar-menu span.active').className='';
	if (document.querySelector('#left-side .sidebar-menu span.active')) document.querySelector('#left-side .sidebar-menu span.active').className='';
	if (document.querySelector('#left-side .sidebar-menu span.active')) document.querySelector('#left-side .sidebar-menu span.active').className='';
	this.onClick_closeToggle();
	if (document.querySelector('i.cabinet')) document.querySelector('i.cabinet').parentNode.parentNode.className='active';
	var path=JSON.parse(JSON.stringify(this.query)), url=this.options.baseUrl + this.mod + '/-?', me=this;
	delete path.mod;
	delete path.act;
	url+=JSON.stringify(path).replace(/^\{"|"\}$/g, "").replace(/"[\:,]"/g, "/").replace('{}','');
	console.log()
	this.showLoading();
	this.get({
		url: url,
		done:function(response){
			me.hideLoading();
		}
	});*/
};
/*onContextmenu_*/
jsTmpl.prototype.onContextmenu_fileman = function(e) {
	console.log(e.targetElement)
	console.log(e.targetElement.getAttribute('context'));
};
/* common */

/*

path=JSON.parse(JSON.stringify(jsTmpl.__))
url=jsTmpl.options + jsTmpl.__.mod + '-?'
	delete path.mod;
	delete path.act;
	url+=JSON.stringify(path).replace(/^\{"|"\}$/g, "").replace(/"[\:,]"/g, "/");
	console.log()
	jsTmpl.showLoading();
	this.get({
		url: url,
		done:function(response){

		}
	});







*/

/*jsTmpl.prototype.submit_UserF=function(e) {
	console.log(this);
	e.preventDefault();
	console.log(htAdmin);

}*/