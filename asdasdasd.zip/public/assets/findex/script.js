var treeToggle = document.querySelectorAll('a[role="tree-toggle"]');
for (var i=0; i<treeToggle.length; i++) {
    treeToggle[i].onclick = function (e) {
        e.preventDefault();
        var ul = this.parentNode.getElementsByTagName('UL');
        ul = ul.length>0 ? ul.item(0) : null;
        if (ul) {
            if (!ul.getAttribute('value')) {
                ul.setAttribute('value', ul.getElementsByTagName('A').length);
            }
            if (this.parentNode.className != 'active' && ul.getAttribute('value')) {
                ul.style.height = ul.getAttribute('value')*30 + 'px';
                this.parentNode.className = 'active';
            } else {
                ul.style.height = '';
                this.parentNode.className = '';
            }
        }
    }
}

(function(items) {
    var $_THIS=this;
    this.urlAction=function(act) {
        url = location.href.split('/');
        url[5] = act;
        url = url.join('/');
        return url;
    };
    this.closeAllPopup=function(){
        var forms = document.querySelectorAll('#backdrop-static form');
        for (var i = 0; i < forms.length; i++) {
            forms[i].style.display = 'none';
        } 
        document.getElementById('backdrop-static').style.display = 'none';
        document.getElementById('view-image').style.display = 'none';
    }
    var mcpBox=function(type, message, callbackOK, callbackCancel) {
        document.getElementById('backdrop-static').style.display = 'block';
        document.querySelector('#backdrop-static form[name="' +type+ '"]').style.display='inline-block';
        document.querySelector('#backdrop-static form[name="' +type+ '"] button[name="true"]').onclick=function(e) {
            $_THIS.closeAllPopup();
            if (typeof callbackOK=='function') {
                callbackOK.call(this)
            }
            document.querySelector('#backdrop-static form[name="' +type+ '"]').reset();
            document.querySelector('#backdrop-static form[name="' +type+ '"] strong').innerHTML='';
            if (this.parentNode.parentNode.querySelector('input[type="text"][name="max-width"]')) {
                this.parentNode.parentNode.querySelector('input[type="text"][name="max-width"]').value='';
                this.parentNode.parentNode.querySelector('input[type="text"][name="max-width"]').disabled=true;
            }
            if (this.parentNode.parentNode.querySelector('input[type="text"][name="max-height"]')) {
                this.parentNode.parentNode.querySelector('input[type="text"][name="max-height"]').value='';
                this.parentNode.parentNode.querySelector('input[type="text"][name="max-height"]').disabled=true;
            }
        }
        document.querySelector('#backdrop-static form[name="' +type+ '"] button[name="false"]').onclick=function(e) {
            $_THIS.closeAllPopup();
            if (typeof callbackCancel=='function') {
                callbackOK.call(this)
            }
            document.querySelector('#backdrop-static form[name="' +type+ '"]').reset();
            document.querySelector('#backdrop-static form[name="' +type+ '"] strong').innerHTML='';
            if (this.parentNode.parentNode.querySelector('input[type="text"][name="max-width"]')) {
                this.parentNode.parentNode.querySelector('input[type="text"][name="max-width"]').value='';
                this.parentNode.parentNode.querySelector('input[type="text"][name="max-width"]').disabled=true;
            }
            if (this.parentNode.parentNode.querySelector('input[type="text"][name="max-height"]')) {
                this.parentNode.parentNode.querySelector('input[type="text"][name="max-height"]').value='';
                this.parentNode.parentNode.querySelector('input[type="text"][name="max-height"]').disabled=true;
            }
        }
        document.querySelector('#backdrop-static form[name="' +type+ '"] strong').innerHTML=message;
    };
    this.confirmDelete=function(message, callbackOK, callbackCancel) { mcpBox('confirm-delete', message, callbackOK, callbackCancel)};
    this.promptRename=function(message, callbackOK, callbackCancel) { mcpBox('prompt-rename', message, callbackOK, callbackCancel)};
    this.promptResize=function(message, callbackOK, callbackCancel) { mcpBox('prompt-resize', message, callbackOK, callbackCancel)};
    document.querySelector('#backdrop-static form[name="prompt-resize"]').onclick=function(e){
        if (e.target.tagName=='INPUT' && e.target.type=='radio') {
            if (e.target.checked && e.target.value=="0") {
                this.querySelector('input[type="text"][name="max-width"]').disabled=false;
                this.querySelector('input[type="text"][name="max-height"]').disabled=false;
            } else {
                this.querySelector('input[type="text"][name="max-width"]').disabled=true;
                this.querySelector('input[type="text"][name="max-height"]').disabled=true;
            }
        }
    }
    this.GetA=function(a,b){(typeof a=='object'&&(x=a[1],a=a[0])),window.XMLHttpRequest?(XMLRequest=new XMLHttpRequest,XMLRequest.onreadystatechange=function(){4==XMLRequest.readyState&&200==XMLRequest.status&&"function"==typeof b&&(null!=XMLRequest.responseXML?b.call(this,XMLRequest.responseXML):b.call(this,XMLRequest.responseText))},XMLRequest.open("GET",a,!0),XMLRequest.setRequestHeader('x-header', typeof x!='undefined'?x:'1'),XMLRequest.send(null)):window.ActiveXObject&&(XMLRequest=new ActiveXObject("Microsoft.XMLHTTP"),XMLRequest&&(XMLRequest.onreadystatechange=function(){4==XMLRequest.readyState&&200==XMLRequest.status&&"function"==typeof b&&(null!=XMLRequest.responseXML?b.call(this,XMLRequest.responseXML):b.call(this,XMLRequest.responseText))},XMLRequest.open("GET",a,!0),XMLRequest.setRequestHeader('x-header', typeof x!='undefined'?x:'1'),XMLRequest.send()))};
    this.PostA=function(a,b,c){(typeof a=='object'&&(x=a[1],a=a[0])),window.XMLHttpRequest?(XMLRequest=new XMLHttpRequest,XMLRequest.onreadystatechange=function(){4==XMLRequest.readyState&&200==XMLRequest.status&&"function"==typeof c&&(null!=XMLRequest.responseXML?c.call(this,XMLRequest.responseXML):c.call(this,XMLRequest.responseText))},XMLRequest.open("POST",a,!0),XMLRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded"),XMLRequest.setRequestHeader('x-header', typeof x!='undefined'?x:'1'),XMLRequest.send(b)):window.ActiveXObject&&(XMLRequest=new ActiveXObject("Microsoft.XMLHTTP"),XMLRequest&&(XMLRequest.onreadystatechange=function(){4==XMLRequest.readyState&&200==XMLRequest.status&&"function"==typeof c&&(null!=XMLRequest.responseXML?c.call(this,XMLRequest.responseXML):c.call(this,XMLRequest.responseText))},XMLRequest.open("POST",a,!0),XMLRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded"),XMLRequest.setRequestHeader('x-header', typeof x!='undefined'?x:'1'),XMLRequest.send(b)))};
    this.getH=function(){if(window.innerHeight!=undefined){return window.innerHeight}else{var B=document.body,D=document.documentElement;return Math.max(D.clientHeight,B.clientHeight)}};
    this.getW=function(){if(window.innerWidth!=undefined){return window.innerWidth;}else{var B=document.body, D=document.documentElement;return Math.max(D.clientWidth, B.clientWidth)}};
    var getItem = function ( el ) {
        if ( el.getAttribute && el.getAttribute('role') && el.getAttribute('role')=='fileitem' ) {
            return el;
        } else {
            while ( el = el.parentNode ) {
                if ( el.getAttribute && el.getAttribute('role') && el.getAttribute('role')=='fileitem' ) {
                    return el;
                }
            }
        }
        return false;
    }
    var menuItem = items || {}
    var condContext = function ( e ) {
        try {
            var el = e.srcElement || e.target;    
            if ( el.getAttribute('context') ) {
                return el;
            } else {
                while ( el = el.parentNode ) {
                    if ( el && el.getAttribute('context') ) {
                        return el;
                    }
                }
            }
        } catch (ex) {}
        return false;
    }
    var condViewImage = function ( e ) {
        var el = e.srcElement || e.target;    
        if ( el.getAttribute && el.getAttribute('role') && el.getAttribute('role')=='view-image' ) {
            return el;
        } else {
            while ( el = el.parentNode ) {
                if ( el.getAttribute && el.getAttribute('role') && el.getAttribute('role')=='view-image' ) {
                    return el;
                }
            }
        }
        return false;
    }
    var getContextItems = function (e) {
        var el = e.srcElement || e.target;
        if ( el.getAttribute('context') ) {
            var s = el.getAttribute('context').replace(/\s+/g,' ').replace(/(^[\s]+|[\s]+$)/g, '');
            return s.length ? s.substr(s.indexOf(';')+1).split(';') : [];
        } else {
            while ( el = el.parentNode ) {
                if ( el.getAttribute('context') ) {
                    var s = el.getAttribute('context').replace(/\s+/g,' ').replace(/(^[\s]+|[\s]+$)/g, '');
                    return s.length ? s.substr(s.indexOf(';')+1).split(';') : [];
                }
            }
        }
        return null;
    }
    var createContextmenu = function (argument) {
        if (document.getElementById('contextmenu')) {
            document.getElementById('contextmenu').parentNode.removeChild(document.getElementById('contextmenu'));
        }
        var div = document.createElement('div');
        var elul = document.createElement('ul');
        div.appendChild(elul);
        elul.id = 'contextmenu';
        for (var i = 0; i < argument.length; i++) {
            var li = document.createElement('li');
            var a = document.createElement('a');
            var v = argument[i].split(':');
            li.setAttribute('contextvalue', v[0]);
            a.innerHTML = v[1];
            a.onclick = function(e){
                if (typeof menuItem[this.parentNode.getAttribute('contextvalue')] == 'function') {
                    menuItem[this.parentNode.getAttribute('contextvalue')].call(this, $_THIS)
                }
            }
            li.appendChild(a);
            elul.appendChild(li);
        }
        document.querySelector('body').appendChild(elul);
        return elul;
    }
    document.addEventListener('click', function(e){
        if (document.getElementById('contextmenu')) {
            document.getElementById('contextmenu').parentNode.removeChild(document.getElementById('contextmenu'));
        }
        if (_target = condViewImage(e)) {
            e.preventDefault();
            var $viewImage = document.getElementById('view-image');
            var img = document.createElement('img');
            if ($viewImage && _target.tagName == 'A') {
                img.src = _target.href;
            } 
            if ($viewImage && _target.tagName == 'IMG') {
                img.src = _target.src;
            }
            $viewImage.children[0].appendChild(img);
            $viewImage.style.display = 'block';
            setTimeout(function(){$viewImage.className = 'op'}, 100);
        }
    });
    document.addEventListener( "contextmenu", function(e) {
        var cond = condContext(e);
        if (cond) {
            e.preventDefault();
            window.elt = cond;
            $_THIS.item = getItem(cond);
            var contextmenu=null;
            contextmenu = createContextmenu(getContextItems(e));
            if (contextmenu) {
                contextmenu
                var X = e.clientX + scrollX;
                var Y = e.clientY + scrollY;
                var W = contextmenu.offsetWidth;
                var H = contextmenu.offsetHeight;
                contextmenu.style.left = (X + W) >=$_THIS.getW() ? (X - W + 5 + 'px') : (X - 5 + 'px');
                contextmenu.style.top = (Y + H) >=$_THIS.getH() ? (Y - H + 5 + 'px') : (Y - 5 + 'px');
                
            }
        } else {
            var el = e.srcElement || e.target; 
            if ( el.tagName=='FORM' ) {
                document.getElementById('fileman').className = 'box-body';
                return;
            } else {
                while ( el = el.parentNode ) {
                    if ( el.tagName=='FORM' ) {
                        document.getElementById('fileman').className = 'box-body';
                        return ;
                    }
                }
            }
        }
    });

    document.getElementById('fileman').ondrag = function(e){e.preventDefault();e.stopPropagation();}
    document.getElementById('fileman').ondragstart = function(e){e.preventDefault();e.stopPropagation();}
    document.getElementById('fileman').ondragend = function(e){
        e.preventDefault();
        e.stopPropagation();
        this.className = 'box-body';
    }
    document.getElementById('fileman').ondragover = function(e){
        e.preventDefault();
        e.stopPropagation();
        this.className = 'box-body dragover';
    }
    document.getElementById('fileman').ondragenter = function(e){
        e.preventDefault();
        e.stopPropagation();
        this.className = 'box-body dragover';
    }
    document.getElementById('fileman').ondragleave = function(e){
        e.preventDefault();
        e.stopPropagation();
        this.className = 'box-body';
    }
    document.getElementById('fileman').ondrop = function(e){
        
    }
    /*  upload  */
    var _IF = document.querySelectorAll('input[type="file"]');
    for (var i=0; i<_IF.length; i++) {
        _IF.item(i).onchange=function(e){
            var context = this.parentNode.getAttribute('data-context'),
            contextImage = this.parentNode.getAttribute('data-context-image'),
            formData = new FormData(this.parentNode),
            request = new XMLHttpRequest();
            request.open("POST", this.parentNode.action);
            request.onreadystatechange = function(){
                if (request.readyState == 4 && request.status == 200){
                    try {
                        json = JSON.parse(request.responseText);
                    } catch (ex) {}
                    if (json && json.status==1) {
                        var div = document.createElement('div');
                        div.className = 'file-item';
                        div.setAttribute('role', "fileitem");
                        div.setAttribute('value', json.filename);
                        div.setAttribute('type', 'file');
                        div.innerHTML = '<div>'
                            +'<div class="text-center valign-middle">'
                            + (json.fileinfo.type=='image' ? ('<img src="'+json.src+'" context="' +contextImage+ '" />'):('<i class="fa fa-file-o fa-3x" style="color:#000" title="'+json.fileinfo.mime+'" context="' +context+ '"></i>'))
                            +'</div>'
                        +'</div>'
                        +'<div>'
                            +'<div class="text-center">'
                                +'<a context="' +context+ '" href="'+json.src+'" target="_blank" title="'+json.filename+'">'+json.filename+'</a>'
                                +'<span context="' +context+ '" class="size">'+json.fileinfo.size+'</span>'
                            +'</div>'
                        +'</div>';
                        document.getElementById('fileman').children[0].appendChild(div);
                    }
                }
            };
            request.send(formData);
            this.parentNode.reset();
            document.getElementById('fileman').className = 'box-body';
        };
    }
    window.viewImage = function (_this) {
        var $viewImage = document.getElementById('view-image');    
        $viewImage.children[0].appendChild(_this.cloneNode());
        $viewImage.style.display = 'block';
        setTimeout(function(){$viewImage.className = 'op'}, 100);
    }
})({
    resize:function($JS){
        var itemName = $JS.item.getAttribute('value'), 
        type = $JS.item.getAttribute('type');
        $JS.promptResize(itemName, function(){
            var rdChecked = document.querySelector('#backdrop-static form[name="prompt-resize"] input[type="radio"]:checked');
            if (rdChecked) {
                var value = rdChecked.value=='0' ? (document.querySelector('#backdrop-static form[name="prompt-resize"] input[name="max-width"]').value +','+ document.querySelector('#backdrop-static form[name="prompt-resize"] input[name="max-height"]').value) : rdChecked.value;
                $JS.PostA($JS.urlAction('resize') + '?debug=1', 'name='+itemName+'&type='+type+'&value='+value, function(response) {
                    try {
                        json = JSON.parse(response);
                    } catch (ex) {}
                    if (json && json.status==1) {
                        var div = document.createElement('div'), 
                        context = document.getElementById('formUpload').getAttribute('data-context'), 
                        contextImage = document.getElementById('formUpload').getAttribute('data-context-image');
                        div.className = 'file-item';
                        div.setAttribute('role', "fileitem");
                        div.setAttribute('value', json.filename);
                        div.setAttribute('type', 'file');
                        div.innerHTML = '<div>'
                            +'<div class="text-center valign-middle">'
                            + (json.fileinfo.type=='image' ? ('<img src="'+json.src+'" context="' +contextImage+ '" />'):('<i class="fa fa-file-o fa-3x" style="color:#000" title="'+json.fileinfo.mime+'" context="' +context+ '"></i>'))
                            +'</div>'
                        +'</div>'
                        +'<div>'
                            +'<div class="text-center">'
                                +'<a context="' +context+ '" href="'+json.src+'" target="_blank" title="'+json.filename+'">'+json.filename+'</a>'
                                +'<span context="' +context+ '" class="size">'+json.fileinfo.size+'</span>'
                            +'</div>'
                        +'</div>';
                        document.getElementById('fileman').children[0].appendChild(div);
                    }
                });
            }
        });
    },
    duplicate:function($JS){
        var itemName = $JS.item.getAttribute('value'), 
        type = $JS.item.getAttribute('type');
        $JS.PostA($JS.urlAction('duplicate'), 'name='+itemName+'&type='+type, function(response) {
            try {
                json = JSON.parse(response);
            } catch (ex) {}
            if (json && json.status==1) {
                var div = document.createElement('div'), 
                context = document.getElementById('formUpload').getAttribute('data-context'), 
                contextImage = document.getElementById('formUpload').getAttribute('data-context-image');
                div.className = 'file-item';
                div.setAttribute('role', "fileitem");
                div.setAttribute('value', json.filename);
                div.setAttribute('type', 'file');
                div.innerHTML = '<div>'
                    +'<div class="text-center valign-middle">'
                    + (json.fileinfo.type=='image' ? ('<img src="'+json.src+'" context="' +contextImage+ '" />'):('<i class="fa fa-file-o fa-3x" style="color:#000" title="'+json.fileinfo.mime+'" context="' +context+ '"></i>'))
                    +'</div>'
                +'</div>'
                +'<div>'
                    +'<div class="text-center">'
                        +'<a context="' +context+ '" href="'+json.src+'" target="_blank" title="'+json.filename+'">'+json.filename+'</a>'
                        +'<span context="' +context+ '" class="size">'+json.fileinfo.size+'</span>'
                    +'</div>'
                +'</div>';
                document.getElementById('fileman').children[0].appendChild(div);
            }
        });
    },
    del:function($JS){
        var itemName = $JS.item.getAttribute('value'), 
        type = $JS.item.getAttribute('type');
        $JS.confirmDelete(itemName, function(){
            $JS.PostA($JS.urlAction('del'), 'name='+itemName+'&type='+type, function(response) {
                if (response.getElementsByTagName('status')[0].childNodes[0].nodeValue==1) {
                    item = $JS.item;
                    item.parentNode.removeChild(item);
                }
            });
        });
    },
    rename:function($JS){
        var oldname = $JS.item.getAttribute('value'), 
        type = $JS.item.getAttribute('type');
        $JS.promptRename(oldname, function() {
            var newName = document.querySelector('input[name="new-name"]').value;
            if (newName) {
                $JS.PostA($JS.urlAction('rename'), 'old-name='+oldname+'&new-name='+newName+'&type='+type, function(response) {
                    window.ttt = response;
                    if (response.getElementsByTagName('status')[0].childNodes[0].nodeValue==1) {
                        $JS.item.setAttribute('value', newName);
                        a = $JS.item.getElementsByTagName('a');
                        a[a.length-1].innerHTML=newName;
                        if (type=='file') {
                            console.log($JS.item.children[0].children[0].children[0].getAttribute('context'))
                            var thiscontext = $JS.item.children[0].children[0].children[0].getAttribute('context');
                            if (response.getElementsByTagName('status')[0].getAttribute('is-img')=='1') {
                                $JS.item.children[0].children[0].innerHTML='<img src="' +response.getElementsByTagName('status')[0].getAttribute('src')+ '" context="'+document.getElementById('formUpload').getAttribute('data-context-image')+'" onclick="viewImage(this)" />';
                            } else {
                                $JS.item.children[0].children[0].innerHTML='<i class="fa fa-file-o fa-3x" style="color:#000" title="' +response.getElementsByTagName('status')[0].getAttribute('mime')+ '" context="'+document.getElementById('formUpload').getAttribute('data-context')+'"></i>';
                            }
                        }
                    }
                });
                
            }
        });
    },
    upload:function() {
        document.getElementById('fileman').className = 'box-body dragover'
    },
    newdir:function($JS) {
        var formNewdir = document.querySelector('#backdrop-static form[name="newdir"]');
        if (formNewdir) {
            document.getElementById('backdrop-static').style.display = 'block';
            formNewdir.style.display = 'inline-block';
            document.querySelector('#backdrop-static form[name="newdir"] button[type="reset"]').onclick=function(e) {
                $JS.closeAllPopup();
            }
            formNewdir.onsubmit=function(e) {
                e.preventDefault();
                var folderName = this.querySelector('input[name="folder-name"]').value;
                var dirpath = formNewdir.getAttribute('data-dirpath');
                var context = formNewdir.getAttribute('data-context');
                $JS.PostA($JS.urlAction('newfolder'), 'folderName='+folderName, function(response){
                    if (response.getElementsByTagName('status')[0].childNodes[0].nodeValue==1) {
                        var folderName = response.getElementsByTagName('status')[0].getAttribute('name');
                        var div = document.createElement('div');
                        div.className = 'folder-item';
                        div.setAttribute('role', 'fileitem');
                        div.setAttribute('value', folderName);
                        div.setAttribute('type', 'folder');
                        div.innerHTML = '<div>'
                            +'<div class="text-center valign-middle">'
                                +'<a href="/' +dirpath+ '/' +folderName+ '" value="' +folderName+ '" context="' +context+ '">'
                                    +'<i class="fa fa-folder fa-3x"></i>'
                                +'</a>'
                            +'</div>'
                        +'</div>'
                        +'<div>'
                            +'<div class="text-center">'
                                +'<a href="/' +dirpath+ '/' +folderName+ '" context="' +context+ '" value="' +folderName+ '">' +folderName+ '</a>'
                            +'</div>'
                        +'</div>';
                        var ff = document.querySelector('#fileman div[role="fileitem"].file-item');
                        if (ff) {
                            document.getElementById('fileman').children[0].insertBefore(div, ff);
                        } else {
                            document.getElementById('fileman').children[0].appendChild(div);
                        }
                        formNewdir.reset();
                        $JS.closeAllPopup();
                        div.querySelector('div[class="text-center"] a').focus();
                    }
                });
            }
        }
    }
})
