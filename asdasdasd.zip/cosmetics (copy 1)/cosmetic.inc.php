<?php 
use Htlib\Mvc\Routes;

return array(
    array(
        '' => function () {
            exit('404');
        },
        '/' => array(
            'file' => 'fronts/Home',
            'class'=> 'Home::index'
        ),
        _KADMIN => array(
            'file' => 'TamchanCMS',
            // 'class' => 'TamchanCMS',
            'call' => 'TamchanCMS::loadMod',
            'arg' => function () { 
                $args = func_get_args();
                return array(
                    'path_admin' => array_shift($args),
                    'mod' => array_shift($args),
                    'action' => array_shift($args),
                    'params' => array_values($args)
                );
            },
        ),
    ),
    function ($setting, $a=null, $b=null, $c=null, $d=null) {
        if ($b == _KADMIN) {
            Htlib_Template::basePath($setting->template_cms);
        } else {
            Htlib_Template::basePath($setting->template_dir);
        }
        Htlib_Template::compilerDir($setting->compiler_dir);
    },
    'template_cms' => __DIR__.'/tamchans/templates',
    'template_dir' => __DIR__.'/fronts/templates',
    'compiler_dir' => __DIR__.'/compiler_dir',
);
