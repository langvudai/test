<?php 
namespace Cosmetic\Admin;

use Htlib\Mvc\Controller as HtlibController;
use Htlib\Interfaces\Controller as IController;

class Controller extends HtlibController implements IController
{

}