<?php 

use Htlib\Mvc\Controller;
use Cosmetic\Admin\Process\Authentication;

/**
 * summary
 */
class Login extends Controller
{
    protected $_name = 'account';
	// public function __construct()
	// {
	// 	echo 'string';
 //    	print_r(func_get_args());
	// }
 //    {
 //        parent::__construct();
 //        $request_method = Htlib_Request::getMethod();
 //        if (method_exists($this, $request_method.'_'.$arguments['method'])) {
 //            call_user_func_array(array($this, $request_method.'_'.$arguments['method']), $arguments);
 //        } elseif (method_exists($this, $arguments['method'])) {
 //            call_user_func_array(array($this, $arguments['method']), $arguments);
 //        }
 //    }

    public function passwordGenerate($username, $password, Authentication $authentication)
    {
    	echo 'Bcrypt Password: ' . (int)$authentication->confirmUserPass('admin', '123456');
    	// $authentication = new Authentication ();
    	// $bcrypt = new bcrypt(12);

		// /* Two create a Hash you do */
		// echo 'Bcrypt Password: ' . $bcrypt->generateHash('password');
		// $2a$12$mYSnMDcWQF36ZQbgrHm/KeI32mxVk35MfUnDK9lcnUrzPO50Yg9J2Array

		// /* Two verify a hash you do */
		// $HashFromDB = $bcrypt->genHash('password'); /* This is an example you would draw the hash from your db */
		// $verify = $bcrypt->verify('password', '$2a$12$mYSnMDcWQF36ZQbgrHm/KeI32mxVk35MfUnDK9lcnUrzPO50Yg9J2');

  //   	echo (int)$verify;
  //   	print_r(func_get_args());
        // $username = preg_replace('/[^a-z][a-z0-9]+/i','',$username);
        // $password = $this->generatepw($username, $password);
        // $uid = uniqid('', true);

        // if (preg_match_all('/\d/', $uid, $matches)) {
        //     $uid.= '.'.dechex(implode($matches[0]));
        // }

        // $this->where('`useid` IS NULL AND `username` = {$username} AND `isAdmin`={$is_admin}', array(
        //     'username' => $username,
        //     'is_admin' => biten(1),
        // ))->update(array('password' => $password, 'useid' => $uid));
    }

    private function index($a, $b)
    {
        $a = array('a' => 1, 'b' => 2, 'c'=>3);
        $b = array('a'=> '', 'c' => '');

        print_r(array_intersect_key($a, $b));

        exit('-');
        echo 'string';
        $this->getTableSchema();
        $data = $this->parseSchema(array('username' => 'abc', 'hhhh' => 'hh'));
        echo 'string';
        $template = new Htlib_Template('login/index', array('rand' => $b));
        $template->render();
    }

    private function POST_index()
    {
        $post = new Htlib_Request('POST');
        
        if ($this->confirmUserPass($post->username, $post->password, $post->rand)) {
            header('location: '.admin_url());
        } else {
            header('location: /login/'. rand(0,999999));
        }
    }

    private function logout()
    {
        Htlib_Session::destroy();
        header('location: '.admin_url());
    }

    private function confirmUserPass($username, $password, $rand='')
    {
        $username = preg_replace('/[^a-z][a-z0-9]+/i','',$username);
        $result = $this->query('SELECT `id`, `password` FROM {_account} WHERE `username` = {$username} AND `isAdmin`={$is_admin}', array(
            'username' => $username,
            'is_admin' => biten(1),
        ))
        ->fetchRow();

        if (empty($result)) {
            Htlib_Log::open('app')->logerror($username. ' is not found');
            return false;
        }
        if ($this->vefifypw($username, $password, $result['password'])) {
            $uid = uniqid($rand, true);

            if (preg_match_all('/\d/', $uid, $matches)) {
                $uid.= '.'.dechex(implode($matches[0]));
            }

            $uid.= '.'.time();
            Htlib_Session::set(_USER_ID, $result['id']);
            $result = $this->where('`id`={$id} AND `password`={$password}', array(
                'id' => $result['id'],
                'password' => $result['password'],
            ))->update(array('useid' => $uid));

            if ($result) {
                Htlib_Session::set(_TKKEYA, $uid);
            }

            return true;
        }

        return false;
    }

    private function generatepw($username, $password)
    {
        $password = sha1('qaz\'`490-=OP{'.strlen($username).$password.' }|L:"VB<');
        $l = rand(0, 32);
        $salt = substr(md5(rand()), 0, 15);
        return substr($password, 0, $l).$salt.substr($password, $l).str_pad(dechex($l), 2, 0, STR_PAD_LEFT);
    }

    private function vefifypw($username, $password, $password_compare)
    {
        $l = hexdec(substr($password_compare, -2));
        $password = sha1('qaz\'`490-=OP{'.strlen($username).$password.' }|L:"VB<');
        $password_compare = substr($password_compare, 0, strlen($password_compare)-2);
        $password_compare = substr($password_compare, 0, $l).substr($password_compare, $l+15);
        return ($password_compare === $password);
    }
}