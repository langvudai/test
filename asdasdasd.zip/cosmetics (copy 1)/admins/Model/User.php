<?php

namespace Cosmetic\Admin\Model;

use Htlib\Mvc\Model;

/**
 * summary
 */
class User extends Model
{
    protected $_name = 'users';

    protected $_filter_fields = array();
}