<?php 

namespace Cosmetic\Admin\Process;

use Cosmetic\Admin\Model\User;

/**
 * Authentication
 */
class Authentication
{
	private $rounds;

	public function __construct() 
	{
		if (!CRYPT_BLOWFISH) {
			throw new Exception("Bcrypt is not supported on this server, please see the following to learn more: http://php.net/crypt");
		}
		$this->rounds = 12;
	}

	public function createFields($username, $password)
	{
		$username = preg_replace('/[^a-z][a-z0-9]+/i','',$username);
		return array(
			'username' => $username,
			'password' => $this->generateHash($username . $password),
		);
	}

	public function confirmUserPass($username, $password, $rand='')
	{
		// echo $this->generateHash('admin123456').';';
		$password = $username.$password;
		$username = preg_replace('/[^a-z][a-z0-9]+/i','',$username);
		$user = new User();
		$result = $user->select('id', 'password')
			->where('username = ', $username)
			->where('actived=', 1)
			// ->fetchRow()
			;
		echo $result;
    	// $result = $this->query('SELECT `id`, `password` FROM {_account} WHERE `username` = {$username} AND `isAdmin`={$is_admin}', array(
     //        'username' => $username,
     //        'is_admin' => biten(1),
     //    ))
     //    ->fetchRow();

     //    if (empty($result)) {
     //        Htlib_Log::open('app')->logerror($username. ' is not found');
     //        return false;
     //    }
     //    if ($this->verify($username . $password, $result['password'])) {
     //        $uid = uniqid($rand, true);

     //        if (preg_match_all('/\d/', $uid, $matches)) {
     //            $uid.= '.'.dechex(implode($matches[0]));
     //        }

     //        $uid.= '.'.time();
     //        Htlib_Session::set(_USER_ID, $result['id']);
     //        $result = $this->where('`id`={$id} AND `password`={$password}', array(
     //            'id' => $result['id'],
     //            'password' => $result['password'],
     //        ))->update(array('useid' => $uid));

     //        if ($result) {
     //            Htlib_Session::set(_TKKEYA, $uid);
     //        }

     //        return true;
     //    }

     //    return false;
	}

	/**
	 * [generateHash description]
	 * @param  [type] $password [description]
	 * @return [type]           [description]
	 */
	private function generateHash($password) 
	{
		/* Explain '$2a$' . $this->rounds . '$' */
			/* 2a selects bcrypt algorithm */
			/* $this->rounds is the workload factor */
		/* GenHash */
		$hash = crypt($password, '$2a$' . $this->rounds . '$' . $this->generateSalt());
		/* Return */
		return $hash;
	}
	
	/* Verify Password */
	private function verify($password, $existingHash) {
		/* Hash new password with old hash */
		$hash = crypt($password, $existingHash);
		
		/* Do Hashs match? */
		if($hash === $existingHash) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * [generateSalt description]
	 * @return [type] [description]
	 */
	private function generateSalt() 
	{
		/* openssl_random_pseudo_bytes(16) Fallback */
		$seed = '';
		for($i = 0; $i < 16; $i++) {
			$seed .= chr(mt_rand(0, 255));
		}
		/* GenSalt */
		$salt = substr(strtr(base64_encode($seed), '+', '.'), 0, 22);
		/* Return */
		return $salt;
	}
}