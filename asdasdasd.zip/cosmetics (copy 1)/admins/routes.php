<?php 
use Htlib\Mvc\Routes;

Routes::add('login', array(
	'file' => 'Login',
	'class' => 'Login::index',
	'arg' => function ($a = null, $b = null) {
		return array('rand' => $b);
	},
));//->arg(function ($a = null, $b = null) {return array('rand' => $b);});
// Routes::add('logout', 'Login::logout')->name('logout');
Routes::add('loginpwg/{$username}/{$password}', 'Login::passwordGenerate')->regex(array('username' => '[a-z]+'));