<?php 

namespace Cosmetic\Admin\Process;

/**
 * Authentication
 */
class Authentication
{
	private $rounds;

	public function __construct() 
	{
		if (!CRYPT_BLOWFISH) {
			throw new Exception("Bcrypt is not supported on this server, please see the following to learn more: http://php.net/crypt");
		}
		$this->rounds = 12;
	}

	public function confirmUserPass($username, $password, $rand='')
	{
		
	}

	/**
	 * [generateHash description]
	 * @param  [type] $password [description]
	 * @return [type]           [description]
	 */
	private function generateHash($password) 
	{
		/* Explain '$2a$' . $this->rounds . '$' */
			/* 2a selects bcrypt algorithm */
			/* $this->rounds is the workload factor */
		/* GenHash */
		$hash = crypt($password, '$2a$' . $this->rounds . '$' . $this->generateSalt());
		/* Return */
		return $hash;
	}
	
	/* Verify Password */
	private function verify($password, $existingHash) {
		/* Hash new password with old hash */
		$hash = crypt($password, $existingHash);
		
		/* Do Hashs match? */
		if($hash === $existingHash) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * [generateSalt description]
	 * @return [type] [description]
	 */
	private function generateSalt() 
	{
		/* openssl_random_pseudo_bytes(16) Fallback */
		$seed = '';
		for($i = 0; $i < 16; $i++) {
			$seed .= chr(mt_rand(0, 255));
		}
		/* GenSalt */
		$salt = substr(strtr(base64_encode($seed), '+', '.'), 0, 22);
		/* Return */
		return $salt;
	}
}
/* Next the Usage */
/* Start Instance */
// $bcrypt = new bcrypt(12);

// /* Two create a Hash you do */
// echo 'Bcrypt Password: ' . $bcrypt->genHash('password');

// /* Two verify a hash you do */
// $HashFromDB = $bcrypt->genHash('password'); /* This is an example you would draw the hash from your db */
// $verify = $bcrypt->verify('password', $HashFromDB);