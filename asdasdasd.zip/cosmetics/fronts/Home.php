<?php

/**
 * summary
 */
class Home
{
    /**
     * summary
     */
    public function __construct()
    {
        // echo '5555';
        $this->index()->render();
        $f = new Glib_Request(Glib_Request::FILE);
        print_r($f->aa);
        // $files = $_FILES;
        // print_r($files);
       //  $request = array();
       //  foreach ($_FILES as $name => $value) {
       //  	if (is_array($value['name'])) {
       //  		$request[$name] = array();
       //  		foreach ($value['error'] as $i => $error) {
       //  			if ($error) {
       //  				$request[$name] = (object)array('error'=>$error);
       //  				return false;
       //  			}
       //  			$request[$name][] = (object)array(
       //  				'name' => $value['name'][$i],
       //  				'type' => $value['type'][$i],
       //  				'tmp_name' => $value['tmp_name'][$i],
       //  				'size' => $value['size'][$i],
       //  			);
       //  		}
       //  	} else {
       //  		if ($value['error']) {
    			// 	$request[$name] = (object)array('error'=>$value['error']);
    			// 	return false;
    			// }
    			// $request[$name] = (object)array(
    			// 	'name' => $value['name'],
    			// 	'type' => $value['type'],
    			// 	'tmp_name' => $value['tmp_name'],
    			// 	'size' => $value['size'],
    			// );
       //  	}
       //  }
       //  print_r($request);
    }

    public function index()
    {
    	// echo 'home';
    	return new Glib_Template('index');
    }
}