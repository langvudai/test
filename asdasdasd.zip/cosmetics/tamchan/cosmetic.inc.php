<?php 

return array(
    array(
        '' => function () {
            echo 'string';
            return array(
                'file' => __DIR__.'/../tamchans/Dashboard.php',
                'class'=> 'Dashboard::index'
            );
        },
        '/' => array(
            'file' => __DIR__.'/../tamchans/Dashboard.php',
            'class'=> 'Dashboard::index'
        ),
        _KADMIN => array(
            'file' => __DIR__.'/../tamchans/Dashboard.php',
            'class'=> 'Dashboard::index'
        ),
    ),
    function ($setting, $admin=null, $b=null, $c=null, $d=null) {
        print_r(func_get_args());
        exit;
        Glib_Autoload::init('tamchan', __DIR__);
        if ($b == _KADMIN) {
            Glib_Template::basePath($setting->template_cms);
        } else {
            Glib_Template::basePath($setting->template_dir);
        }
        Glib_Template::compilerDir($setting->compiler_dir);
    },
    'template_cms' => __DIR__.'/tamchans/templates',
    'template_dir' => __DIR__.'/fronts/templates',
    'compiler_dir' => __DIR__.'/compiler_dir',
);
