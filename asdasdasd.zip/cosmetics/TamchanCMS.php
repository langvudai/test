<?php 

class TamchanCMS
{
	const Login = 'login';

	private static $path_admin;
	protected $mod;
	protected $action;
	protected $params;

	public static function loadMod($args)
	{
		$mod = isset($args['mod']) && !empty($args['mod']) ? $args['mod'] : null;
		if (is_numeric($mod)) {
			$class = 'Menu';
			$file = realpath(__DIR__.'/tamchans/'.$class.'.php');
			if (!empty($file) && is_file($file) && is_readable($file)) {
				include_once $file;
				if (class_exists($class)) {
					new $class($args);
				}
			}
		} elseif (is_scalar($mod) && preg_match('/^([a-z])([a-z0-9]+)$/i', $mod, $matches)) {
			$file = realpath(__DIR__.'/tamchans/'.strtoupper($matches[1]).$matches[2].'.php');
			if (!empty($file) && is_file($file) && is_readable($file)) {
				include_once $file;
				if (class_exists($mod)) {
					new $mod($args);
				}
			}
		} else {
			new TamchanCMS($args);
		}
	}

	public function __construct()
	{
		$ht = new HT();
		self::$path_admin = '/'.$ht->path_admin;
		$this->mod = $ht->mod;
		$this->action = $ht->action ? $ht->action : 'index';
		$this->params = $ht->params;

		$authentication = new Cosmetic_Tamchan_Process_Authentication();
		$permission = $authentication->getPermission();
		if ($permission === null) {
			// $this->getUrl('login/'.rand(0, 9999), 1);
			// return;
		}

		$result = $this->runMethod(Glib_Request::getMethod(), $this->action);
		if ($result !== false) {
			$class_name = get_class($this);
			$template = new Glib_Template(strtolower($class_name).DS.$this->action);
			if (is_array($result)) {
			    $template->data($result);
			}
			$template->render();
		}
	}

	public function index()
	{
		$template = new Glib_Template('layout');
        // $template->data();
        $template->render();
	}

	protected function getUrl($url, $redirect = false)
	{
		if (!$redirect) {
			return self::$path_admin.'/'.$url;
		}
		header('location: '.self::$path_admin.'/'.$url);
	}

	/**
     * @param  string $request_method
     * @param  string $method_name
     * @param  HT $ht
     * @return mixed
     */
    private function runMethod($request_method, $method_name)
    {
        if (method_exists($this, $request_method.'_'.$method_name)) {
            return $this->invokeMethod($request_method.'_'.$method_name);
        }

        if (method_exists($this, $method_name)) {
            return $this->invokeMethod($method_name);
        }

        return null;
    }

    /**
     * invokeMethod: invoke if method is public
     * @param  string $method
     * @param  HT $ht
     * @return mixed
     */
    private function invokeMethod($method)
    {
        $reflection_method = new \ReflectionMethod(get_class($this), $method);
        $arguments = array();
        if (!empty($this->params)) {
        	if (is_object($this->params)) {
        		$arguments = get_object_vars($this->params);
        	} else {
        		$arguments = array($this->params);
        	}
        }
        
        if ($reflection_method->isPublic()) {
            return $reflection_method->invokeArgs($this, $arguments);
        }

        return null;
    }
}