<?php

/**
 * summary
 */
class Cosmetic_Tamchan_Process_Authentication
{
	private $user;
	private $bcrypt;
    /**
     * summary
     */
    public function __construct()
    {
        $this->user = new Cosmetic_Tamchan_Class_User();
        $this->bcrypt = new Cosmetic_Tamchan_Bcrypt();
    }

    public function confirmUserPassword($arguments)
    {
        // extract($arguments);
        // print_r($arguments);exit;
        list($username, $password) = array_values($arguments);
        print_r($username);
        // list($id, $password) = $this->user->idPassword($form->username);
        // if ($this->bcrypt->verify($form->username.$form->password, $password)) {
        //     $dtoken = $this->user->createToken($id);
        //     Glib_Session::set(_USER_ID, $id);
        //     Glib_Session::set(_TKKEYA, $dtoken);
        //     return true;
        // }
        return false;
    }

    public function getPermission()
    {
        return null;
    }
}