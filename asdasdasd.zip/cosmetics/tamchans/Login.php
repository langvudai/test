<?php 
/**
 * summary
 */
class Login
{
    private $_post;
	private $authentication;

    /**
     * summary
     */
    public function __construct($arguments)
    {
        // print_r($arguments);
        $post = new Cosmetic_Tamchan_Validation_PostRequest();
    	$authentication = new Cosmetic_Tamchan_Process_Authentication();
        if ($authentication->confirmUserPassword($post->isValidLogin()->getValues())) {
            return $this->gotoAdminPanel();
        }
        $template = new Glib_Template('login/index');
        $template->data($post->getValues());
        $template->render();
    }

    private function gotoAdminPanel()
    {

    }
}