<?php 
/**
 * summary
 */
class Menu extends TamchanCMS
{
    /**
     * summary
     */
    public function __construct2()
    {
        echo 'string';
        // parent::__construct();
    }

    public function test()
    {
    	echo 'testsadasdsd';
    }
}