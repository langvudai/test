<?php 
/**
 * summary
 */
class Cosmetic_Tamchan_Validation_PostRequest extends Glib_Request
{
    private $request;
    private $validated;

    /**
     * summary
     */
    public function __construct()
    {
        // parent::__construct(Glib_Request::POST);
        $this->request = new Glib_Request(Glib_Request::POST);
        $this->validated = array();
    }

    public function getValues()
    {
    	return $this->validated;
    }

    public function isValidLogin()
    {
        $this->validated = array(
            'username' => preg_replace('/([^a-z])/', '', $this->request->username),
            'password' => preg_replace('/([\'"=])/', '', $this->request->password),
        );
        // if (preg_match('//')) {
            
        // }
        // print_r($this->all());
    	return $this;
    }


}