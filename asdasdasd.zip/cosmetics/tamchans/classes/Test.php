<?php 
class Tamchan_Class_Test
{
	function __construct()
	{
		echo 'tttok';
	}
}