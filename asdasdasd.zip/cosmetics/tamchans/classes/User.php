<?php 
/**
 * summary
 */
class Cosmetic_Tamchan_Class_User extends Glib_DbTable
{
	protected $_name = 'users';

    /**
     * summary
     */
    public function idPassword($username)
    {
        $query_row = $this->query('SELECT `id`, `password` FROM `{_users}` WHERE `username`={$username} AND `actived`=1', ['username' => $username])
	        ->fetchRow();
        return [$query_row['id'], $query_row['password']];
    }

    public function createToken($user_id)
    {
    	$token = uniqid();
    	$this->where('id={$user_id}', ['user_id' => $user_id])->update(['dtoken' => $token]);
    	return $token;
    }
}