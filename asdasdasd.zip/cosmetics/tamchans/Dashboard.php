99999<?php 
class Dashboard extends Glib_Do
{
	function index()
	{
		new Tamchan_Class_Test();
		echo 'test';
	}
}